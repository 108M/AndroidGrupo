package com.example.pruebabefit.vista;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.pruebabefit.AppController;
import com.example.pruebabefit.R;
import com.example.pruebabefit.controlador.ControladorApp;
import com.example.pruebabefit.models.ActividadFisica;
import com.example.pruebabefit.models.Ejercicio;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.example.pruebabefit.Imagenes.ImageRepository;
import com.example.pruebabefit.Imagenes.FileResource;





import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ActividadDiaria extends AppCompatActivity {

    private TextView tvTiempo, tvEjercicios;
    private Button btnFinalizar;
    private CountDownTimer countDownTimer;
    private long segundosRestantes;

    private ControladorApp controlador;
    private ActividadFisica actividad;
    private double latitud, longitud;
    private boolean ubicacionObtenida = false;
    private boolean fotoTomada = false;
    private String pathImagen = "";
    private Uri photoUri;

    private static final int REQUEST_LOCATION_PERMISSION = 1001;

    // Permiso de cámara
    private final ActivityResultLauncher<String[]> permLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), res -> {
                if (Boolean.TRUE.equals(res.get(Manifest.permission.CAMERA))) {
                    finalizarActividad();
                } else {
                    Toast.makeText(this, "Permiso de cámara requerido", Toast.LENGTH_SHORT).show();
                }

            });

    // Tomar foto
    private final ActivityResultLauncher<Uri> takeLauncher =
            registerForActivityResult(new ActivityResultContracts.TakePicture(), ok -> {
                if (!ok) {
                    Toast.makeText(this, "No se tomó foto", Toast.LENGTH_SHORT).show();
                    return;
                }

                fotoTomada = true;

                File imageFile = new File(pathImagen);
                ImageRepository imageRepo = new ImageRepository();

                ExecutorService executor = Executors.newSingleThreadExecutor();
                executor.execute(() -> {
                    try {
                        FileResource uploaded = imageRepo.upload(imageFile, imageFile.getName());
                        runOnUiThread(() -> {
                            // Esperamos a que la ubicación esté lista antes de continuar
                            obtenerUbicacion(() -> mostrarDialogoFinal(uploaded.url));
                        });
                    } catch (IOException e) {
                        e.printStackTrace();
                        runOnUiThread(() ->
                                Toast.makeText(this, "Error subiendo imagen", Toast.LENGTH_LONG).show()
                        );
                    }
                });
            });

    private void mostrarDialogoFinal(String imageUrl) {
        new AlertDialog.Builder(this)
                .setTitle("¿Has tenido dolores durante la actividad?")
                .setPositiveButton("Sí", (d, w) -> {
                    Intent i = new Intent(this, DolorMapaActivity.class);
                    i.putExtra("foto", imageUrl);
                    i.putExtra("lat", latitud);
                    i.putExtra("lon", longitud);
                    startActivity(i);
                    finish();
                })
                .setNegativeButton("No", (d, w) -> {
                    controlador.finalizarActividad(imageUrl, latitud, longitud);
                    startActivity(new Intent(this, MenuPrincipal.class));
                    finish();
                })
                .setCancelable(false)
                .show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_actividad_diaria);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, ins) -> {
            Insets b = ins.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(b.left, b.top, b.right, b.bottom);
            return ins;
        });

        tvTiempo = findViewById(R.id.tvTiempo);
        tvEjercicios = findViewById(R.id.tvEjercicios);
        btnFinalizar = findViewById(R.id.btnFinalizar);
        controlador = AppController.getControlador();

        ExecutorService ex = Executors.newSingleThreadExecutor();
        ex.execute(() -> {
            ActividadFisica act = controlador.generarActividadDiaria();
            runOnUiThread(() -> {
                if (act == null) {
                    Toast.makeText(this, "No se pudo generar la actividad diaria", Toast.LENGTH_LONG).show();
                    finish();
                    return;
                }
                actividad = act;
                cargarEjercicios(act);
                configurarTemporizador(act);
            });
        });

        btnFinalizar.setOnClickListener(v -> {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                permLauncher.launch(new String[]{Manifest.permission.CAMERA});
            } else {
                finalizarActividad();
            }
        });

    }

    private void cargarEjercicios(ActividadFisica actividad) {
        StringBuilder sb = new StringBuilder("Ejercicios de hoy:\n");
        List<Ejercicio> listaEjercicios = actividad.getEjercicios();
        if (listaEjercicios != null && !listaEjercicios.isEmpty()) {
            for (Ejercicio ejercicio : listaEjercicios) {
                sb.append("- ").append(ejercicio.getNombre())
                        .append(": ").append(ejercicio.getTecnica())
                        .append("\n");
            }
        } else {
            sb.append("No hay ejercicios asignados.\n");
        }
        tvEjercicios.setText(sb.toString());
    }

    private void configurarTemporizador(ActividadFisica actividad) {
        try {
            String horaMaximaStr = actividad.getHoraMaximaActividad();
            if (horaMaximaStr == null || horaMaximaStr.trim().isEmpty()) {
                tvTiempo.setText("Error: Tiempo no definido");
                return;
            }

            DateTimeFormatter formatter = new DateTimeFormatterBuilder()
                    .appendPattern("HH:mm:ss")
                    .optionalStart()
                    .appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true)
                    .optionalEnd()
                    .toFormatter();

            LocalTime horaMaxima = LocalTime.parse(horaMaximaStr, formatter);
            LocalTime ahora = LocalTime.now();

            if (ahora.isAfter(horaMaxima)) {
                tvTiempo.setText("¡Tiempo completado!");
                return;
            }

            Duration duracion = Duration.between(ahora, horaMaxima);
            segundosRestantes = duracion.getSeconds();

            countDownTimer = new CountDownTimer(segundosRestantes * 1000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    long segundos = millisUntilFinished / 1000;
                    long horas = segundos / 3600;
                    long minutos = (segundos % 3600) / 60;
                    long segs = segundos % 60;
                    tvTiempo.setText(String.format("Tiempo restante: %02d:%02d:%02d", horas, minutos, segs));
                }

                @Override
                public void onFinish() {
                    tvTiempo.setText("¡Tiempo terminado!");
                    Toast.makeText(ActividadDiaria.this, "¡Tiempo de actividad completado!", Toast.LENGTH_SHORT).show();
                }
            };
            countDownTimer.start();
        } catch (Exception e) {
            tvTiempo.setText("Error al configurar el temporizador");
            e.printStackTrace();
        }
    }

    private void finalizarActividad() {
        if (countDownTimer != null) countDownTimer.cancel();
        abrirCamara();
    }

    private void abrirCamara() {
        try {
            File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new java.util.Date());
            File img = new File(dir, "act_" + ts + ".jpg");
            photoUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", img);
            pathImagen = img.getAbsolutePath();
            takeLauncher.launch(photoUri);
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo crear archivo", Toast.LENGTH_SHORT).show();
        }
    }

    private void obtenerUbicacion(Runnable callback) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_LOCATION_PERMISSION);
            return;
        }

        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                latitud = location.getLatitude();
                longitud = location.getLongitude();
                ubicacionObtenida = true;
            } else {
                Toast.makeText(this, "No se pudo obtener la ubicación", Toast.LENGTH_SHORT).show();
            }

            if (callback != null) callback.run(); // Ejecutamos la acción después de obtenerla
        });
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                obtenerUbicacion(null);
            } else {
                Toast.makeText(this, "Permiso de ubicación denegado", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) countDownTimer.cancel();
    }
}
