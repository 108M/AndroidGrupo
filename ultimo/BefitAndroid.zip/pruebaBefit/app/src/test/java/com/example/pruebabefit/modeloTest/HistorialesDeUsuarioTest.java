/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.pruebabefit.modeloTest;

import static org.junit.jupiter.api.Assertions.*;

import com.example.pruebabefit.models.HistorialesDeUsuario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

class HistorialesDeUsuarioTest {

    private HistorialesDeUsuario historial;
    private List<String> historiaIds;

    @BeforeEach
    void setUp() {
        historiaIds = new ArrayList<>();
        historiaIds.add("hist1");
        historial = new HistorialesDeUsuario("user123", historiaIds);
    }

    @Test
    void testConstructorInitialization() {
        assertNotNull(historial);
        assertEquals("user123", historial.getIdUsuario());
        assertEquals(historiaIds, historial.getHistorialUsuarioIds());
    }

    @Test
    void testSetIdUsuario_ValidInput() {
        historial.setIdUsuario("user456");
        assertEquals("user456", historial.getIdUsuario());
    }

    @Test
    void testSetIdUsuario_NullInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> historial.setIdUsuario(null));
    }

    @Test
    void testSetIdUsuario_EmptyInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> historial.setIdUsuario(""));
    }

    @Test
    void testSetHistorialUsuarioIds_ValidInput() {
        List<String> newHistoriaIds = new ArrayList<>();
        newHistoriaIds.add("hist2");
        historial.setHistorialUsuarioIds(newHistoriaIds);
        assertEquals(newHistoriaIds, historial.getHistorialUsuarioIds());
    }

    @Test
    void testSetHistorialUsuarioIds_NullInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> historial.setHistorialUsuarioIds(null));
    }

    @Test
    void testSetHistorialUsuarioIds_EmptyInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> historial.setHistorialUsuarioIds(new ArrayList<>()));
    }

    @Test
    void testAgregarHistoria_ValidInput() {
        historial.agregarHistoria("hist2");
        assertTrue(historial.getHistorialUsuarioIds().contains("hist2"));
        assertEquals(2, historial.getHistorialUsuarioIds().size());
    }

    @Test
    void testAgregarHistoria_NullList_CreatesListAndAdds() {
        HistorialesDeUsuario historial2 = new HistorialesDeUsuario("user789", null);
        historial2.agregarHistoria("hist3");
        assertNotNull(historial2.getHistorialUsuarioIds());
        assertTrue(historial2.getHistorialUsuarioIds().contains("hist3"));
        assertEquals(1, historial2.getHistorialUsuarioIds().size());
    }

    @Test
    void testAgregarHistoria_Duplicate_AddsAnyway() { // Or modify logic to prevent duplicates if needed
        historial.agregarHistoria("hist1");
        int count = 0;
        for (String id : historial.getHistorialUsuarioIds()) {
            if (id.equals("hist1")) {
                count++;
            }
        }
        assertEquals(2, count); // Or change assertion based on desired behavior
    }
}