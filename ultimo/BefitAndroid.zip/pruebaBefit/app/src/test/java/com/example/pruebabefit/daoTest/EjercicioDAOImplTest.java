package com.example.pruebabefit.daoTest;

import static org.junit.jupiter.api.Assertions.*;

import com.example.pruebabefit.dao.EjercicioDAOImpl;
import com.example.pruebabefit.models.Ejercicio;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.util.List;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;

class EjercicioDAOImplTest {

    private MockWebServer mockWebServer;
    private EjercicioDAOImpl ejercicioDAO;

    @BeforeEach
    void setUp() throws IOException {
        mockWebServer = new MockWebServer();
        mockWebServer.start();
        ejercicioDAO = new EjercicioDAOImpl();
        ejercicioDAO.API_URL = mockWebServer.url("/").toString();
    }

    @AfterEach
    void tearDown() throws IOException {
        mockWebServer.shutdown();
    }

    @Test
    void crearEjercicio() throws IOException {
        // Mock the upload image response
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json")
                .setBody("{\"url\":\"image_url\"}"));

        // Mock the create ejercicio response
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json")
                .setBody("{\"objectId\":\"ejercicio123\",\"createdAt\":\"2024-01-01T00:00:00.000Z\"}"));

        File tempImage = File.createTempFile("test_image", ".jpg");
        tempImage.deleteOnExit();

        Ejercicio ejercicio = new Ejercicio("Sentadilla", 5, "image_url", "Buena postura", 1.5f);

        assertDoesNotThrow(() -> ejercicioDAO.crearEjercicio(ejercicio, tempImage));
        assertEquals("image_url", ejercicio.getImagenPath());
    }

    @Test
    void actualizarEjercicio() {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json"));

        Ejercicio ejercicio = new Ejercicio("Press de Banca", 7, "new_image_url", "Pecho recto", 2.0f);
        ejercicio.setObjectId("ejercicio456");

        assertDoesNotThrow(() -> ejercicioDAO.actualizarEjercicio(ejercicio, null));
    }

    @Test
    void eliminarEjercicio() {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json"));

        assertDoesNotThrow(() -> ejercicioDAO.eliminarEjercicio("ejercicio456"));
    }

    @Test
    void obtenerTodosLosEjercicios() {
        String responseBody = "{\"results\":[" +
                "{\"objectId\":\"1\",\"nombre\":\"Correr\"}," +
                "{\"objectId\":\"2\",\"nombre\":\"Nadar\"}" +
                "]}";
        mockWebServer.enqueue(new MockResponse()
                .setBody(responseBody)
                .addHeader("Content-Type", "application/json"));

        List<Ejercicio> ejercicios = ejercicioDAO.obtenerTodosLosEjercicios();

        assertEquals(2, ejercicios.size());
        assertEquals("Correr", ejercicios.get(0).getNombre());
        assertEquals("Nadar", ejercicios.get(1).getNombre());
    }

    @Test
    void obtenerEjercicioPorId() {
        String responseBody = "{\"objectId\":\"1\",\"nombre\":\"Yoga\",\"intensidad\":3,\"imagenPath\":\"yoga.jpg\",\"tecnica\":\"Respiracion\",\"tiempoMax\":1.0}";
        mockWebServer.enqueue(new MockResponse()
                .setBody(responseBody)
                .addHeader("Content-Type", "application/json"));

        Ejercicio ejercicio = ejercicioDAO.obtenerEjercicioPorId("1");

        assertNotNull(ejercicio);
        assertEquals("Yoga", ejercicio.getNombre());
        assertEquals(3, ejercicio.getIntensidad());
    }
}