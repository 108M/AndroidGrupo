/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.pruebabefit.modeloTest;

import static org.junit.jupiter.api.Assertions.*;

import com.example.pruebabefit.models.Ejercicio;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class EjercicioTest {

    private Ejercicio ejercicio;

    @BeforeEach
    void setUp() {
        ejercicio = new Ejercicio("Sentadilla", 5, "sentadilla.jpg", "Espalda recta", 10);
    }

    @Test
    void testConstructorInitialization() {
        assertNotNull(ejercicio);
        assertEquals("Sentadilla", ejercicio.getNombre());
        assertEquals(5, ejercicio.getIntensidad());
        assertEquals("sentadilla.jpg", ejercicio.getImagenPath());
        assertEquals("Espalda recta", ejercicio.getTecnica());
        assertEquals(10, ejercicio.getTiempoMax(), 0.001);
    }

    @Test
    void testSetNombre_ValidInput() {
        ejercicio.setNombre("Press de Banca");
        assertEquals("Press de Banca", ejercicio.getNombre());
    }

    @Test
    void testSetNombre_NullInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> ejercicio.setNombre(null));
    }

    @Test
    void testSetNombre_EmptyInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> ejercicio.setNombre(""));
    }

    @Test
    void testSetIntensidad_ValidInput() {
        ejercicio.setIntensidad(8);
        assertEquals(8, ejercicio.getIntensidad());
    }

    @Test
    void testSetIntensidad_LowerBoundary_ValidInput() {
        ejercicio.setIntensidad(1);
        assertEquals(1, ejercicio.getIntensidad());
    }

    @Test
    void testSetIntensidad_UpperBoundary_ValidInput() {
        ejercicio.setIntensidad(10);
        assertEquals(10, ejercicio.getIntensidad());
    }

    @Test
    void testSetIntensidad_InvalidLowInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> ejercicio.setIntensidad(0));
    }

    @Test
    void testSetIntensidad_InvalidHighInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> ejercicio.setIntensidad(11));
    }

    @Test
    void testSetImagenPath_ValidInput() {
        ejercicio.setImagenPath("nuevo_path.jpg");
        assertEquals("nuevo_path.jpg", ejercicio.getImagenPath());
    }

    @Test
    void testSetImagenPath_NullInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> ejercicio.setImagenPath(null));
    }

    @Test
    void testSetImagenPath_EmptyInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> ejercicio.setImagenPath(""));
    }

    @Test
    void testSetTecnica_ValidInput() {
        ejercicio.setTecnica("Nueva técnica");
        assertEquals("Nueva técnica", ejercicio.getTecnica());
    }

    @Test
    void testSetTecnica_NullInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> ejercicio.setTecnica(null));
    }

    @Test
    void testSetTecnica_EmptyInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> ejercicio.setTecnica(""));
    }

    @Test
    void testSetTiempoMax_ValidInput() {
        ejercicio.setTiempoMax(20);
        assertEquals(20, ejercicio.getTiempoMax(), 0.001);
    }

    @Test
    void testSetTiempoMax_ZeroInput_ThrowsException() {
         assertThrows(IllegalArgumentException.class, () -> ejercicio.setTiempoMax(0));
    }

    @Test
    void testSetTiempoMax_NegativeInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> ejercicio.setTiempoMax(-5));
    }
}