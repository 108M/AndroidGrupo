package com.example.pruebabefit.daoTest;

import static org.junit.jupiter.api.Assertions.*;

import com.example.pruebabefit.dao.HistorialesDeUsuarioDAOImpl;
import com.example.pruebabefit.models.HistorialesDeUsuario;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;

class HistorialesDeUsuarioDAOImplTest {
    private MockWebServer mockWebServer;
    private HistorialesDeUsuarioDAOImpl historialDAO;

    @BeforeEach
    void setUp() throws IOException {
        mockWebServer = new MockWebServer();
        mockWebServer.start();
        
        historialDAO = new HistorialesDeUsuarioDAOImpl();
        historialDAO.API_URL = mockWebServer.url("/").toString();
    }

    @AfterEach
    void tearDown() throws IOException {
        mockWebServer.shutdown();
    }

    @Test
    void crearHistorialDeUsuario() {
        mockWebServer.enqueue(new MockResponse()
                .setBody("{\"objectId\":\"101\",\"createdAt\":\"2023-01-01T00:00:00.000Z\"}")
                .addHeader("Content-Type", "application/json"));

        HistorialesDeUsuario historial = new HistorialesDeUsuario(
                "user123",
                new ArrayList<>()
        );

        historialDAO.crearHistorialDeUsuario(historial);

        assertEquals("101", historial.getObjectId());
    }

    @Test
    void obtenerHistorialDeUsuarioPorIdUsuario() {
        String responseBody = "{\"results\":[{\"objectId\":\"101\",\"idUsuario\":\"user123\"}]}";
        mockWebServer.enqueue(new MockResponse()
                .setBody(responseBody)
                .addHeader("Content-Type", "application/json"));

        HistorialesDeUsuario historial = historialDAO.obtenerHistorialDeUsuarioPorIdUsuario("user123");

        assertNotNull(historial);
        assertEquals("101", historial.getObjectId());
        assertEquals("user123", historial.getIdUsuario());
    }

    @Test
    void obtenerHistorialDeUsuarioPorId() {
        String responseBody = "{\"objectId\":\"101\",\"idUsuario\":\"user123\"}";
        mockWebServer.enqueue(new MockResponse()
                .setBody(responseBody)
                .addHeader("Content-Type", "application/json"));

        HistorialesDeUsuario historial = historialDAO.obtenerHistorialDeUsuarioPorId("101");

        assertNotNull(historial);
        assertEquals("101", historial.getObjectId());
        assertEquals("user123", historial.getIdUsuario());
    }

    @Test
    void actualizarHistorialDeUsuario() {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json"));

        HistorialesDeUsuario historial = new HistorialesDeUsuario(
                "user123",
                new ArrayList<>()
        );
        historial.setObjectId("101");

        assertDoesNotThrow(() -> historialDAO.actualizarHistorialDeUsuario(historial));
    }

    @Test
    void eliminarHistorialDeUsuario() {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json"));

        assertDoesNotThrow(() -> historialDAO.eliminarHistorialDeUsuario("101"));
    }

    @Test
    void obtenerTodosLosHistorialesDeUsuario() {
        String responseBody = "{\"results\":[{\"objectId\":\"1\",\"idUsuario\":\"user1\"},{\"objectId\":\"2\",\"idUsuario\":\"user2\"}]}";
        mockWebServer.enqueue(new MockResponse()
                .setBody(responseBody)
                .addHeader("Content-Type", "application/json"));

        List<HistorialesDeUsuario> historiales = historialDAO.obtenerTodosLosHistorialesDeUsuario();

        assertEquals(2, historiales.size());
        assertEquals("1", historiales.get(0).getObjectId());
        assertEquals("2", historiales.get(1).getObjectId());
    }
}