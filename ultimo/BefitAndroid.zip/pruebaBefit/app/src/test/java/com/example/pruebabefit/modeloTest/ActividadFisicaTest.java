/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.pruebabefit.modeloTest;

import static org.junit.jupiter.api.Assertions.*;

import com.example.pruebabefit.models.ActividadFisica;
import com.example.pruebabefit.models.Ejercicio;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

class ActividadFisicaTest {

    private ActividadFisica actividadFisica;
    private ArrayList<String> ejerciciosIds;
    private LocalTime startTime;
    private LocalTime maxDuration;

    @BeforeEach
    void setUp() {
        ejerciciosIds = new ArrayList<>();
        ejerciciosIds.add("ej1");
        ejerciciosIds.add("ej2");
        startTime = LocalTime.of(10, 0);
        maxDuration = LocalTime.of(11, 0);
        actividadFisica = new ActividadFisica(ejerciciosIds, startTime, maxDuration, false);
    }

    @Test
    void testConstructorInitialization() {
        assertNotNull(actividadFisica);
        assertEquals(ejerciciosIds, actividadFisica.getListaEjerciciosIds());
        assertEquals("10:00", actividadFisica.getHoraComienzoActividad());
        assertEquals("11:00", actividadFisica.getHoraMaximaActividad());
        assertFalse(actividadFisica.getEstado());
        assertNotNull(actividadFisica.getEjercicios());
        assertTrue(actividadFisica.getEjercicios().isEmpty());
    }

    @Test
    void testSetListaEjerciciosIds_ValidInput() {
        ArrayList<String> newIds = new ArrayList<>();
        newIds.add("ej3");
        actividadFisica.setListaEjerciciosIds(newIds);
        assertEquals(newIds, actividadFisica.getListaEjerciciosIds());
    }

    @Test
    void testSetListaEjerciciosIds_NullInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> actividadFisica.setListaEjerciciosIds(null));
    }

    @Test
    void testSetListaEjerciciosIds_EmptyInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> actividadFisica.setListaEjerciciosIds(new ArrayList<>()));
    }

    @Test
    void testSetHoraComienzoActividad_ValidInput() {
        actividadFisica.setHoraComienzoActividad("14:30");
        assertEquals("14:30", actividadFisica.getHoraComienzoActividad());
    }

    @Test
    void testSetHoraComienzoActividad_NullInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> actividadFisica.setHoraComienzoActividad(null));
    }

    @Test
    void testSetHoraComienzoActividad_EmptyInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> actividadFisica.setHoraComienzoActividad(""));
    }

    @Test
    void testSetHoraMaximaActividad_ValidInput() {
        actividadFisica.setHoraMaximaActividad("15:45");
        assertEquals("15:45", actividadFisica.getHoraMaximaActividad());
    }

    @Test
    void testSetHoraMaximaActividad_NullInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> actividadFisica.setHoraMaximaActividad(null));
    }

    @Test
    void testSetHoraMaximaActividad_EmptyInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> actividadFisica.setHoraMaximaActividad(""));
    }

    @Test
    void testSetEstado_ValidInput() {
        actividadFisica.setEstado(true);
        assertTrue(actividadFisica.getEstado());
    }

    @Test
    void testSetEstado_NullInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> actividadFisica.setEstado(null));
    }

    @Test
    void testSetEjercicios_ValidInput() {
        List<Ejercicio> ejercicios = new ArrayList<>();
        ejercicios.add(new Ejercicio("Correr", 5, "correr.jpg", "Buena postura", 30));
        actividadFisica.setEjercicios(ejercicios);
        assertEquals(ejercicios, actividadFisica.getEjercicios());
    }

    @Test
    void testSetEjercicios_EmptyInput() {
        actividadFisica.setEjercicios(new ArrayList<>());
        assertTrue(actividadFisica.getEjercicios().isEmpty());
        assertTrue(actividadFisica.getListaEjerciciosIds().isEmpty()); // Verify IDs are cleared
    }
}