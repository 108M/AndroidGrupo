/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.pruebabefit.modeloTest;

import static org.junit.jupiter.api.Assertions.*;

import com.example.pruebabefit.models.Usuario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UsuarioTest {

    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuario = new Usuario("Alice Smith", 60.5f, 1.65f, 25, Usuario.Genero.MUJER);
    }

    @Test
    void testConstructorInitialization() {
        assertNotNull(usuario);
        assertEquals("Alice Smith", usuario.getNombre());
        assertEquals(60.5f, usuario.getPeso(), 0.001);
        assertEquals(1.65f, usuario.getAltura(), 0.001);
        assertEquals(25, usuario.getEdad());
        assertEquals(Usuario.Genero.MUJER, usuario.getGenero());
    }

    @Test
    void testSetNombre_ValidInput() {
        usuario.setNombre("Bob Johnson");
        assertEquals("Bob Johnson", usuario.getNombre());
    }

    @Test
    void testSetNombre_NullInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> usuario.setNombre(null));
    }

    @Test
    void testSetNombre_EmptyInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> usuario.setNombre(""));
    }

    @Test
    void testSetPeso_ValidInput() {
        usuario.setPeso(70.2f);
        assertEquals(70.2f, usuario.getPeso(), 0.001);
    }

    @Test
    void testSetPeso_ZeroInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> usuario.setPeso(0));
    }

    @Test
    void testSetPeso_NegativeInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> usuario.setPeso(-10));
    }

    @Test
    void testSetAltura_ValidInput() {
        usuario.setAltura(1.80f);
        assertEquals(1.80f, usuario.getAltura(), 0.001);
    }

    @Test
    void testSetAltura_ZeroInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> usuario.setAltura(0));
    }

    @Test
    void testSetAltura_NegativeInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> usuario.setAltura(-1.5f));
    }

    @Test
    void testSetEdad_ValidInput() {
        usuario.setEdad(30);
        assertEquals(30, usuario.getEdad());
    }

    @Test
    void testSetEdad_NegativeInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> usuario.setEdad(-5));
    }

    @Test
    void testSetGenero_ValidInput() {
        usuario.setGenero(Usuario.Genero.HOMBRE);
        assertEquals(Usuario.Genero.HOMBRE, usuario.getGenero());
    }

    @Test
    void testSetGenero_NullInput_DoesNotThrowException() {  // Assuming null is acceptable or handled elsewhere
        usuario.setGenero(null);
        assertNull(usuario.getGenero());
    }
}