package com.example.pruebabefit.modeloTest;

import static org.junit.jupiter.api.Assertions.*;

import com.example.pruebabefit.models.ActividadFisica;
import com.example.pruebabefit.models.Ejercicio;
import com.example.pruebabefit.models.Historia;
import com.example.pruebabefit.models.HistorialesDeUsuario;
import com.example.pruebabefit.models.Usuario;

import org.junit.jupiter.api.Test;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

class ModelTests {

    @Test
    void testUsuarioConstructorAndGettersSetters() {
        Usuario usuario = new Usuario("Alice Smith", 60.5f, 1.65f, 25, Usuario.Genero.MUJER);
        assertNotNull(usuario);
        assertEquals("Alice Smith", usuario.getNombre());
        assertEquals(60.5f, usuario.getPeso(), 0.001);
        assertEquals(1.65f, usuario.getAltura(), 0.001);
        assertEquals(25, usuario.getEdad());
        assertEquals(Usuario.Genero.MUJER, usuario.getGenero());

        assertThrows(IllegalArgumentException.class, () -> usuario.setNombre(null));
        assertThrows(IllegalArgumentException.class, () -> usuario.setPeso(-10));
        assertThrows(IllegalArgumentException.class, () -> usuario.setAltura(0));
        assertThrows(IllegalArgumentException.class, () -> usuario.setEdad(-5));
    }

    @Test
    void testActividadFisicaConstructorAndGettersSetters() {
        ArrayList<String> ejerciciosIds = new ArrayList<>();
        ejerciciosIds.add("ej1");
        LocalTime startTime = LocalTime.of(10, 0);
        LocalTime maxDuration = LocalTime.of(1, 0); // 1 hour
        ActividadFisica actividad = new ActividadFisica(ejerciciosIds, startTime, maxDuration, false);

        assertNotNull(actividad);
        assertEquals(ejerciciosIds, actividad.getListaEjerciciosIds());
        assertEquals("10:00", actividad.getHoraComienzoActividad());
        assertEquals("01:00", actividad.getHoraMaximaActividad());
        assertFalse(actividad.getEstado());

        assertThrows(IllegalArgumentException.class, () -> actividad.setHoraComienzoActividad(null));
        assertThrows(IllegalArgumentException.class, () -> actividad.setEstado(null));
    }

    @Test
    void testEjercicioConstructorAndGettersSetters() {
        Ejercicio ejercicio = new Ejercicio("Levantamiento de pesas", 8, "pesas.jpg", "Espalda recta", 2.5f);
        assertNotNull(ejercicio);
        assertEquals("Levantamiento de pesas", ejercicio.getNombre());
        assertEquals(8, ejercicio.getIntensidad());
        assertEquals("pesas.jpg", ejercicio.getImagenPath());
        assertEquals("Espalda recta", ejercicio.getTecnica());
        assertEquals(2.5f, ejercicio.getTiempoMax(), 0.001);

        assertThrows(IllegalArgumentException.class, () -> ejercicio.setNombre(""));
        assertThrows(IllegalArgumentException.class, () -> ejercicio.setIntensidad(11));
        assertThrows(IllegalArgumentException.class, () -> ejercicio.setTiempoMax(-1));
    }

    @Test
    void testHistoriaConstructorAndGettersSetters() {
        Date now = new Date();
        Historia historia = new Historia(now, "act123", Historia.estadoFinalizacion.FACIL, "historia.jpg", 40.7128, -74.0060);
        assertNotNull(historia);
        assertEquals(now, historia.getFecha());
        assertEquals("act123", historia.getActividadRegistradaId());
        assertEquals(Historia.estadoFinalizacion.FACIL, historia.getEstadoFinalizacion());
        assertEquals("historia.jpg", historia.getImagen());
        assertEquals(40.7128, historia.getLatitud(), 0.0001);
        assertEquals(-74.0060, historia.getLongitud(), 0.0001);

        assertThrows(IllegalArgumentException.class, () -> historia.setFecha(null));
        assertThrows(IllegalArgumentException.class, () -> historia.setActividadRegistradaId(""));
        assertThrows(IllegalArgumentException.class, () -> historia.setEstadoFinalizacion(null));
    }

    @Test
    void testHistorialesDeUsuarioConstructorAndGettersSetters() {
        List<String> historiaIds = new ArrayList<>();
        historiaIds.add("hist1");
        HistorialesDeUsuario historial = new HistorialesDeUsuario("user123", historiaIds);
        assertNotNull(historial);
        assertEquals("user123", historial.getIdUsuario());
        assertEquals(historiaIds, historial.getHistorialUsuarioIds());

        assertThrows(IllegalArgumentException.class, () -> historial.setIdUsuario(null));
        assertThrows(IllegalArgumentException.class, () -> historial.setHistorialUsuarioIds(null));

        historial.agregarHistoria("hist2");
        assertEquals(2, historial.getHistorialUsuarioIds().size());
    }
}