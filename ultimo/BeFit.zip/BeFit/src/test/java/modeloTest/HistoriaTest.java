/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modeloTest;

import modelos.Historia;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class HistoriaTest {

    private Historia historia;
    private Date fecha;

    @BeforeEach
    void setUp() {
        fecha = new Date();
        historia = new Historia(fecha, "act123", Historia.estadoFinalizacion.FACIL, "historia.jpg", 40.7128, -74.0060);
    }

    @Test
    void testConstructorInitialization() {
        assertNotNull(historia);
        assertEquals(fecha, historia.getFecha());
        assertEquals("act123", historia.getActividadRegistradaId());
        assertEquals(Historia.estadoFinalizacion.FACIL, historia.getEstadoFinalizacion());
        assertEquals("historia.jpg", historia.getImagen());
        assertEquals(40.7128, historia.getLatitud(), 0.0001);
        assertEquals(-74.0060, historia.getLongitud(), 0.0001);
    }

    @Test
    void testSetFecha_ValidInput() {
        Date newDate = new Date(System.currentTimeMillis() + 86400000); // Tomorrow
        historia.setFecha(newDate);
        assertEquals(newDate, historia.getFecha());
    }

    @Test
    void testSetFecha_NullInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> historia.setFecha(null));
    }

    @Test
    void testSetActividadRegistradaId_ValidInput() {
        historia.setActividadRegistradaId("act456");
        assertEquals("act456", historia.getActividadRegistradaId());
    }

    @Test
    void testSetActividadRegistradaId_NullInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> historia.setActividadRegistradaId(null));
    }

    @Test
    void testSetActividadRegistradaId_EmptyInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> historia.setActividadRegistradaId(""));
    }

    @Test
    void testSetEstadoFinalizacion_ValidInput() {
        historia.setEstadoFinalizacion(Historia.estadoFinalizacion.MEDIO);
        assertEquals(Historia.estadoFinalizacion.MEDIO, historia.getEstadoFinalizacion());
    }

    @Test
    void testSetEstadoFinalizacion_NullInput_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> historia.setEstadoFinalizacion(null));
    }

    @Test
    void testSetImagen_ValidInput() {
        historia.setImagen("nueva_imagen.png");
        assertEquals("nueva_imagen.png", historia.getImagen());
    }

    @Test
    void testSetImagen_NullInput_DoesNotThrowException() { // Assuming null is acceptable
        historia.setImagen(null);
        assertNull(historia.getImagen());
    }

    @Test
    void testSetLatitud_ValidInput() {
        historia.setLatitud(41.8781);
        assertEquals(41.8781, historia.getLatitud(), 0.0001);
    }

    @Test
    void testSetLongitud_ValidInput() {
        historia.setLongitud(-87.6298);
        assertEquals(-87.6298, historia.getLongitud(), 0.0001);
    }
}