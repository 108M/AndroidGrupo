package daoTest;

import dao.ActividadFisicaDAOImpl;
import modelos.ActividadFisica;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ActividadFisicaDAOImplTest {
    private MockWebServer mockWebServer;
    private ActividadFisicaDAOImpl actividadFisicaDAO;

    @BeforeEach
    void setUp() throws IOException {
        mockWebServer = new MockWebServer();
        mockWebServer.start();
        
        actividadFisicaDAO = new ActividadFisicaDAOImpl();
        // Sobrescribir la URL para usar el servidor mock
        actividadFisicaDAO.API_URL = mockWebServer.url("/").toString();
    }

    @AfterEach
    void tearDown() throws IOException {
        mockWebServer.shutdown();
    }

    @Test
    void crearActividadFisica() {
        // Configurar respuesta mock
        mockWebServer.enqueue(new MockResponse()
                .setBody("{\"objectId\":\"123\",\"createdAt\":\"2023-01-01T00:00:00.000Z\"}")
                .addHeader("Content-Type", "application/json"));

        ActividadFisica actividad = new ActividadFisica(
                new ArrayList<>(),
                LocalTime.now(),
                LocalTime.now().plusHours(1),
                false
        );

        actividadFisicaDAO.crearActividadFisica(actividad);

        assertEquals("123", actividad.getObjectId());
    }

    @Test
    void obtenerActividadFisicaPorId() {
        String responseBody = "{\"objectId\":\"123\",\"horaComienzoActividad\":\"10:00\",\"estado\":false}";
        mockWebServer.enqueue(new MockResponse()
                .setBody(responseBody)
                .addHeader("Content-Type", "application/json"));

        ActividadFisica actividad = actividadFisicaDAO.obtenerActividadFisicaPorId("123");

        assertNotNull(actividad);
        assertEquals("123", actividad.getObjectId());
        assertEquals("10:00", actividad.getHoraComienzoActividad());
        assertFalse(actividad.getEstado());
    }

    @Test
    void actualizarActividadFisica() {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json"));

        ActividadFisica actividad = new ActividadFisica(
                new ArrayList<>(),
                LocalTime.now(),
                LocalTime.now().plusHours(1),
                false
        );
        actividad.setObjectId("123");

        assertDoesNotThrow(() -> actividadFisicaDAO.actualizarActividadFisica(actividad));
    }

    @Test
    void eliminarActividadFisica() {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json"));

        assertDoesNotThrow(() -> actividadFisicaDAO.eliminarActividadFisica("123"));
    }

    @Test
    void obtenerTodasLasActividadesFisicas() {
        String responseBody = "{\"results\":[{\"objectId\":\"1\",\"horaComienzoActividad\":\"10:00\"},{\"objectId\":\"2\",\"horaComienzoActividad\":\"11:00\"}]}";
        mockWebServer.enqueue(new MockResponse()
                .setBody(responseBody)
                .addHeader("Content-Type", "application/json"));

        List<ActividadFisica> actividades = actividadFisicaDAO.obtenerTodasLasActividadesFisicas();

        assertEquals(2, actividades.size());
        assertEquals("1", actividades.get(0).getObjectId());
        assertEquals("2", actividades.get(1).getObjectId());
    }
}