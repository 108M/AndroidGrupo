package daoTest;

import dao.UsuarioDAOImpl;
import modelos.Usuario;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class UsuarioDAOImplTest {
    private MockWebServer mockWebServer;
    private UsuarioDAOImpl usuarioDAO;

    @BeforeEach
    void setUp() throws IOException {
        mockWebServer = new MockWebServer();
        mockWebServer.start();
        
        usuarioDAO = new UsuarioDAOImpl();
        usuarioDAO.API_URL = mockWebServer.url("/").toString();
    }

    @AfterEach
    void tearDown() throws IOException {
        mockWebServer.shutdown();
    }

    @Test
    void crearUsuario() {
        mockWebServer.enqueue(new MockResponse()
                .setBody("{\"objectId\":\"202\",\"createdAt\":\"2023-01-01T00:00:00.000Z\"}")
                .addHeader("Content-Type", "application/json"));

        Usuario usuario = new Usuario(
                "Juan Perez",
                70.5f,
                1.75f,
                30,
                Usuario.Genero.HOMBRE
        );

        usuarioDAO.crearUsuario(usuario);

        assertEquals("202", usuario.getObjectId());
    }

    @Test
    void obtenerUsuarioPorId() {
        String responseBody = "{\"objectId\":\"202\",\"nombre\":\"Juan Perez\",\"edad\":30}";
        mockWebServer.enqueue(new MockResponse()
                .setBody(responseBody)
                .addHeader("Content-Type", "application/json"));

        Usuario usuario = usuarioDAO.obtenerUsuarioPorId("202");

        assertNotNull(usuario);
        assertEquals("202", usuario.getObjectId());
        assertEquals("Juan Perez", usuario.getNombre());
        assertEquals(30, usuario.getEdad());
    }

    @Test
    void actualizarUsuario() {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json"));

        Usuario usuario = new Usuario(
                "Juan Perez",
                70.5f,
                1.75f,
                30,
                Usuario.Genero.HOMBRE
        );
        usuario.setObjectId("202");

        assertDoesNotThrow(() -> usuarioDAO.actualizarUsuario(usuario));
    }

    @Test
    void eliminarUsuario() {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json"));

        assertDoesNotThrow(() -> usuarioDAO.eliminarUsuario("202"));
    }

    @Test
    void obtenerTodosLosUsuarios() {
        String responseBody = "{\"results\":[{\"objectId\":\"1\",\"nombre\":\"Usuario1\"},{\"objectId\":\"2\",\"nombre\":\"Usuario2\"}]}";
        mockWebServer.enqueue(new MockResponse()
                .setBody(responseBody)
                .addHeader("Content-Type", "application/json"));

        List<Usuario> usuarios = usuarioDAO.obtenerTodosLosUsuarios();

        assertEquals(2, usuarios.size());
        assertEquals("1", usuarios.get(0).getObjectId());
        assertEquals("2", usuarios.get(1).getObjectId());
    }
}