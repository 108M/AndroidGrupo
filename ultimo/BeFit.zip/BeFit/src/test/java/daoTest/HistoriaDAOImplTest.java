package daoTest;

import dao.HistoriaDAOImpl;
import modelos.Historia;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class HistoriaDAOImplTest {
    private MockWebServer mockWebServer;
    private HistoriaDAOImpl historiaDAO;

    @BeforeEach
    void setUp() throws Exception {
        mockWebServer = new MockWebServer();
        mockWebServer.start();
        
        historiaDAO = new HistoriaDAOImpl();
        historiaDAO.API_URL = mockWebServer.url("/").toString();
    }

    @AfterEach
    void tearDown() throws Exception {
        mockWebServer.shutdown();
    }

    @Test
    void crearHistoria() {
        mockWebServer.enqueue(new MockResponse()
                .setBody("{\"objectId\":\"789\",\"createdAt\":\"2023-01-01T00:00:00.000Z\"}")
                .addHeader("Content-Type", "application/json"));

        Historia historia = new Historia(
                new Date(),
                "act123",
                Historia.estadoFinalizacion.MEDIO,
                "img.jpg",
                40.4168,
                -3.7038
        );

        historiaDAO.crearHistoria(historia, null);

        assertEquals("789", historia.getObjectId());
    }

    @Test
    void obtenerHistoriaPorId() {
        String responseBody = "{\"objectId\":\"789\",\"actividadRegistradaId\":\"act123\",\"estadoFinalizacion\":\"MEDIO\"}";
        mockWebServer.enqueue(new MockResponse()
                .setBody(responseBody)
                .addHeader("Content-Type", "application/json"));

        Historia historia = historiaDAO.obtenerHistoriaPorId("789");

        assertNotNull(historia);
        assertEquals("789", historia.getObjectId());
        assertEquals("act123", historia.getActividadRegistradaId());
        assertEquals(Historia.estadoFinalizacion.MEDIO, historia.getEstadoFinalizacion());
    }

    @Test
    void actualizarHistoria() {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json"));

        Historia historia = new Historia(
                new Date(),
                "act123",
                Historia.estadoFinalizacion.MEDIO,
                "img.jpg",
                40.4168,
                -3.7038
        );
        historia.setObjectId("789");

        assertDoesNotThrow(() -> historiaDAO.actualizarHistoria(historia, null));
    }

    @Test
    void eliminarHistoria() {
        mockWebServer.enqueue(new MockResponse()
                .setResponseCode(200)
                .addHeader("Content-Type", "application/json"));

        assertDoesNotThrow(() -> historiaDAO.eliminarHistoria("789"));
    }

    @Test
    void obtenerTodasLasHistorias() {
        String responseBody = "{\"results\":[{\"objectId\":\"1\",\"actividadRegistradaId\":\"act1\"},{\"objectId\":\"2\",\"actividadRegistradaId\":\"act2\"}]}";
        mockWebServer.enqueue(new MockResponse()
                .setBody(responseBody)
                .addHeader("Content-Type", "application/json"));

        List<Historia> historias = historiaDAO.obtenerTodasLasHistorias();

        assertEquals(2, historias.size());
        assertEquals("1", historias.get(0).getObjectId());
        assertEquals("2", historias.get(1).getObjectId());
    }
}