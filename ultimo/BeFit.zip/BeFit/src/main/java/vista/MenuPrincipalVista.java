package vista;

import controlador.App;
import javax.swing.*;
import java.awt.*;

public class MenuPrincipalVista extends JFrame {
    private App controlador;
    private JLabel lblBienvenida;
    private JButton btnActividad, btnHistorial, btnPerfil, btnSalir;
    
    public MenuPrincipalVista(App controlador) {
        this.controlador = controlador;
        configurarVentana();
        initComponentes();
        configurarEventos();
    }
    
    private void configurarVentana() {
        setTitle("BeFit - Menú Principal");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
    
    private void initComponentes() {
        // Panel principal
        JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Componentes
        lblBienvenida = new JLabel("Bienvenido, " + controlador.getUsuarioActual().getNombre(), SwingConstants.CENTER);
        lblBienvenida.setFont(new Font("Arial", Font.BOLD, 18));
        
        btnActividad = new JButton("Realizar Actividad Diaria");
        btnHistorial = new JButton("Ver Mi Historial");
        btnPerfil = new JButton("Editar Mi Perfil");
        btnSalir = new JButton("Cerrar Sesión");
        
        // Agregar componentes al panel
        panel.add(lblBienvenida);
        panel.add(btnActividad);
        panel.add(btnHistorial);
        panel.add(btnPerfil);
        panel.add(btnSalir);
        
        add(panel);
    }
    
    private void configurarEventos() {
        btnActividad.addActionListener(e -> {
            new ActividadDiariaVista(controlador).mostrar();
            dispose();
        });
        
        btnHistorial.addActionListener(e -> {
            new HistorialVista(controlador).mostrar();
            dispose();
        });
        
        btnPerfil.addActionListener(e -> {
            new PerfilVista(controlador).mostrar();
            dispose();
        });
        
        btnSalir.addActionListener(e -> {
            controlador.setUsuarioActual(null);
            new LoginRegistroVista(controlador).mostrar();
            dispose();
        });
    }
    
    public void mostrar() {
        setVisible(true);
    }
}