package vista;

import controlador.PanelAdmin;
import modelos.Usuario;
import modelos.Historia;
import modelos.Ejercicio;
import modelos.ActividadFisica;
import modelos.HistorialesDeUsuario;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import javax.imageio.ImageIO;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class AdminVista extends JFrame {

    private PanelAdmin controlador;
    private final OkHttpClient httpClient = new OkHttpClient();

    public AdminVista(PanelAdmin controlador) {
        this.controlador = controlador;
        setTitle("Panel de Control");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Crear botones
        JButton btnCrearUsuario = new JButton("Crear Usuario");
        JButton btnListarUsuarios = new JButton("Listar Usuarios");
        JButton btnCrearActividad = new JButton("Crear Actividad");
        JButton btnListarActividades = new JButton("Listar Actividades");
        JButton btnCrearEjercicio = new JButton("Crear Ejercicio");
        JButton btnListarEjercicios = new JButton("Listar Ejercicios");
        JButton btnCrearHistoria = new JButton("Crear Historia");
        JButton btnListarHistorias = new JButton("Listar Historias");
        JButton btnCrearHistorial = new JButton("Crear Historial");
        JButton btnListarHistoriales = new JButton("Listar Historiales");

        // Configurar el layout
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.add(btnCrearUsuario);
        panel.add(btnListarUsuarios);
        panel.add(btnCrearActividad);
        panel.add(btnListarActividades);
        panel.add(btnCrearEjercicio);
        panel.add(btnListarEjercicios);
        panel.add(btnCrearHistoria);
        panel.add(btnListarHistorias);
        panel.add(btnCrearHistorial);
        panel.add(btnListarHistoriales);

        // Añadir el panel al JFrame
        add(panel);

        // Asignar acciones a los botones
        btnCrearUsuario.addActionListener(e -> crearUsuario());
        btnListarUsuarios.addActionListener(e -> listarUsuarios());
        btnCrearActividad.addActionListener(e -> crearActividad());
        btnListarActividades.addActionListener(e -> listarActividades());
        btnCrearEjercicio.addActionListener(e -> crearEjercicio());
        btnListarEjercicios.addActionListener(e -> listarEjercicios());
        btnCrearHistoria.addActionListener(e -> crearHistoria());
        btnListarHistorias.addActionListener(e -> listarHistorias());
        btnCrearHistorial.addActionListener(e -> crearHistorial());
        btnListarHistoriales.addActionListener(e -> listarHistoriales());
    }
    
    // Método auxiliar para extraer el objectId
    private String extraerObjectId(String item) {
        if (item == null || !item.contains("ObjectId: ")) {
            return null;
        }
        // Extraemos la parte después de "ObjectId: "
        String temp = item.substring(item.indexOf("ObjectId: ") + 10);
        // Tomamos hasta el siguiente separador " | " o el final de la cadena
        int endIndex = temp.indexOf(" - ");
        return endIndex == -1 ? temp : temp.substring(0, endIndex);
    }
    
    private void mostrarDetalleEjercicio(int index) {
        java.util.List<Ejercicio> ejercicios = controlador.getEjercicioDAO().obtenerTodosLosEjercicios();
        if (index >= 0 && index < ejercicios.size()) {
            Ejercicio ejercicio = ejercicios.get(index);

            JDialog detalleDialog = new JDialog(this, "Detalles de Ejercicio", true);
            detalleDialog.setSize(600, 500);
            detalleDialog.setLayout(new BorderLayout());

            // Panel de información
            JPanel infoPanel = new JPanel(new GridLayout(0, 1));
            infoPanel.add(new JLabel("ObjectId: " + (ejercicio.getObjectId() != null ? ejercicio.getObjectId() : "null")));
            infoPanel.add(new JLabel("Nombre: " + (ejercicio.getNombre() != null ? ejercicio.getNombre() : "null")));
            infoPanel.add(new JLabel("Intensidad: " + ejercicio.getIntensidad()));
            infoPanel.add(new JLabel("Técnica: " + (ejercicio.getTecnica() != null ? ejercicio.getTecnica() : "null")));
            infoPanel.add(new JLabel("Tiempo máximo: " + ejercicio.getTiempoMax() + " minutos"));
            infoPanel.add(new JLabel("Imagen: " + (ejercicio.getImagenPath() != null ? "Sí" : "No")));

            // Panel de imagen
            JPanel imagenPanel = new JPanel(new BorderLayout());
            if (ejercicio.getImagenPath() != null && !ejercicio.getImagenPath().isEmpty()) {
                cargarImagenEjercicio(ejercicio.getImagenPath(), imagenPanel);
            } else {
                imagenPanel.add(new JLabel("No hay imagen disponible", SwingConstants.CENTER), BorderLayout.CENTER);
            }

            // Panel principal con split pane
            JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, 
                new JScrollPane(infoPanel), imagenPanel);
            splitPane.setResizeWeight(0.3);

            detalleDialog.add(splitPane, BorderLayout.CENTER);

            // Botón de cerrar
            JButton btnCerrar = new JButton("Cerrar");
            btnCerrar.addActionListener(e -> detalleDialog.dispose());
            detalleDialog.add(btnCerrar, BorderLayout.SOUTH);

            detalleDialog.setLocationRelativeTo(this);
            detalleDialog.setVisible(true);
        }
    }

    private void mostrarDetalleHistoria(int index) {
        java.util.List<Historia> historias = controlador.getHistoriaDAO().obtenerTodasLasHistorias();
        if (index >= 0 && index < historias.size()) {
            Historia historia = historias.get(index);

            JDialog detalleDialog = new JDialog(this, "Detalles de Historia", true);
            detalleDialog.setSize(600, 500);
            detalleDialog.setLayout(new BorderLayout());

            // Panel de información
            JPanel infoPanel = new JPanel(new GridLayout(0, 1));
            infoPanel.add(new JLabel("ObjectId: " + (historia.getObjectId() != null ? historia.getObjectId() : "null")));
            infoPanel.add(new JLabel("Fecha: " + (historia.getFecha() != null ? 
                new SimpleDateFormat("dd/MM/yyyy HH:mm").format(historia.getFecha()) : "null")));
            infoPanel.add(new JLabel("ID Actividad: " + (historia.getActividadRegistradaId() != null ? 
                historia.getActividadRegistradaId() : "null")));
            infoPanel.add(new JLabel("Estado: " + (historia.getEstadoFinalizacion() != null ? 
                historia.getEstadoFinalizacion().toString() : "null")));
            infoPanel.add(new JLabel("Ubicación: Lat " + historia.getLatitud() + ", Long " + historia.getLongitud()));
            infoPanel.add(new JLabel("Imagen: " + (historia.getImagen() != null ? "Sí" : "No")));

            // Panel de imagen
            JPanel imagenPanel = new JPanel(new BorderLayout());
            if (historia.getImagen() != null && !historia.getImagen().isEmpty()) {
                cargarImagen(historia.getImagen(), imagenPanel);
            } else {
                imagenPanel.add(new JLabel("No hay imagen disponible", SwingConstants.CENTER), BorderLayout.CENTER);
            }

            // Panel principal con split pane
            JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, 
                new JScrollPane(infoPanel), imagenPanel);
            splitPane.setResizeWeight(0.3);

            detalleDialog.add(splitPane, BorderLayout.CENTER);

            // Botón de cerrar
            JButton btnCerrar = new JButton("Cerrar");
            btnCerrar.addActionListener(e -> detalleDialog.dispose());
            detalleDialog.add(btnCerrar, BorderLayout.SOUTH);

            detalleDialog.setLocationRelativeTo(this);
            detalleDialog.setVisible(true);
        }
    }

    // Métodos para ActividadFisica
    private void crearActividad() {
        JTextField horaComienzoField = new JTextField();
        JTextField horaMaximaField = new JTextField();
        JCheckBox estadoCheckbox = new JCheckBox("Activa");

        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(new JLabel("Hora de comienzo (HH:MM):"));
        panel.add(horaComienzoField);
        panel.add(new JLabel("Hora máxima (HH:MM):"));
        panel.add(horaMaximaField);
        panel.add(new JLabel("Estado:"));
        panel.add(estadoCheckbox);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Actividad", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                LocalTime horaComienzo = LocalTime.parse(horaComienzoField.getText());
                LocalTime horaMaxima = LocalTime.parse(horaMaximaField.getText());
                boolean estado = estadoCheckbox.isSelected();

                controlador.crearActividad(horaComienzo.toString(), horaMaxima.toString(), null);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error en el formato de hora (HH:MM)", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void listarActividades() {
        DefaultListModel<String> model = controlador.getListModelActividades();
        JList<String> list = new JList<>(model);
        JScrollPane scrollPane = new JScrollPane(list);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        buttonPanel.add(btnModificar);
        buttonPanel.add(btnEliminar);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        JDialog dialog = new JDialog(this, "Lista de Actividades", true);
        dialog.getContentPane().add(panel);
        dialog.setSize(500, 300);
        dialog.setLocationRelativeTo(this);

        btnModificar.addActionListener(e -> {
            int selectedIndex = list.getSelectedIndex();
            if (selectedIndex != -1) {
                String selectedItem = model.getElementAt(selectedIndex);
                String objectId = extraerObjectId(selectedItem);
                ActividadFisica actividad = controlador.obtenerActividadFisicaPorId(objectId);
                if (actividad != null) {
                    mostrarDialogoModificarActividad(actividad);
                    dialog.dispose();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona una actividad para modificar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });

        btnEliminar.addActionListener(e -> {
            int selectedIndex = list.getSelectedIndex();
            if (selectedIndex != -1) {
                String selectedItem = model.getElementAt(selectedIndex);
                String objectId = extraerObjectId(selectedItem);
                int confirm = JOptionPane.showConfirmDialog(this, "¿Seguro que quieres eliminar esta actividad?", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    controlador.eliminarActividadFisica(objectId);
                    dialog.dispose();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona una actividad para eliminar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });

        dialog.setVisible(true);
    }

    private void mostrarDialogoModificarActividad(ActividadFisica actividad) {
        JTextField objectIdField = new JTextField(actividad.getObjectId());
        objectIdField.setEditable(false);
        JTextField horaComienzoField = new JTextField(actividad.getHoraComienzoActividad());
        JTextField horaMaximaField = new JTextField(actividad.getHoraMaximaActividad());
        JTextField horaFinalizacionField = new JTextField(actividad.getHoraFinalizacionActividad() != null ? actividad.getHoraFinalizacionActividad() : "");
        JCheckBox estadoCheckbox = new JCheckBox("Activa", actividad.getEstado());

        JPanel panel = new JPanel(new GridLayout(5, 2));
        panel.add(new JLabel("ObjectId:"));
        panel.add(objectIdField);
        panel.add(new JLabel("Hora de comienzo (HH:MM):"));
        panel.add(horaComienzoField);
        panel.add(new JLabel("Hora máxima (HH:MM):"));
        panel.add(horaMaximaField);
        panel.add(new JLabel("Hora de finalización (HH:MM):"));
        panel.add(horaFinalizacionField);
        panel.add(new JLabel("Estado:"));
        panel.add(estadoCheckbox);

        int result = JOptionPane.showConfirmDialog(this, panel, "Modificar Actividad", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                actividad.setHoraComienzoActividad(horaComienzoField.getText());
                actividad.setHoraMaximaActividad(horaMaximaField.getText());
                
                if (!horaFinalizacionField.getText().isEmpty()) {
                    actividad.setHoraFinalizacionActividad(LocalTime.parse(horaFinalizacionField.getText()));
                }
                
                actividad.setEstado(estadoCheckbox.isSelected());
                
                controlador.actualizarActividadFisica(actividad);
                JOptionPane.showMessageDialog(this, "Actividad actualizada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error en el formato de hora (HH:MM)", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Métodos para Ejercicio
    private void crearEjercicio() {
        JTextField nombreField = new JTextField();
        JSpinner intensidadSpinner = new JSpinner(new SpinnerNumberModel(5, 1, 10, 1));
        JTextField tecnicaField = new JTextField();
        JSpinner tiempoMaxSpinner = new JSpinner(new SpinnerNumberModel(30.0, 1.0, 120.0, 0.5));
        JButton btnSeleccionarImagen = new JButton("Seleccionar Imagen");
        JLabel lblImagenSeleccionada = new JLabel("No se ha seleccionado imagen");

        JFileChooser fileChooser = new JFileChooser();
        btnSeleccionarImagen.addActionListener(e -> {
            if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                lblImagenSeleccionada.setText(fileChooser.getSelectedFile().getName());
            }
        });

        JPanel panel = new JPanel(new GridLayout(6, 2));
        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("Intensidad (1-10):"));
        panel.add(intensidadSpinner);
        panel.add(new JLabel("Técnica:"));
        panel.add(tecnicaField);
        panel.add(new JLabel("Tiempo máximo (min):"));
        panel.add(tiempoMaxSpinner);
        panel.add(new JLabel("Imagen:"));
        panel.add(btnSeleccionarImagen);
        panel.add(new JLabel(""));
        panel.add(lblImagenSeleccionada);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Ejercicio", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String nombre = nombreField.getText();
                int intensidad = (Integer) intensidadSpinner.getValue();
                String tecnica = tecnicaField.getText();
                float tiempoMax = ((Double) tiempoMaxSpinner.getValue()).floatValue();
                File imagenFile = fileChooser.getSelectedFile();

                controlador.crearEjercicio(nombre, intensidad, imagenFile != null ? imagenFile.getAbsolutePath() : "", tecnica, tiempoMax);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al crear el ejercicio: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void listarEjercicios() {
        DefaultListModel<String> model = controlador.getListModelEjercicios();
        JList<String> list = new JList<>(model);
        
        // Agregar listener para mostrar la imagen al hacer clic
        list.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 1) { // Simple clic
                    int index = list.locationToIndex(evt.getPoint());
                    if (index >= 0) {
                        mostrarDetalleEjercicio(index);
                    }
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(list);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        buttonPanel.add(btnModificar);
        buttonPanel.add(btnEliminar);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        JDialog dialog = new JDialog(this, "Lista de Ejercicios", true);
        dialog.getContentPane().add(panel);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);

        btnModificar.addActionListener(e -> {
            int selectedIndex = list.getSelectedIndex();
            if (selectedIndex != -1) {
                String selectedItem = model.getElementAt(selectedIndex);
                String objectId = extraerObjectId(selectedItem);
                Ejercicio ejercicio = controlador.getEjercicioDAO().obtenerEjercicioPorId(objectId);
                if (ejercicio != null) {
                    mostrarDialogoModificarEjercicio(ejercicio);
                    dialog.dispose();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona un ejercicio para modificar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });

        btnEliminar.addActionListener(e -> {
            int selectedIndex = list.getSelectedIndex();
            if (selectedIndex != -1) {
                String selectedItem = model.getElementAt(selectedIndex);
                String objectId = extraerObjectId(selectedItem);
                Ejercicio ejercicio = controlador.getEjercicioDAO().obtenerTodosLosEjercicios().stream()
                    .filter(ej -> ej.getNombre().equals(objectId))
                    .findFirst()
                    .orElse(null);
                
                if (ejercicio != null) {
                    int confirm = JOptionPane.showConfirmDialog(this, 
                        "¿Seguro que quieres eliminar este ejercicio?", 
                        "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        controlador.eliminarEjercicio(ejercicio.getObjectId());
                        dialog.dispose();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona un ejercicio para eliminar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });

        dialog.setVisible(true);
    }

    private void mostrarDialogoModificarEjercicio(Ejercicio ejercicio) {
        JTextField objectIdField = new JTextField(ejercicio.getObjectId());
        objectIdField.setEditable(false);
        JTextField nombreField = new JTextField(ejercicio.getNombre());
        JSpinner intensidadSpinner = new JSpinner(new SpinnerNumberModel((Number) ejercicio.getIntensidad(), 1, 10, 1));
        JTextField tecnicaField = new JTextField(ejercicio.getTecnica());
        JSpinner tiempoMaxSpinner = new JSpinner(new SpinnerNumberModel((double)ejercicio.getTiempoMax(), 1.0, 120.0, 0.5));
        JButton btnSeleccionarImagen = new JButton("Seleccionar Imagen");
        JLabel lblImagenSeleccionada = new JLabel(ejercicio.getImagenPath() != null ? 
            ejercicio.getImagenPath() : "No se ha seleccionado imagen");

        JFileChooser fileChooser = new JFileChooser();
        btnSeleccionarImagen.addActionListener(e -> {
            if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                lblImagenSeleccionada.setText(fileChooser.getSelectedFile().getName());
            }
        });

        JPanel panel = new JPanel(new GridLayout(8, 2));
        panel.add(new JLabel("ObjectId:"));
        panel.add(objectIdField);
        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("Intensidad (1-10):"));
        panel.add(intensidadSpinner);
        panel.add(new JLabel("Técnica:"));
        panel.add(tecnicaField);
        panel.add(new JLabel("Tiempo máximo (min):"));
        panel.add(tiempoMaxSpinner);
        panel.add(new JLabel("Imagen:"));
        panel.add(btnSeleccionarImagen);
        panel.add(new JLabel(""));
        panel.add(lblImagenSeleccionada);

        int result = JOptionPane.showConfirmDialog(this, panel, "Modificar Ejercicio", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                ejercicio.setNombre(nombreField.getText());
                ejercicio.setIntensidad((Integer) intensidadSpinner.getValue());
                ejercicio.setTecnica(tecnicaField.getText());
                ejercicio.setTiempoMax(((Double) tiempoMaxSpinner.getValue()).floatValue());
                
                File imagenFile = fileChooser.getSelectedFile();
                if (imagenFile != null) {
                    ejercicio.setImagenPath(imagenFile.getAbsolutePath());
                }

                controlador.actualizarEjercicio(ejercicio, imagenFile);
                JOptionPane.showMessageDialog(this, "Ejercicio actualizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error al actualizar el ejercicio: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Métodos para Historia
    private void crearHistoria() {
        JTextField idActividadField = new JTextField();
        JComboBox<Historia.estadoFinalizacion> estadoCombo = new JComboBox<>(Historia.estadoFinalizacion.values());
        JTextField latitudField = new JTextField();
        JTextField longitudField = new JTextField();
        JButton btnSeleccionarImagen = new JButton("Seleccionar Imagen");
        JLabel lblImagenSeleccionada = new JLabel("No se ha seleccionado imagen");

        JFileChooser fileChooser = new JFileChooser();
        btnSeleccionarImagen.addActionListener(e -> {
            if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                lblImagenSeleccionada.setText(fileChooser.getSelectedFile().getName());
            }
        });

        JPanel panel = new JPanel(new GridLayout(6, 2));
        panel.add(new JLabel("ID de la actividad:"));
        panel.add(idActividadField);
        panel.add(new JLabel("Estado de finalización:"));
        panel.add(estadoCombo);
        panel.add(new JLabel("Latitud:"));
        panel.add(latitudField);
        panel.add(new JLabel("Longitud:"));
        panel.add(longitudField);
        panel.add(new JLabel("Imagen:"));
        panel.add(btnSeleccionarImagen);
        panel.add(new JLabel(""));
        panel.add(lblImagenSeleccionada);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Historia", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String idActividad = idActividadField.getText();
                Historia.estadoFinalizacion estado = (Historia.estadoFinalizacion) estadoCombo.getSelectedItem();
                double latitud = Double.parseDouble(latitudField.getText());
                double longitud = Double.parseDouble(longitudField.getText());
                File imagenFile = fileChooser.getSelectedFile();

                controlador.crearHistoria(new Date(), idActividad, estado, imagenFile, latitud, longitud);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Latitud y longitud deben ser números válidos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void listarHistorias() {
        DefaultListModel<String> model = controlador.getListModelHistorias();
        JList<String> list = new JList<>(model);
        
        // Agregar listener para mostrar la imagen al hacer clic
        list.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 1) { // Simple clic
                    int index = list.locationToIndex(evt.getPoint());
                    if (index >= 0) {
                        mostrarDetalleHistoria(index);
                    }
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(list);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        buttonPanel.add(btnModificar);
        buttonPanel.add(btnEliminar);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        JDialog dialog = new JDialog(this, "Lista de Historias", true);
        dialog.getContentPane().add(panel);
        dialog.setSize(600, 400);
        dialog.setLocationRelativeTo(this);

        btnModificar.addActionListener(e -> {
            int selectedIndex = list.getSelectedIndex();
            if (selectedIndex != -1) {
                String selectedItem = model.getElementAt(selectedIndex);
                String objectId = extraerObjectId(selectedItem);
                Historia historia = controlador.obtenerHistoriaPorId(objectId);
                if (historia != null) {
                    mostrarDialogoModificarHistoria(historia);
                    dialog.dispose();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona una historia para modificar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });

        btnEliminar.addActionListener(e -> {
            int selectedIndex = list.getSelectedIndex();
            if (selectedIndex != -1) {
                String selectedItem = model.getElementAt(selectedIndex);
                String objectId = extraerObjectId(selectedItem);
                int confirm = JOptionPane.showConfirmDialog(this, 
                    "¿Seguro que quieres eliminar esta historia?", 
                    "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    controlador.eliminarHistoria(objectId);
                    dialog.dispose();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona una historia para eliminar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });

        dialog.setVisible(true);
    }

    private void mostrarDialogoModificarHistoria(Historia historia) {
        JTextField objectIdField = new JTextField(historia.getObjectId());
        objectIdField.setEditable(false);

        // Corregir la forma de mostrar la fecha sin comillas
        JTextField fechaField = new JTextField(historia.getFecha() != null ? 
            new SimpleDateFormat("MMM dd, yyyy, hh:mm:ss a").format(historia.getFecha()) : "null");
        fechaField.setEditable(false);

        JTextField idActividadField = new JTextField(historia.getActividadRegistradaId());
        JComboBox<Historia.estadoFinalizacion> estadoCombo = new JComboBox<>(Historia.estadoFinalizacion.values());
        estadoCombo.setSelectedItem(historia.getEstadoFinalizacion());
        JTextField latitudField = new JTextField(String.valueOf(historia.getLatitud()));
        JTextField longitudField = new JTextField(String.valueOf(historia.getLongitud()));
        JButton btnSeleccionarImagen = new JButton("Seleccionar Imagen");
        JLabel lblImagenSeleccionada = new JLabel(historia.getImagen() != null ? 
            "Imagen actual seleccionada" : "No se ha seleccionado imagen");

        JFileChooser fileChooser = new JFileChooser();
        btnSeleccionarImagen.addActionListener(e -> {
            if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                lblImagenSeleccionada.setText(fileChooser.getSelectedFile().getName());
            }
        });

        JPanel panel = new JPanel(new GridLayout(8, 2));
        panel.add(new JLabel("ObjectId:"));
        panel.add(objectIdField);
        panel.add(new JLabel("Fecha:"));
        panel.add(fechaField);
        panel.add(new JLabel("ID de la actividad:"));
        panel.add(idActividadField);
        panel.add(new JLabel("Estado de finalización:"));
        panel.add(estadoCombo);
        panel.add(new JLabel("Latitud:"));
        panel.add(latitudField);
        panel.add(new JLabel("Longitud:"));
        panel.add(longitudField);
        panel.add(new JLabel("Imagen:"));
        panel.add(btnSeleccionarImagen);
        panel.add(new JLabel(""));
        panel.add(lblImagenSeleccionada);

        int result = JOptionPane.showConfirmDialog(this, panel, "Modificar Historia", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                historia.setActividadRegistradaId(idActividadField.getText());
                historia.setEstadoFinalizacion((Historia.estadoFinalizacion) estadoCombo.getSelectedItem());
                historia.setLatitud(Double.parseDouble(latitudField.getText()));
                historia.setLongitud(Double.parseDouble(longitudField.getText()));

                File imagenFile = fileChooser.getSelectedFile();

                controlador.actualizarHistoria(historia, imagenFile);
                JOptionPane.showMessageDialog(this, "Historia actualizada correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Error: Latitud y longitud deben ser números válidos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Métodos para Historial
    private void crearHistorial() {
        JTextField idUsuarioField = new JTextField();
        JTextField idHistoriaField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(2, 2));
        panel.add(new JLabel("ID del usuario:"));
        panel.add(idUsuarioField);
        panel.add(new JLabel("ID de la historia:"));
        panel.add(idHistoriaField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Historial", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String idUsuario = idUsuarioField.getText();
            String idHistoria = idHistoriaField.getText();

            controlador.crearHistorial(idUsuario, idHistoria);
        }
    }

    private void listarHistoriales() {
        DefaultListModel<String> model = controlador.getListModelHistoriales();
        JList<String> list = new JList<>(model);
        JScrollPane scrollPane = new JScrollPane(list);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        buttonPanel.add(btnModificar);
        buttonPanel.add(btnEliminar);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        JDialog dialog = new JDialog(this, "Lista de Historiales", true);
        dialog.getContentPane().add(panel);
        dialog.setSize(500, 300);
        dialog.setLocationRelativeTo(this);

        btnModificar.addActionListener(e -> {
            int selectedIndex = list.getSelectedIndex();
            if (selectedIndex != -1) {
                String selectedItem = model.getElementAt(selectedIndex);
                String objectId = extraerObjectId(selectedItem);
                HistorialesDeUsuario historial = controlador.obtenerHistorialesDeUsuarioPorId(objectId);
                if (historial != null) {
                    mostrarDialogoModificarHistorial(historial);
                    dialog.dispose();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona un historial para modificar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });

        btnEliminar.addActionListener(e -> {
            int selectedIndex = list.getSelectedIndex();
            if (selectedIndex != -1) {
                String selectedItem = model.getElementAt(selectedIndex);
                String objectId = extraerObjectId(selectedItem);
                int confirm = JOptionPane.showConfirmDialog(this, 
                    "¿Seguro que quieres eliminar este historial?", 
                    "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    controlador.eliminarHistorialesDeUsuario(objectId);
                    dialog.dispose();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona un historial para eliminar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });

        dialog.setVisible(true);
    }

    private void mostrarDialogoModificarHistorial(HistorialesDeUsuario historial) {
        JTextField objectIdField = new JTextField(historial.getObjectId());
        objectIdField.setEditable(false);
        JTextField idUsuarioField = new JTextField(historial.getIdUsuario());
        JTextArea idsHistoriasArea = new JTextArea(String.join("\n", historial.getHistorialUsuarioIds()));
        idsHistoriasArea.setRows(5);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JLabel("ObjectId:"), BorderLayout.NORTH);
        panel.add(objectIdField, BorderLayout.NORTH);
        panel.add(new JLabel("ID del usuario:"), BorderLayout.CENTER);
        panel.add(idUsuarioField, BorderLayout.CENTER);
        panel.add(new JLabel("IDs de historias (uno por línea):"), BorderLayout.SOUTH);
        panel.add(new JScrollPane(idsHistoriasArea), BorderLayout.SOUTH);

        int result = JOptionPane.showConfirmDialog(this, panel, "Modificar Historial", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                historial.setIdUsuario(idUsuarioField.getText());
                
                // Actualizar la lista de IDs de historias
                String[] ids = idsHistoriasArea.getText().split("\n");
                historial.getHistorialUsuarioIds().clear();
                for (String id : ids) {
                    if (!id.trim().isEmpty()) {
                        historial.getHistorialUsuarioIds().add(id.trim());
                    }
                }
                
                controlador.actualizarHistorialesDeUsuario(historial);
                JOptionPane.showMessageDialog(this, "Historial actualizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error al actualizar el historial: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }


    private void crearUsuario() {
        JTextField nombreField = new JTextField();
        JTextField pesoField = new JTextField();
        JTextField alturaField = new JTextField();
        JTextField edadField = new JTextField();
        JComboBox<Usuario.Genero> generoCombo = new JComboBox<>(Usuario.Genero.values());

        JPanel panel = new JPanel(new GridLayout(5, 2));
        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("Peso:"));
        panel.add(pesoField);
        panel.add(new JLabel("Altura:"));
        panel.add(alturaField);
        panel.add(new JLabel("Edad:"));
        panel.add(edadField);
        panel.add(new JLabel("Género:"));
        panel.add(generoCombo);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Usuario", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String nombre = nombreField.getText();
                float peso = Float.parseFloat(pesoField.getText());
                float altura = Float.parseFloat(alturaField.getText());
                int edad = Integer.parseInt(edadField.getText());
                Usuario.Genero genero = (Usuario.Genero) generoCombo.getSelectedItem();

                controlador.crearUsuario(nombre, peso, altura, edad, genero);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Ingresa valores numéricos válidos para peso, altura y edad.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void listarUsuarios() {
        DefaultListModel<String> model = controlador.getListModelUsuarios();
        JList<String> list = new JList<>(model);
        JScrollPane scrollPane = new JScrollPane(list);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        buttonPanel.add(btnModificar);
        buttonPanel.add(btnEliminar);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        JDialog dialog = new JDialog(this, "Lista de Usuarios", true);
        dialog.getContentPane().add(panel);
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(this);

        btnModificar.addActionListener(e -> {
            int selectedIndex = list.getSelectedIndex();
            if (selectedIndex != -1) {
                String selectedItem = model.getElementAt(selectedIndex);
                String objectId = extraerObjectId(selectedItem);
                Usuario usuario = controlador.obtenerUsuarioPorId(objectId);
                if (usuario != null) {
                    mostrarDialogoModificarUsuario(usuario);
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Error al obtener el usuario para modificar.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona un usuario para modificar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });

        btnEliminar.addActionListener(e -> {
            int selectedIndex = list.getSelectedIndex();
            if (selectedIndex != -1) {
                String selectedItem = model.getElementAt(selectedIndex);
                String objectId = extraerObjectId(selectedItem);
                int confirm = JOptionPane.showConfirmDialog(this, "¿Seguro que quieres eliminar este usuario?", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    controlador.eliminarUsuario(objectId.trim());
                    dialog.dispose();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Selecciona un usuario para eliminar.", "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });

        dialog.setVisible(true);
    }

    private void mostrarDialogoModificarUsuario(Usuario usuario) {
        JTextField objectIdField = new JTextField(usuario.getObjectId());
        objectIdField.setEditable(false);
        JTextField nombreField = new JTextField(usuario.getNombre());
        JTextField pesoField = new JTextField(String.valueOf(usuario.getPeso()));
        JTextField alturaField = new JTextField(String.valueOf(usuario.getAltura()));
        JTextField edadField = new JTextField(String.valueOf(usuario.getEdad()));
        JComboBox<Usuario.Genero> generoCombo = new JComboBox<>(Usuario.Genero.values());
        generoCombo.setSelectedItem(usuario.getGenero());

        JPanel panel = new JPanel(new GridLayout(6, 2));
        panel.add(new JLabel("ObjectId:"));
        panel.add(objectIdField);
        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("Peso:"));
        panel.add(pesoField);
        panel.add(new JLabel("Altura:"));
        panel.add(alturaField);
        panel.add(new JLabel("Edad:"));
        panel.add(edadField);
        panel.add(new JLabel("Género:"));
        panel.add(generoCombo);

        int result = JOptionPane.showConfirmDialog(this, panel, "Modificar Usuario", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String nombre = nombreField.getText();
                float peso = Float.parseFloat(pesoField.getText());
                float altura = Float.parseFloat(alturaField.getText());
                int edad = Integer.parseInt(edadField.getText());
                Usuario.Genero genero = (Usuario.Genero) generoCombo.getSelectedItem();

                usuario.setNombre(nombre);
                usuario.setPeso(peso);
                usuario.setAltura(altura);
                usuario.setEdad(edad);
                usuario.setGenero(genero);

                controlador.actualizarUsuario(usuario);
                JOptionPane.showMessageDialog(this, "Usuario actualizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Error: Ingresa valores numéricos válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }



    private void cargarImagenEjercicio(String imagePath, JPanel imagenPanel) {
        JLabel lblCargando = new JLabel("Cargando imagen...", SwingConstants.CENTER);
        imagenPanel.add(lblCargando, BorderLayout.CENTER);
        imagenPanel.revalidate();

        new SwingWorker<ImageIcon, Void>() {
            @Override
            protected ImageIcon doInBackground() throws Exception {
                try {
                    // Verificar si es una URL o una ruta local
                    if (imagePath.startsWith("http")) {
                        return descargarImagen(imagePath);
                    } else {
                        // Cargar imagen local
                        BufferedImage img = ImageIO.read(new File(imagePath));
                        return img != null ? new ImageIcon(img) : null;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            protected void done() {
                try {
                    ImageIcon imageIcon = get();
                    imagenPanel.removeAll();

                    if (imageIcon != null) {
                        // Escalar la imagen manteniendo el aspect ratio
                        Image img = imageIcon.getImage();
                        int ancho = 400;
                        int alto = (int) (ancho * ((double) img.getHeight(null) / img.getWidth(null)));
                        Image scaledImage = img.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);

                        JLabel lblImagen = new JLabel(new ImageIcon(scaledImage));
                        lblImagen.setHorizontalAlignment(SwingConstants.CENTER);
                        imagenPanel.add(lblImagen, BorderLayout.CENTER);
                    } else {
                        imagenPanel.add(new JLabel("No se pudo cargar la imagen", SwingConstants.CENTER), BorderLayout.CENTER);
                    }
                } catch (Exception e) {
                    imagenPanel.add(new JLabel("Error al cargar imagen", SwingConstants.CENTER), BorderLayout.CENTER);
                    e.printStackTrace();
                }
                imagenPanel.revalidate();
                imagenPanel.repaint();
            }
        }.execute();
    }
    
    
    private void cargarImagen(String imageUrl, JPanel imagenPanel) {
        JLabel lblCargando = new JLabel("Cargando imagen...", SwingConstants.CENTER);
        imagenPanel.add(lblCargando, BorderLayout.CENTER);
        imagenPanel.revalidate();

        new SwingWorker<ImageIcon, Void>() {
            @Override
            protected ImageIcon doInBackground() throws Exception {
                return descargarImagen(imageUrl);
            }

            @Override
            protected void done() {
                try {
                    ImageIcon imageIcon = get();
                    imagenPanel.removeAll();

                    if (imageIcon != null) {
                        // Escalar la imagen manteniendo el aspect ratio
                        Image img = imageIcon.getImage();
                        int ancho = 400;
                        int alto = (int) (ancho * ((double) img.getHeight(null) / img.getWidth(null)));
                        Image scaledImage = img.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);

                        JLabel lblImagen = new JLabel(new ImageIcon(scaledImage));
                        lblImagen.setHorizontalAlignment(SwingConstants.CENTER);
                        imagenPanel.add(lblImagen, BorderLayout.CENTER);
                    } else {
                        imagenPanel.add(new JLabel("No se pudo cargar la imagen", SwingConstants.CENTER), BorderLayout.CENTER);
                    }
                } catch (Exception e) {
                    imagenPanel.add(new JLabel("Error al cargar imagen", SwingConstants.CENTER), BorderLayout.CENTER);
                    e.printStackTrace();
                }
                imagenPanel.revalidate();
                imagenPanel.repaint();
            }
        }.execute();
    }

    private ImageIcon descargarImagen(String imageUrl) {
        try {
            Request request = new Request.Builder()
                .url(imageUrl)
                .addHeader("X-Parse-Application-Id", "CdXSEGccBwT7HOAe8T3sE6CNuFiOyJDE9DNFEhJt")
                .addHeader("X-Parse-REST-API-Key", "jcxfHzxoP8jDYslcfGUSbhgMNQn8Iam1Cda35WpJ")
                .build();

            try (Response response = httpClient.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    System.err.println("Error al descargar imagen: " + response.code());
                    return null;
                }

                byte[] imageData = response.body().bytes();
                BufferedImage img = ImageIO.read(new java.io.ByteArrayInputStream(imageData));
                return img != null ? new ImageIcon(img) : null;
            }
        } catch (IOException e) {
            System.err.println("Error al descargar imagen: " + e.getMessage());
            return null;
        }
    }

    public void mostrar() {
        setVisible(true);
    }
}
