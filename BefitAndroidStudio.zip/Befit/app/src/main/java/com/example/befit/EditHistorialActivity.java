package com.example.befit;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.befit.models.Historia;
import com.example.befit.models.HistorialesDeUsuario;
import java.util.ArrayList;
import java.util.List;

public class EditHistorialActivity extends AppCompatActivity {

    private EditText editTextUsuarioID, editTextHistoriaID;
    private Button buttonGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_historial);

        editTextUsuarioID = findViewById(R.id.editTextUsuarioID);
        editTextHistoriaID = findViewById(R.id.editTextHistoriaID);

        buttonGuardar = findViewById(R.id.buttonGuardar);
        buttonGuardar.setOnClickListener(v -> guardarHistorial());
    }

    private void guardarHistorial() {
        try {
            int usuarioID = Integer.parseInt(editTextUsuarioID.getText().toString());
            int historiaID = Integer.parseInt(editTextHistoriaID.getText().toString());

            // Aquí deberías buscar la Historia real, pero simplificamos:
            List<Historia> historias = new ArrayList<>();
            // Podrías añadir la historia real si la tuvieras en una lista global

            HistorialesDeUsuario historial = new HistorialesDeUsuario(usuarioID, historias);

            Toast.makeText(this, "Historial creado para usuario: " + historial.getIdUsuario(), Toast.LENGTH_SHORT).show();
            finish();
        } catch (Exception e) {
            Toast.makeText(this, "Error al crear historial: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
