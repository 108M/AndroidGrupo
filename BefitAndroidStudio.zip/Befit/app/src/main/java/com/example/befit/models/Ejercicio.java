package com.example.befit.models;

import java.io.Serializable;

public class Ejercicio implements Serializable {

    public enum TipoEjercicio {
        FLEXIONES, DOMINADAS, ABDOMINALES, CORRER, BURPIS
    }

    private String nombreEjercicio;
    private Integer intensidad;
    private int imageResId;
    private String tecnica;
    private float tiempoMax;

    public Ejercicio(String nombreEjercicio, Integer intensidad, int imageResId, String tecnica, float tiempoMax) {
        this.nombreEjercicio = nombreEjercicio;
        setIntensidad(intensidad); // Usamos setters para validar
        this.imageResId = imageResId;
        this.tecnica = tecnica;
        setTiempoMax(tiempoMax); // Usamos setters para validar
    }

    public String getNombreEjercicio() {
        return nombreEjercicio;
    }

    public void setNombreEjercicio(String nombreEjercicio) {
        this.nombreEjercicio = nombreEjercicio;
    }

    public Integer getIntensidad() {
        return intensidad;
    }

    public void setIntensidad(Integer intensidad) {
        if (intensidad != null && intensidad >= 0) {
            this.intensidad = intensidad;
        } else {
            this.intensidad = 0; // Valor por defecto si es inválido
        }
    }

    public int getImageResId() {
        return imageResId;
    }

    public void setImageResId(int imageResId) {
        this.imageResId = imageResId;
    }

    public String getTecnica() {
        return tecnica;
    }

    public void setTecnica(String tecnica) {
        this.tecnica = tecnica;
    }

    public float getTiempoMax() {
        return tiempoMax;
    }

    public void setTiempoMax(float tiempoMax) {
        if (tiempoMax >= 0) {
            this.tiempoMax = tiempoMax;
        } else {
            this.tiempoMax = 0; // Valor por defecto si es inválido
        }
    }
}
