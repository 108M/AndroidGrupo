package com.example.befit;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.befit.models.ActividadFisica;
import com.example.befit.models.Ejercicio;
import org.threeten.bp.LocalTime;
import java.util.ArrayList;

public class EditActividadFisicaActivity extends AppCompatActivity {

    private EditText editTextID, editTextHoraComienzo, editTextHoraMaxima, editTextHoraFinalizacion;
    private Button buttonGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_actividad_fisica);

        editTextID = findViewById(R.id.editTextID);
        editTextHoraComienzo = findViewById(R.id.editTextHoraComienzo);
        editTextHoraMaxima = findViewById(R.id.editTextHoraMaxima);
        editTextHoraFinalizacion = findViewById(R.id.editTextHoraFinalizacion);

        buttonGuardar = findViewById(R.id.buttonGuardar);
        buttonGuardar.setOnClickListener(v -> guardarActividadFisica());
    }

    private void guardarActividadFisica() {
        try {
            int id = Integer.parseInt(editTextID.getText().toString());
            LocalTime horaComienzo = LocalTime.parse(editTextHoraComienzo.getText().toString());
            LocalTime horaMaxima = LocalTime.parse(editTextHoraMaxima.getText().toString());
            LocalTime horaFinal = LocalTime.parse(editTextHoraFinalizacion.getText().toString());

            // Por simplicidad, creamos una lista vacía de ejercicios
            ArrayList<Ejercicio> listaEjercicios = new ArrayList<>();

            ActividadFisica actividad = new ActividadFisica(
                    id,
                    listaEjercicios,
                    horaComienzo,
                    horaMaxima,
                    horaFinal,
                    false // estado inicial
            );

            Toast.makeText(this, "Actividad creada: ID " + actividad.getId(), Toast.LENGTH_SHORT).show();
            finish();
        } catch (Exception e) {
            Toast.makeText(this, "Error al crear actividad: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
