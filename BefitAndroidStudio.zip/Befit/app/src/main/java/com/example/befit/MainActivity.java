package com.example.befit;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btnUsuarios, btnActividades, btnEjercicios, btnHistorias, btnHistoriales;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnUsuarios = findViewById(R.id.btnUsuarios);
        btnActividades = findViewById(R.id.btnActividades);
        btnEjercicios = findViewById(R.id.btnEjercicios);
        btnHistorias = findViewById(R.id.btnHistorias);
        btnHistoriales = findViewById(R.id.btnHistoriales);

        // Botón para abrir la pantalla de Usuario
        btnUsuarios.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditUsuarioActivity.class);
            startActivity(intent);
        });

        // Botón para abrir la pantalla de Actividad Física
        btnActividades.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditActividadFisicaActivity.class);
            startActivity(intent);
        });

        // Botón para abrir la pantalla de Ejercicio
        btnEjercicios.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditEjercicioActivity.class);
            startActivity(intent);
        });

        // Botón para abrir la pantalla de Historia
        btnHistorias.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditHistoriaActivity.class);
            startActivity(intent);
        });

        // Botón para abrir la pantalla de Historial
        btnHistoriales.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditHistorialActivity.class);
            startActivity(intent);
        });
    }
}
