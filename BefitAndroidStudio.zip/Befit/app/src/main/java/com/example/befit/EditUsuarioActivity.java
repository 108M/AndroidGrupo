package com.example.befit;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.befit.models.ActividadFisica;
import com.example.befit.models.Usuario;

public class EditUsuarioActivity extends AppCompatActivity {

    private EditText editTextNombre, editTextID, editTextPeso, editTextAltura, editTextEdad, editTextGenero, editTextDificultad;
    private Button buttonGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_usuario);

        editTextNombre = findViewById(R.id.editTextNombre);
        editTextID = findViewById(R.id.editTextID);
        editTextPeso = findViewById(R.id.editTextPeso);
        editTextAltura = findViewById(R.id.editTextAltura);
        editTextEdad = findViewById(R.id.editTextEdad);
        editTextGenero = findViewById(R.id.editTextGenero);
        editTextDificultad = findViewById(R.id.editTextDificultad);

        buttonGuardar = findViewById(R.id.buttonGuardar);

        buttonGuardar.setOnClickListener(v -> guardarUsuario());
    }

    private void guardarUsuario() {
        try {
            String nombre = editTextNombre.getText().toString();
            int id = Integer.parseInt(editTextID.getText().toString());
            float peso = Float.parseFloat(editTextPeso.getText().toString());
            float altura = Float.parseFloat(editTextAltura.getText().toString());
            int edad = Integer.parseInt(editTextEdad.getText().toString());
            String generoStr = editTextGenero.getText().toString().toUpperCase();
            String dificultadStr = editTextDificultad.getText().toString().toUpperCase();

            Usuario.Genero genero = Usuario.Genero.valueOf(generoStr);
            Usuario.Dificultad dificultad = Usuario.Dificultad.valueOf(dificultadStr);

            // Por ahora, no asociamos ActividadFisica
            ActividadFisica actividad = null;

            Usuario usuario = new Usuario(id, nombre, peso, altura, edad, genero, dificultad, actividad);

            // Aquí podrías guardar el usuario en una lista estática, BD, etc.
            Toast.makeText(this, "Usuario guardado: " + usuario.getNombre(), Toast.LENGTH_SHORT).show();

            finish(); // Cierra la Activity

        } catch (Exception e) {
            Toast.makeText(this, "Error al guardar usuario: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
