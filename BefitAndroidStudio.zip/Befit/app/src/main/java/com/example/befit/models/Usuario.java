package com.example.befit.models;

import java.io.Serializable;

public class Usuario implements Serializable {

    public enum Genero {
        HOMBRE, MUJER, OTROS
    }

    public enum Dificultad {
        FACIL, MEDIO, DIFICIL
    }

    private String nombre;
    private int id;
    private float peso;
    private float altura;
    private Integer edad;
    private Genero genero;
    private Dificultad dificultad;
    private ActividadFisica actividadActual;

    public Usuario(int id, String nombre, float peso, float altura, Integer edad, Genero genero, Dificultad dificultad, ActividadFisica actividad) {
        this.id = id;
        this.nombre = nombre;
        this.peso = peso;
        this.altura = altura;
        this.edad = edad;
        this.genero = genero;
        this.dificultad = dificultad;
        this.actividadActual = actividad;
    }

    public ActividadFisica getActividadActual() {
        return actividadActual;
    }

    public void setActividadActual(ActividadFisica actividadActual) {
        this.actividadActual = actividadActual;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Dificultad getDificultad() {
        return dificultad;
    }

    public void setDificultad(Dificultad dificultad) {
        this.dificultad = dificultad;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }
}
