package com.example.befit;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.befit.models.ActividadFisica;
import com.example.befit.models.Historia;
import java.util.ArrayList;
import java.util.Date;

public class EditHistoriaActivity extends AppCompatActivity {

    private EditText editTextFecha, editTextEstadoFinalizacion, editTextActividadID;
    private Button buttonGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_historia);

        editTextFecha = findViewById(R.id.editTextFecha);
        editTextEstadoFinalizacion = findViewById(R.id.editTextEstadoFinalizacion);
        editTextActividadID = findViewById(R.id.editTextActividadID);

        buttonGuardar = findViewById(R.id.buttonGuardar);
        buttonGuardar.setOnClickListener(v -> guardarHistoria());
    }

    private void guardarHistoria() {
        try {
            String fechaStr = editTextFecha.getText().toString(); // Simplificamos
            Date fecha = new Date(); // Podrías parsear la fecha real de 'fechaStr'
            String estadoStr = editTextEstadoFinalizacion.getText().toString().toUpperCase();
            Historia.EstadoFinalizacion estado = Historia.EstadoFinalizacion.valueOf(estadoStr);

            // Aquí deberías buscar la ActividadFisica por su ID, pero simplificamos:
            int actividadID = Integer.parseInt(editTextActividadID.getText().toString());
            ActividadFisica actividad = null;
            // Podrías cargar la actividad real desde una BD o lista en memoria

            ArrayList<Integer> imagenes = new ArrayList<>();
            // Podrías añadir resource IDs si quieres

            Historia historia = new Historia(fecha, actividad, estado, imagenes);

            Toast.makeText(this, "Historia creada con estado: " + historia.getEstadoFinalizacion(), Toast.LENGTH_SHORT).show();
            finish();
        } catch (Exception e) {
            Toast.makeText(this, "Error al crear historia: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
