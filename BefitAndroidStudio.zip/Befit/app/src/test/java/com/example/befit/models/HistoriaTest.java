package com.example.befit.models;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import org.threeten.bp.LocalTime;

import static org.junit.Assert.*;

public class HistoriaTest {

    private Historia historia;
    private ActividadFisica actividadFisica;
    private ArrayList<Integer> imagenesEjercicios;

    @Before
    public void setUp() {
        // Crear lista de Ejercicios con los constructores proporcionados
        ArrayList<Ejercicio> listaEjercicios = new ArrayList<>();
        Ejercicio ejercicio1 = new Ejercicio("Ejercicio 1", 10, 1001, "Técnica 1", 30.0f);
        Ejercicio ejercicio2 = new Ejercicio("Ejercicio 2", 15, 1002, "Técnica 2", 45.0f);
        listaEjercicios.add(ejercicio1);
        listaEjercicios.add(ejercicio2);

        // Crear la ActividadFisica con el constructor correspondiente
        actividadFisica = new ActividadFisica(
                1,
                listaEjercicios,
                LocalTime.of(9, 0), // Hora de comienzo
                LocalTime.of(9, 30), // Hora máxima
                LocalTime.of(10, 0), // Hora de finalización
                true
        );

        // Crear la lista de imágenes (IDs de recursos)
        imagenesEjercicios = new ArrayList<>();
        imagenesEjercicios.add(1001);  // ID de imagen para ejercicio 1
        imagenesEjercicios.add(1002);  // ID de imagen para ejercicio 2

        // Crear una instancia de Historia con una fecha y un estado de finalización
        historia = new Historia(
                new Date(),  // Fecha actual
                actividadFisica,
                Historia.EstadoFinalizacion.MEDIO,  // Estado de finalización
                imagenesEjercicios
        );
    }

    @Test
    public void testGetFecha() {
        // Verificar que la fecha se obtiene correctamente
        assertNotNull(historia.getFecha());
    }

    @Test
    public void testSetFecha() {
        Date nuevaFecha = new Date(System.currentTimeMillis() + 1000000);  // Nueva fecha (milisegundos después)
        historia.setFecha(nuevaFecha);
        assertEquals(nuevaFecha, historia.getFecha());
    }

    @Test
    public void testGetActividadRegistrada() {
        // Verificar que la actividad registrada se obtiene correctamente
        assertNotNull(historia.getActividadRegistrada());
        assertEquals(actividadFisica, historia.getActividadRegistrada());
    }

    @Test
    public void testSetActividadRegistrada() {
        // Crear una nueva ActividadFisica
        ActividadFisica nuevaActividad = new ActividadFisica(
                2,
                new ArrayList<>(),
                LocalTime.of(10, 0),
                LocalTime.of(10, 30),
                LocalTime.of(11, 0),
                false
        );
        historia.setActividadRegistrada(nuevaActividad);
        assertEquals(nuevaActividad, historia.getActividadRegistrada());
    }

    @Test
    public void testGetEstadoFinalizacion() {
        // Verificar que el estado de finalización se obtiene correctamente
        assertEquals(Historia.EstadoFinalizacion.MEDIO, historia.getEstadoFinalizacion());
    }

    @Test
    public void testSetEstadoFinalizacion() {
        historia.setEstadoFinalizacion(Historia.EstadoFinalizacion.DIFICIL);
        assertEquals(Historia.EstadoFinalizacion.DIFICIL, historia.getEstadoFinalizacion());
    }

    @Test
    public void testGetImagenesEjercicios() {
        // Verificar que la lista de imágenes se obtiene correctamente
        assertNotNull(historia.getImagenesEjercicios());
        assertEquals(2, historia.getImagenesEjercicios().size());
        assertEquals((Integer) 1001, historia.getImagenesEjercicios().get(0));
        assertEquals((Integer) 1002, historia.getImagenesEjercicios().get(1));
    }

    @Test
    public void testSetImagenesEjercicios() {
        ArrayList<Integer> nuevasImagenes = new ArrayList<>();
        nuevasImagenes.add(1003);  // Nueva imagen
        nuevasImagenes.add(1004);  // Nueva imagen
        historia.setImagenesEjercicios(nuevasImagenes);

        assertNotNull(historia.getImagenesEjercicios());
        assertEquals(2, historia.getImagenesEjercicios().size());
        assertEquals((Integer) 1003, historia.getImagenesEjercicios().get(0));
        assertEquals((Integer) 1004, historia.getImagenesEjercicios().get(1));
    }
}
