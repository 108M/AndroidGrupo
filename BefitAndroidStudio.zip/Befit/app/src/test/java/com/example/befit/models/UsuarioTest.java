package com.example.befit.models;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class UsuarioTest {

    private Usuario usuario;

    @Before
    public void setUp() {
        usuario = new Usuario(1, "Carlos", 70.5f, 1.75f, 25, Usuario.Genero.HOMBRE, Usuario.Dificultad.MEDIO, null);
    }

    // Test del constructor
    @Test
    public void testConstructor() {
        assertEquals(1, usuario.getId());
        assertEquals("Carlos", usuario.getNombre());
        assertEquals(70.5f, usuario.getPeso(), 0.01);
        assertEquals(1.75f, usuario.getAltura(), 0.01);
        assertEquals(25, usuario.getEdad().intValue());
        assertEquals(Usuario.Genero.HOMBRE, usuario.getGenero());
        assertEquals(Usuario.Dificultad.MEDIO, usuario.getDificultad());
        assertNull(usuario.getActividadActual());
    }

    // Test de getters y setters
    @Test
    public void testSettersYGetters() {
        usuario.setNombre("Ana");
        assertEquals("Ana", usuario.getNombre());

        usuario.setPeso(65.0f);
        assertEquals(65.0f, usuario.getPeso(), 0.01);

        usuario.setAltura(1.68f);
        assertEquals(1.68f, usuario.getAltura(), 0.01);

        usuario.setEdad(30);
        assertEquals(30, usuario.getEdad().intValue());

        usuario.setGenero(Usuario.Genero.MUJER);
        assertEquals(Usuario.Genero.MUJER, usuario.getGenero());

        usuario.setDificultad(Usuario.Dificultad.DIFICIL);
        assertEquals(Usuario.Dificultad.DIFICIL, usuario.getDificultad());
    }

    // Validación de peso y altura positiva
    @Test
    public void testPesoYAlturaPositiva() {
        usuario.setPeso(-50.0f);
        assertTrue("El peso debe ser positivo", usuario.getPeso() > 0);

        usuario.setAltura(-1.50f);
        assertTrue("La altura debe ser positiva", usuario.getAltura() > 0);
    }

    // Validación de edad lógica
    @Test
    public void testEdadLogica() {
        usuario.setEdad(-5);
        assertTrue("La edad debe ser mayor o igual a 0", usuario.getEdad() >= 0);

        usuario.setEdad(150);
        assertTrue("La edad debe ser menor o igual a 120", usuario.getEdad() <= 120);
    }

    // Test de enums Genero y Dificultad
    @Test
    public void testEnums() {
        usuario.setGenero(Usuario.Genero.OTROS);
        assertEquals(Usuario.Genero.OTROS, usuario.getGenero());

        usuario.setDificultad(Usuario.Dificultad.FACIL);
        assertEquals(Usuario.Dificultad.FACIL, usuario.getDificultad());
    }
}
