package com.example.befit.models;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.threeten.bp.LocalTime;

import static org.junit.Assert.*;

public class HistorialesDeUsuarioTest {

    private HistorialesDeUsuario historialesDeUsuario;
    private Historia historia;

    @Before
    public void setUp() {
        // Crear una lista de Ejercicios
        ArrayList<Ejercicio> listaEjercicios = new ArrayList<>();
        Ejercicio ejercicio1 = new Ejercicio("Ejercicio 1", 10, 1001, "Técnica 1", 30.0f);
        Ejercicio ejercicio2 = new Ejercicio("Ejercicio 2", 15, 1002, "Técnica 2", 45.0f);
        listaEjercicios.add(ejercicio1);
        listaEjercicios.add(ejercicio2);

        // Crear la ActividadFisica
        ActividadFisica actividadFisica = new ActividadFisica(
                1,
                listaEjercicios,
                LocalTime.of(9, 0), // Hora de comienzo
                LocalTime.of(9, 30), // Hora máxima
                LocalTime.of(10, 0), // Hora de finalización
                true
        );

        // Crear la lista de imágenes (IDs de recursos)
        ArrayList<Integer> imagenesEjercicios = new ArrayList<>();
        imagenesEjercicios.add(1001);
        imagenesEjercicios.add(1002);

        // Crear la instancia de Historia
        historia = new Historia(
                new Date(),  // Fecha actual
                actividadFisica,
                Historia.EstadoFinalizacion.MEDIO,  // Estado de finalización
                imagenesEjercicios
        );

        // Crear HistorialesDeUsuario con un solo historial
        List<Historia> historialList = new ArrayList<>();
        historialList.add(historia);

        historialesDeUsuario = new HistorialesDeUsuario(1, historialList);
    }

    @Test
    public void testGetIdUsuario() {
        // Verificar que el id del usuario se obtiene correctamente
        assertEquals(1, historialesDeUsuario.getIdUsuario());
    }

    @Test
    public void testSetIdUsuario() {
        historialesDeUsuario.setIdUsuario(2);
        // Verificar que el id del usuario se actualiza correctamente
        assertEquals(2, historialesDeUsuario.getIdUsuario());
    }

    @Test
    public void testGetHistorialUsuario() {
        // Verificar que el historial de usuario se obtiene correctamente
        List<Historia> historial = historialesDeUsuario.getHistorialUsuario();
        assertNotNull(historial);
        assertEquals(1, historial.size());  // Debe tener un solo historial
        assertEquals(historia, historial.get(0));  // Verifica que sea el historial correcto
    }

    @Test
    public void testSetHistorialUsuario() {
        // Crear un nuevo historial para el usuario
        Historia nuevaHistoria = new Historia(
                new Date(),
                new ActividadFisica(2, new ArrayList<>(), LocalTime.of(10, 0), LocalTime.of(10, 30), LocalTime.of(11, 0), true),
                Historia.EstadoFinalizacion.FACIL,
                new ArrayList<>()
        );

        List<Historia> nuevoHistorial = new ArrayList<>();
        nuevoHistorial.add(nuevaHistoria);

        // Actualizar el historial del usuario
        historialesDeUsuario.setHistorialUsuario(nuevoHistorial);

        // Verificar que el historial del usuario se ha actualizado correctamente
        List<Historia> historialActualizado = historialesDeUsuario.getHistorialUsuario();
        assertNotNull(historialActualizado);
        assertEquals(1, historialActualizado.size());
        assertEquals(nuevaHistoria, historialActualizado.get(0));  // Verifica que sea la nueva historia
    }

    @Test
    public void testAddHistoriaToHistorialUsuario() {
        // Crear una nueva Historia
        Historia nuevaHistoria = new Historia(
                new Date(),
                new ActividadFisica(2, new ArrayList<>(), LocalTime.of(10, 0), LocalTime.of(10, 30), LocalTime.of(11, 0), true),
                Historia.EstadoFinalizacion.IMPOSIBLE,
                new ArrayList<>()
        );

        // Añadir la nueva historia al historial
        List<Historia> historial = historialesDeUsuario.getHistorialUsuario();
        historial.add(nuevaHistoria);

        // Verificar que el historial tiene ahora dos historias
        assertEquals(2, historialesDeUsuario.getHistorialUsuario().size());
        assertEquals(nuevaHistoria, historialesDeUsuario.getHistorialUsuario().get(1));  // Verifica que sea la nueva historia añadida
    }
}
