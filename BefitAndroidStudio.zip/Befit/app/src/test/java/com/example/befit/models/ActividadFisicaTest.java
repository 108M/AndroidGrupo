package com.example.befit.models;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import org.threeten.bp.LocalTime;

import static org.junit.Assert.*;

public class ActividadFisicaTest {

    private ActividadFisica actividadFisica;
    private Ejercicio ejercicio1;
    private Ejercicio ejercicio2;
    private ArrayList<Ejercicio> listaEjercicios;

    @Before
    public void setUp() {
        // Crear ejercicios
        ejercicio1 = new Ejercicio("Flexiones", 3, 101, "Mantén la espalda recta y baja lentamente.", 15.0f);
        ejercicio2 = new Ejercicio("Correr", 2, 102, "Corre a un paso rápido.", 30.0f);

        // Crear lista de ejercicios
        listaEjercicios = new ArrayList<>();
        listaEjercicios.add(ejercicio1);
        listaEjercicios.add(ejercicio2);

        // Crear actividad física
        actividadFisica = new ActividadFisica(1, listaEjercicios, LocalTime.of(8, 0), LocalTime.of(9, 30), LocalTime.of(10, 0), true);
    }

    @Test
    public void testConstructorYGetters() {
        assertEquals(1, actividadFisica.getId());
        assertEquals(2, actividadFisica.getSizeListaEjercicios());
        assertEquals(LocalTime.of(8, 0), actividadFisica.getHoraComienzoActividad());
        assertEquals(LocalTime.of(9, 30), actividadFisica.getHoraMaximaActividad());
        assertEquals(LocalTime.of(10, 0), actividadFisica.getHoraFinalizacionActividad());
        assertTrue(actividadFisica.getEstado());
    }

    @Test
    public void testAñadirEjercicio() {
        Ejercicio ejercicio3 = new Ejercicio("Abdominales", 2, 103, "Realiza movimientos lentos.", 10.0f);
        actividadFisica.añadirEjercicio(ejercicio3);

        assertEquals(3, actividadFisica.getSizeListaEjercicios());
    }

    @Test
    public void testSetEstado() {
        // Cambiar el estado de la actividad
        actividadFisica.setEstado(false);
        assertFalse(actividadFisica.getEstado());
    }

    @Test
    public void testTiempos() {
        // Comprobar que las horas se asignan correctamente
        assertEquals(LocalTime.of(8, 0), actividadFisica.getHoraComienzoActividad());
        assertEquals(LocalTime.of(9, 30), actividadFisica.getHoraMaximaActividad());
        assertEquals(LocalTime.of(10, 0), actividadFisica.getHoraFinalizacionActividad());
    }

    @Test
    public void testGetListaEjercicios() {
        // Verificamos que se recupera correctamente la lista de ejercicios
        assertNotNull(actividadFisica.getListaEjercicios());
        assertEquals(2, actividadFisica.getListaEjercicios().size());
    }

    @Test
    public void testSetHoraMaximaActividad() {
        // Cambiar la hora máxima de actividad y comprobarlo
        actividadFisica.setHoraMaximaActividad(LocalTime.of(9, 0));
        assertEquals(LocalTime.of(9, 0), actividadFisica.getHoraMaximaActividad());
    }

    @Test
    public void testSetHoraComienzoActividad() {
        // Cambiar la hora de comienzo de actividad
        actividadFisica.setHoraComienzoActividad(LocalTime.of(7, 0));
        assertEquals(LocalTime.of(7, 0), actividadFisica.getHoraComienzoActividad());
    }

    @Test
    public void testSetHoraFinalizacionActividad() {
        // Cambiar la hora de finalización de la actividad
        actividadFisica.setHoraFinalizacionActividad(LocalTime.of(11, 0));
        assertEquals(LocalTime.of(11, 0), actividadFisica.getHoraFinalizacionActividad());
    }
}
