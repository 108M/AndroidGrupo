package com.example.befit.models;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class EjercicioTest {

    private Ejercicio ejercicio;

    @Before
    public void setUp() {
        ejercicio = new Ejercicio("Flexiones", 3, 101, "Mantén la espalda recta y baja lentamente.", 30.0f);
    }

    @Test
    public void testGetters() {
        assertEquals("Flexiones", ejercicio.getNombreEjercicio());
        assertEquals(Integer.valueOf(3), ejercicio.getIntensidad());
        assertEquals(101, ejercicio.getImageResId());
        Ejercicio ejercicio = new Ejercicio("Flexiones", 5, 123, "Mantén la espalda recta y baja lentamente.", 30.0f);
        assertEquals("Mantén la espalda recta y baja lentamente.", ejercicio.getTecnica());
        assertEquals(30.0f, ejercicio.getTiempoMax(), 0.01);
    }

    @Test
    public void testSetters() {
        ejercicio.setNombreEjercicio("Dominadas");
        ejercicio.setIntensidad(5);
        ejercicio.setImageResId(202);
        ejercicio.setTecnica("Usa todo tu rango de movimiento.");
        ejercicio.setTiempoMax(45.0f);

        assertEquals("Dominadas", ejercicio.getNombreEjercicio());
        assertEquals(Integer.valueOf(5), ejercicio.getIntensidad());
        assertEquals(202, ejercicio.getImageResId());
        assertEquals("Usa todo tu rango de movimiento.", ejercicio.getTecnica());
        assertEquals(45.0f, ejercicio.getTiempoMax(), 0.01);
    }

    @Test
    public void testIntensidadNegativa() {
        ejercicio.setIntensidad(-1);
        assertEquals(Integer.valueOf(0), ejercicio.getIntensidad());
    }

    @Test
    public void testTiempoMaxNegativo() {
        ejercicio.setTiempoMax(-10.0f);
        assertEquals(0.0f, ejercicio.getTiempoMax(), 0.01);
    }
}
