package modelos;

import java.time.LocalTime;
import java.util.ArrayList;

public class ActividadFisica {
    private String objectId;
    private ArrayList<String> listaEjerciciosIds;
    private String horaComienzoActividad; // Usar String en lugar de LocalTime
    private String horaMaximaActividad;   // Usar String en lugar de LocalTime
    private String horaFinalizacionActividad; // Usar String en lugar de LocalTime
    private Boolean estado;

    public ActividadFisica(ArrayList<String> listaEjerciciosIds, LocalTime horaComienzoActividad,
                           LocalTime horaMaximaActividad, LocalTime horaFinalizacionActividad, Boolean estado) {
        this.listaEjerciciosIds = listaEjerciciosIds;
        this.horaComienzoActividad = horaComienzoActividad.toString(); // Convertir a String
        this.horaMaximaActividad = horaMaximaActividad.toString();     // Convertir a String
        this.horaFinalizacionActividad = horaFinalizacionActividad.toString(); // Convertir a String
        this.estado = estado;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public ArrayList<String> getListaEjerciciosIds() {
        return listaEjerciciosIds;
    }

    public void setListaEjerciciosIds(ArrayList<String> listaEjerciciosIds) {
        if (listaEjerciciosIds == null || listaEjerciciosIds.isEmpty()) {
            throw new IllegalArgumentException("La lista de ejercicios no puede ser vacía.");
        }
        this.listaEjerciciosIds = listaEjerciciosIds;
    }

    public String getHoraComienzoActividad() {
        return horaComienzoActividad;
    }

    public void setHoraComienzoActividad(String horaComienzoActividad) {
        if (horaComienzoActividad == null || horaComienzoActividad.trim().isEmpty()) {
            throw new IllegalArgumentException("La hora de comienzo no puede estar vacía.");
        }
        this.horaComienzoActividad = horaComienzoActividad;
    }

    public String getHoraMaximaActividad() {
        return horaMaximaActividad;
    }

    public void setHoraMaximaActividad(String horaMaximaActividad) {
        if (horaMaximaActividad == null || horaMaximaActividad.trim().isEmpty()) {
            throw new IllegalArgumentException("La hora máxima de actividad no puede estar vacía.");
        }
        this.horaMaximaActividad = horaMaximaActividad;
    }

    public String getHoraFinalizacionActividad() {
        return horaFinalizacionActividad;
    }

    public void setHoraFinalizacionActividad(String horaFinalizacionActividad) {
        if (horaFinalizacionActividad == null || horaFinalizacionActividad.trim().isEmpty()) {
            throw new IllegalArgumentException("La hora de finalización no puede estar vacía.");
        }
        this.horaFinalizacionActividad = horaFinalizacionActividad;
    }

    public Boolean getEstado() {
        return estado;
    }

    public void setEstado(Boolean estado) {
        if (estado == null) {
            throw new IllegalArgumentException("El estado no puede ser null.");
        }
        this.estado = estado;
    }

   
}