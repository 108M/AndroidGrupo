package vista;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Markel
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import modelos.*;
import dao.*;
import java.io.File;
import java.time.LocalTime;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class ModeloAplicacionBefit extends JFrame {
    private JButton btnCrearUsuario;
    private JTextField txtNombre, txtPeso, txtAltura, txtEdad;
    private JComboBox<String> comboGenero, comboIntensidad;
    private JButton btnElegirEjercicio, btnFinalizar, btnConsultarHistorial;
    private JLabel lblEjercicio, lblRepeticiones, lblCuentaRegresiva;
    private Timer timer;
    private int tiempoRestante;
    private String ejercicioActual;
    private int repeticionesActuales;
    private UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
    private EjercicioDAO ejercicioDAO = new EjercicioDAOImpl();
    private ActividadFisicaDAO actividadFisicaDAO = new ActividadFisicaDAOImpl();
    private HistoriaDAO historiaDAO = new HistoriaDAOImpl();
    private HistorialesDeUsuarioDAO historialesDeUsuarioDAO = new HistorialesDeUsuarioDAOImpl();

    private DefaultListModel<String> listModelUsuarios = new DefaultListModel<>();
    private Usuario usuarioActual;
    private List<Ejercicio> ejerciciosDisponibles = new ArrayList<>();
    private List<String> historialEjercicios = new ArrayList<>();

    public ModeloAplicacionBefit() {
        setTitle("BeFit");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel panelInicio = new JPanel();
        btnCrearUsuario = new JButton("Crear Usuario");
        panelInicio.add(btnCrearUsuario);
        add(panelInicio, BorderLayout.CENTER);

        btnCrearUsuario.addActionListener(e -> mostrarFormularioUsuario());
    }

    public void mostrarFormularioUsuario() {
        getContentPane().removeAll();
        JPanel panelUsuario = new JPanel(new GridLayout(6, 2));
        panelUsuario.setBorder(BorderFactory.createTitledBorder("Crear Usuario"));

        panelUsuario.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelUsuario.add(txtNombre);

        panelUsuario.add(new JLabel("Peso (kg):"));
        txtPeso = new JTextField();
        panelUsuario.add(txtPeso);

        panelUsuario.add(new JLabel("Altura (m):"));
        txtAltura = new JTextField();
        panelUsuario.add(txtAltura);

        panelUsuario.add(new JLabel("Edad:"));
        txtEdad = new JTextField();
        panelUsuario.add(txtEdad);

        panelUsuario.add(new JLabel("Género:"));
        comboGenero = new JComboBox<>(new String[]{"Masculino", "Femenino"});
        panelUsuario.add(comboGenero);

        btnElegirEjercicio = new JButton("Crear Usuario");
        btnElegirEjercicio.addActionListener(e -> crearUsuario());
        panelUsuario.add(btnElegirEjercicio);

        add(panelUsuario, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private void crearUsuario() {
        String nombre = txtNombre.getText();
        float peso = Float.parseFloat(txtPeso.getText());
        float altura = Float.parseFloat(txtAltura.getText());
        int edad = Integer.parseInt(txtEdad.getText());
        String generoStr = (String) comboGenero.getSelectedItem();
        Usuario.Genero genero = generoStr.equals("Masculino") ? Usuario.Genero.HOMBRE : Usuario.Genero.MUJER;

        Usuario usuario = new Usuario(nombre, peso, altura, edad, genero);
        usuarioDAO.crearUsuario(usuario);
        usuarioActual = usuario;
        listModelUsuarios.addElement(nombre + " - ObjectId: " + usuario.getObjectId());

        mostrarSeleccionIntensidad();
    }

    public void mostrarSeleccionIntensidad() {
        inicializarEjercicios();

        getContentPane().removeAll();
        JPanel panelIntensidad = new JPanel();
        panelIntensidad.setBorder(BorderFactory.createTitledBorder("Seleccionar Intensidad"));
        comboIntensidad = new JComboBox<>(new String[]{"Fácil", "Medio", "Difícil"});
        btnElegirEjercicio = new JButton("Elegir Ejercicio");
        btnElegirEjercicio.addActionListener(e -> asignarEjercicio());

        panelIntensidad.add(comboIntensidad);
        panelIntensidad.add(btnElegirEjercicio);
        add(panelIntensidad, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private void inicializarEjercicios() {
    ejerciciosDisponibles = ejercicioDAO.obtenerTodosLosEjercicios(); 

    if (ejerciciosDisponibles.isEmpty()) {
        ejerciciosDisponibles.add(new Ejercicio("Flexiones", 3, null, "Técnica básica", 30));
        ejerciciosDisponibles.add(new Ejercicio("Burpees", 4, null, "Ejercicio intenso", 30));
        ejerciciosDisponibles.add(new Ejercicio("Sentadillas", 3, null, "Ejercicio de piernas", 30));

        for (Ejercicio e : ejerciciosDisponibles) {
            ejercicioDAO.crearEjercicio(e);
        }
        // Recargar la lista desde la base de datos para asegurarnos de que tiene datos
        ejerciciosDisponibles = ejercicioDAO.obtenerTodosLosEjercicios();
    }

    // Verificar qué ejercicios hay en la lista
    System.out.println("Ejercicios disponibles:");
    for (Ejercicio e : ejerciciosDisponibles) {
        System.out.println("- " + e.getNombre());
    }
}

private void asignarEjercicio() {
    if (ejerciciosDisponibles.isEmpty()) {
        System.out.println("Error: No hay ejercicios disponibles.");
        return;
    }

    // Escoger un ejercicio aleatorio asegurándonos de que la lista no está vacía
    int index = (int) (Math.random() * ejerciciosDisponibles.size());
    Ejercicio ejercicioSeleccionado = ejerciciosDisponibles.get(index);

    if (ejercicioSeleccionado == null) {
        System.out.println("Error: Se seleccionó un ejercicio nulo.");
        return;
    }

    String ejercicioNombre = ejercicioSeleccionado.getNombre();
    int repeticiones = (int) (Math.random() * 10 + 5);

    // Debug: verificar qué ejercicio se seleccionó
    System.out.println("Ejercicio seleccionado: " + ejercicioNombre);

    mostrarEjercicio(ejercicioNombre, repeticiones, 30);
    }

    public void mostrarEjercicio(String ejercicio, int repeticiones, int tiempo) {
        getContentPane().removeAll();
        JPanel panelEjercicio = new JPanel(new GridLayout(5, 1));
        panelEjercicio.setBorder(BorderFactory.createTitledBorder("Ejercicio"));

        lblEjercicio = new JLabel("Ejercicio: " + ejercicio);
        lblRepeticiones = new JLabel("Repeticiones: " + repeticiones);
        lblCuentaRegresiva = new JLabel("Tiempo restante: " + tiempo + "s");
        btnFinalizar = new JButton("Finalizar");
        btnConsultarHistorial = new JButton("Consultar Historial");

        btnFinalizar.addActionListener(e -> finalizarEjercicio());
        btnConsultarHistorial.addActionListener(e -> mostrarHistorial());

        panelEjercicio.add(lblEjercicio);
        panelEjercicio.add(lblRepeticiones);
        panelEjercicio.add(lblCuentaRegresiva);
        panelEjercicio.add(btnFinalizar);
        panelEjercicio.add(btnConsultarHistorial);

        add(panelEjercicio, BorderLayout.CENTER);
        revalidate();
        repaint();
        tiempoRestante = tiempo;
        iniciarCuentaRegresiva();
    }

    private void finalizarEjercicio() {
        if (timer != null) timer.cancel();
        JOptionPane.showMessageDialog(this, "Ejercicio " + ejercicioActual + " finalizado con " + repeticionesActuales + " repeticiones.");
        guardarEnHistorial(ejercicioActual, repeticionesActuales);
        asignarEjercicio();
    }
    

    private void guardarEnHistorial(String ejercicio, int repeticiones) {
        String registro = ejercicio + " - " + repeticiones + " reps - " + new java.util.Date();
        historialEjercicios.add(registro);

        List<Ejercicio> e = ejercicioDAO.obtenerTodosLosEjercicios();
        ArrayList<String> ejerciciosIds = new ArrayList<>();
        ejerciciosIds.add("prueba-1");

        ActividadFisica actividadFisica = new ActividadFisica(
            ejerciciosIds,
            LocalTime.now(),
            LocalTime.now().plusMinutes(1),
            LocalTime.now().plusMinutes(2),
            false
        );
        actividadFisicaDAO.crearActividadFisica(actividadFisica);

        /*Historia historia = new Historia(
            new Date(),
            actividadFisica.getObjectId(),
            Historia.estadoFinalizacion.MEDIO,
            new ArrayList<>()
        );
        historiaDAO.crearHistoria(historia);*/
        
        
        File imagenFile = new File("prueba.png");
        Historia historia = new Historia(new Date(), actividadFisica.getObjectId(), Historia.estadoFinalizacion.MEDIO, 
                                           null, 0, 0);
        historiaDAO.crearHistoria(historia, imagenFile);

        HistorialesDeUsuario historialExistente = historialesDeUsuarioDAO.obtenerHistorialDeUsuarioPorIdUsuario(usuarioActual.getObjectId());
        if (historialExistente != null) {
            historialExistente.getHistorialUsuarioIds().add(historia.getObjectId());
            //historialesDeUsuarioDAO.actualizarHistorial(historialExistente);
        } else {
            ArrayList<String> historiasIds = new ArrayList<>();
            historiasIds.add(historia.getObjectId());
            HistorialesDeUsuario historial = new HistorialesDeUsuario(usuarioActual.getObjectId(), historiasIds);
            historialesDeUsuarioDAO.crearHistorialDeUsuario(historial);
        }
    }

    private void mostrarHistorial() {
        getContentPane().removeAll();
        JPanel panelHistorial = new JPanel(new BorderLayout());
        panelHistorial.setBorder(BorderFactory.createTitledBorder("Historial de Ejercicios"));

        DefaultListModel<String> historialListModel = new DefaultListModel<>();
        for (String registro : historialEjercicios) {
            historialListModel.addElement(registro);
        }

        JList<String> listaHistorial = new JList<>(historialListModel);
        JScrollPane scrollPane = new JScrollPane(listaHistorial);

        JButton btnVolver = new JButton("Volver");
        btnVolver.addActionListener(e -> mostrarSeleccionIntensidad());

        panelHistorial.add(scrollPane, BorderLayout.CENTER);
        panelHistorial.add(btnVolver, BorderLayout.SOUTH);

        add(panelHistorial, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private void iniciarCuentaRegresiva() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (tiempoRestante > 0) {
                    tiempoRestante--;
                    lblCuentaRegresiva.setText("Tiempo restante: " + tiempoRestante + "s");
                } else {
                    timer.cancel();
                    SwingUtilities.invokeLater(() -> {
                        finalizarEjercicio();
                    });
                }
            }
        }, 1000, 1000);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ModeloAplicacionBefit().setVisible(true));
    }
}

