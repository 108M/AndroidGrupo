package modelos;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import modelos.Historia;
import modelos.Historia.estadoFinalizacion;
import java.util.ArrayList;
import java.util.Date;

public class HistoriaTest {
    private Historia historia;

    @BeforeEach
    public void setUp() {
        ArrayList<String> imagenes = new ArrayList<>();
        imagenes.add("path/imagen1.png");
        imagenes.add("path/imagen2.png");
        
        historia = new Historia(new Date(), "actividad123", estadoFinalizacion.MEDIO, imagenes);
    }

    @Test
    public void testCreacionCorrecta() {
        assertNotNull(historia.getFecha());
        assertEquals("actividad123", historia.getActividadRegistradaId());
        assertEquals(estadoFinalizacion.MEDIO, historia.getEstadoFinalizacion());
        assertEquals(2, historia.getImagenesEjerciciosPaths().size());
        assertEquals("path/imagen1.png", historia.getImagenesEjerciciosPaths().get(0));
    }

    @Test
    public void testActividadRegistradaIdNoVacio() {
        assertThrows(IllegalArgumentException.class, () -> {
            historia.setActividadRegistradaId("");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            historia.setActividadRegistradaId(null);
        });
    }

    @Test
    public void testEstadoFinalizacionValido() {
        assertThrows(IllegalArgumentException.class, () -> {
            historia.setEstadoFinalizacion(null);  // Estado finalización no puede ser null
        });
    }

    @Test
    public void testImagenesEjerciciosPathsNoVacias() {
        ArrayList<String> imagenesInvalidas = new ArrayList<>();
        assertThrows(IllegalArgumentException.class, () -> {
            historia.setImagenesEjerciciosPaths(imagenesInvalidas);
        });
        
        imagenesInvalidas.add(""); // Imagen vacía
        assertThrows(IllegalArgumentException.class, () -> {
            historia.setImagenesEjerciciosPaths(imagenesInvalidas);
        });
    }

    @Test
    public void testFechaNoNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            historia.setFecha(null);
        });
    }
}
