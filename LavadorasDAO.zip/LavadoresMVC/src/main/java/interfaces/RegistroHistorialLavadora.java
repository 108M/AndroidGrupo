/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import java.util.ArrayList;
import java.util.List;
import lavadoras.modelos.EstadoLavadora;

/**
 *
 * @author Markel
 */
public class RegistroHistorialLavadora implements interfaceEstadoLavadora{
    
    private List <EstadoLavadora> historialEstados;

    public RegistroHistorialLavadora() {
        this.historialEstados = new ArrayList<>(); // Inicializar la lista
    }
    
    @Override
    public List<EstadoLavadora> getHistorialEstados() {
        return historialEstados;
    }
    
    public void añadirEstado (EstadoLavadora estado)
    {
        this.historialEstados.add(estado);
    }
    
    @Override
    public void setHistorialEstados(ArrayList<EstadoLavadora> historialEstados) {
        this.historialEstados = historialEstados;
    }
    
    @Override
    public ArrayList<EstadoLavadora> buscarEstadosLavadoraPorId(String id) {
        ArrayList<EstadoLavadora> estadoDev = new ArrayList<>();
        for (EstadoLavadora estado : historialEstados) {
            if (estado.getId().equals(id)) {
                estadoDev.add(estado);
            }
        } 
        return estadoDev;
    }

}
