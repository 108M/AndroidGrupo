/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import java.util.ArrayList;
import java.util.List;
import lavadoras.modelos.EstadoPedido;
import lavadoras.modelos.EstadoPedido.Prenda;
import lavadoras.modelos.EstadoPedido.Programa;
import lavadoras.modelos.Pedido;

/**
 *
 * @author Markel
 */
public class DirectorioPedidos implements interfacePedido{
    private List<Pedido> pedidos;
    
    public DirectorioPedidos(List<Pedido> lavadoras) {
        this.pedidos = new ArrayList<>(); // Inicializar la lista
    }
    
    @Override
    public List<Pedido> getPedidos() {
        return pedidos;
    }
    
    
    @Override
    public void agregarPedido(String id,String direccion, String comentario, EstadoPedido estadoInicial) {
        pedidos.add(new Pedido(id, estadoInicial, direccion,comentario));
    }
    
    
    @Override
    public Pedido buscarPedidoPorId(String id) {
        for (Pedido pedido : pedidos) {
            if (pedido.getId().equals(id)) {
                return pedido;
            }
        } 
        return null;
    }
    
}
