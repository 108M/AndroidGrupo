/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

import java.util.ArrayList;
import java.util.List;
import lavadoras.modelos.EstadoLavadora;

/**
 *
 * @author Markel
 */
public interface interfaceEstadoLavadora {
    
    public List<EstadoLavadora> getHistorialEstados();
    public void setHistorialEstados(ArrayList<EstadoLavadora> historialEstados);
    public ArrayList<EstadoLavadora> buscarEstadosLavadoraPorId(String id);
    
}
