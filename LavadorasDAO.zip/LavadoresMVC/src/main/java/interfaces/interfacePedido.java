/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

import java.util.List;
import lavadoras.modelos.EstadoPedido;
import lavadoras.modelos.Pedido;

/**
 *
 * @author Markel
 */
public interface interfacePedido {
    
    public void agregarPedido(String id, String localizacion,String comentario, EstadoPedido estadoInicial);
    
    public List<Pedido> getPedidos();
     public Pedido buscarPedidoPorId(String id);   
}
