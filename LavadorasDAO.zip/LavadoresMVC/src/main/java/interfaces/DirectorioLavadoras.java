/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import lavadoras.modelos.EstadoLavadora;
import lavadoras.modelos.Lavadora;
import lavadoras.modelos.Pedido;

/**
 *
 * @author Markel
 */
public class DirectorioLavadoras implements interfaceLavadora {
    private List<Lavadora> lavadoras;

    public DirectorioLavadoras(List<Lavadora> lavadoras) {
        this.lavadoras = lavadoras;
    }
    
    
    @Override
    public void agregarLavadora(String id, float[] localizacion, EstadoLavadora estadoInicial) {
        lavadoras.add(new Lavadora(id, localizacion, new ArrayList<>(),estadoInicial));
    }
     
    @Override
      public List<Lavadora> getLavadoras() {
        return lavadoras;
    }

    @Override
    public Lavadora buscarLavadoraPorId(String id) {
        for (Lavadora lavadora : lavadoras) {
            if (lavadora.getId().equals(id)) {
                return lavadora;
            }
        } 
        return null;
    }
     
    //AÑADIR SI ESO ACTUALIZAR LAVAODRAS
}
