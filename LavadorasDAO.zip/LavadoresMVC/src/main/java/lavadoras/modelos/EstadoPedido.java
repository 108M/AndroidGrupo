package lavadoras.modelos;

import java.util.ArrayList;
import java.util.List;

public class EstadoPedido {
    public enum Programa {
        FRIO, MIXTO, ALGODON, DELICADO
    }

    public enum Prenda {
        JERSEY, VAQUERO, ABRIGO, CAMISA, TOP, AMERICANA, CHANDAL,
        ROPA_DEPORTIVA_MUJER, PARKA, ROPA_INTERIOR_MUJER, ALBORNOZ, CALCETIN
    }

    private String nombre;
    private Programa programa;
    private int peso;
    private List<Prenda> prendas;
    private String fecha;

    public EstadoPedido(String nombre, Programa programa, int peso, List<Prenda> prendas, String fecha) {
        this.nombre = nombre;
        this.programa = programa;
        this.peso = peso;
        this.prendas = prendas;
        this.fecha = fecha;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Programa getPrograma() {
        return programa;
    }

    public void setPrograma(Programa programa) {
        this.programa = programa;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public List<Prenda> getPrendas() {
        return prendas;
    }

    public void setPrendas(List<Prenda> prendas) {
        this.prendas = prendas;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
}
