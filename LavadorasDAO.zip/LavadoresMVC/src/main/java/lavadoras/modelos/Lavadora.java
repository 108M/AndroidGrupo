/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lavadoras.modelos;
import interfaces.interfaceLavadora;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Markel
 */
public class Lavadora{
   
    private String id;
    private float[] localizacion;
    private List<EstadoLavadora> historialEstados;
    private EstadoLavadora estadoActual;
    
    
    public Lavadora(String id, float[] localizacion, List<EstadoLavadora> historialEstados, EstadoLavadora estadoActual) {
            this.id = id;
            this.localizacion = localizacion;
            this.historialEstados = historialEstados;
            this.estadoActual = estadoActual;
    }
    
    public String getId() {
        return id;
    }

    public float[] getLocalizacion() {
        return localizacion;
    }


    public EstadoLavadora getEstadoActual() {
        return estadoActual;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setLocalizacion(float[] localizacion) {
        this.localizacion = localizacion;
    }


    public void setEstado_actual(EstadoLavadora estado_actual) {
        this.estadoActual = estado_actual;
    }

    
    public String getID() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   
    public void agregarLavadora(String id, float[] localizacion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
    public List<Lavadora> getLavadoras() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Lavadora buscarLavadoraPorId(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

  
    
    
}
