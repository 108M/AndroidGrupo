/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lavadoras.modelos;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Markel
 */
public class EstadoLavadora{
    
    private String id;
    Date fecha;
    private float[] motor = new float[3];
    private ArrayList cuba;

    public EstadoLavadora(String id,Date fecha, float[] motor, ArrayList cuba) {
        this.id = id;
        this.motor = motor;
        this.fecha = fecha;
        this.cuba = cuba;
    }

    public String getId() {
        return id;
    }

    public Date getFecha() {
        return fecha;
    }

    public float[] getMotor() {
        return motor;
    }

    public ArrayList getCuba() {
        return cuba;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void setMotor(float[] motor) {
        this.motor = motor;
    }

    public void setCuba(ArrayList cuba) {
        this.cuba = cuba;
    }
    
}
