/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lavadoras.modelos;

/**
 *
 * @author Markel
 */
public class Pedido {
    private String id;
    private EstadoPedido estado;
    private String direccion;
    private String comentarios;

    public Pedido(String id,EstadoPedido estado, String direccion, String comentarios) {
        this.id = id;
        this.estado = estado;
        this.direccion = direccion;
        this.comentarios = comentarios;
    }

    public EstadoPedido getEstado() {
        return estado;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getId() {
        return id;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setEstado(EstadoPedido estado) {
        this.estado = estado;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }
    
    
    
}
