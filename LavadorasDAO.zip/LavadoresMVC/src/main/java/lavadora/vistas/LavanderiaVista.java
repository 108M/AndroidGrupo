/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lavadora.vistas;

import interfaces.DirectorioPedidos;
import interfaces.RegistroHistorialLavadora;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import lavadora.LavanderiaControlador;
import interfaces.interfaceEstadoLavadora;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import javax.swing.JCheckBox;
import lavadoras.modelos.EstadoPedido;
import lavadoras.modelos.Lavadora;
import lavadoras.modelos.Pedido;

/**
 *
 * @author Markel
 */
public class LavanderiaVista extends JFrame {
    private LavanderiaControlador controlador;
    private JPanel mainPanel, menuPanel, lavadorasPanel;
    private CardLayout cardLayout;
    private JTextArea displayLavadoras;
    private JTextField idField, locXField, locYField;
    private JComboBox<String> lavadorasComboBox;
    private JTextArea display;
    private RegistroHistorialLavadora estadoLavadoras;
    private JPanel pedidosPanel;
    private JTextArea displayPedidos;
    private JTextField pedidoIdField;
    private JTextField pedidoDireccionField;
    private JTextField pedidoComentariosField;
    private DirectorioPedidos pedidos;
    private JComboBox<String> pedidosComboBox;
    private JButton verEstadoPedidoButton;
    
    public LavanderiaVista(LavanderiaControlador controlador) {
        this.controlador = controlador;
        System.out.println(controlador.getHistorialLavadora());
        this.estadoLavadoras = controlador.getHistorialLavadora();
        
        setTitle("Lavandería App");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        add(mainPanel, BorderLayout.CENTER);

        crearMenuInicial();
        crearPanelLavadoras();
        crearPanelPedidos();
        cardLayout.show(mainPanel, "MENU");
    }

    private void crearMenuInicial() {
        menuPanel = new JPanel();
        menuPanel.setLayout(new GridLayout(2, 1, 10, 10));

        JButton lavadorasButton = new JButton("Gestionar Lavadoras");
        lavadorasButton.addActionListener(e -> {
            actualizarListaLavadoras();
            cardLayout.show(mainPanel, "LAVADORAS");
        });

        JButton pedidosButton = new JButton("Gestionar Pedidos");
        pedidosButton.addActionListener(e -> {
            actualizarListaPedidos();
            cardLayout.show(mainPanel, "PEDIDOS");
         });
        menuPanel.add(lavadorasButton);
        menuPanel.add(pedidosButton);

        mainPanel.add(menuPanel, "MENU");
    }

    private void crearPanelLavadoras() {
        lavadorasPanel = new JPanel(new BorderLayout());

        // Área de visualización de lavadoras
        displayLavadoras = new JTextArea();
        lavadorasPanel.add(new JScrollPane(displayLavadoras), BorderLayout.CENTER);

        // Panel de botones y formularios
        JPanel accionesPanel = new JPanel(new GridLayout(4, 2, 5, 5));

        accionesPanel.add(new JLabel("ID Lavadora:"));
        idField = new JTextField();
        accionesPanel.add(idField);

        accionesPanel.add(new JLabel("Localización X:"));
        locXField = new JTextField();
        accionesPanel.add(locXField);

        accionesPanel.add(new JLabel("Localización Y:"));
        locYField = new JTextField();
        accionesPanel.add(locYField);

        JButton addButton = new JButton("Agregar Lavadora");
        addButton.addActionListener(e -> agregarLavadora());
        accionesPanel.add(addButton);

        lavadorasPanel.add(accionesPanel, BorderLayout.NORTH);

        // Botón para ver historial de una lavadora
        JPanel historialPanel = new JPanel(new FlowLayout());

        lavadorasComboBox = new JComboBox<>();
        historialPanel.add(lavadorasComboBox);

        JButton verHistorialButton = new JButton("Ver Historial");
        verHistorialButton.addActionListener(e -> verHistorialLavadora());
        historialPanel.add(verHistorialButton);

        JButton volverMenuButton = new JButton("Volver al Menú");
        volverMenuButton.addActionListener(e -> cardLayout.show(mainPanel, "MENU"));
        historialPanel.add(volverMenuButton);

        lavadorasPanel.add(historialPanel, BorderLayout.SOUTH);

        mainPanel.add(lavadorasPanel, "LAVADORAS");
    }
    private void agregarLavadora() {
        String id = idField.getText();
        try {
            float locX = Float.parseFloat(locXField.getText());
            float locY = Float.parseFloat(locYField.getText());

            controlador.agregarLavadora(id, new float[]{locX, locY});
            actualizarListaLavadoras();

            idField.setText("");
            locXField.setText("");
            locYField.setText("");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese valores numéricos válidos para la localización.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public void mostrarLavadoras(List<Lavadora> lavadoras) {
    StringBuilder texto = new StringBuilder();
    for (Lavadora lavadora : lavadoras) {
        texto.append("Lavadora: ").append(lavadora.getId()).append("\n")
             .append("Estado actual: ").append(lavadora.getEstadoActual().getFecha()).append("\n\n");
    }
    displayLavadoras.setText(texto.toString()); // Asegurando que se usa la variable correcta
    }
    private void actualizarListaLavadoras() {
        List<Lavadora> lavadoras = controlador.getLavadoras();
        StringBuilder texto = new StringBuilder();
        lavadorasComboBox.removeAllItems();

        for (Lavadora lavadora : lavadoras) {
            texto.append("Lavadora: ").append(lavadora.getId()).append("\n")
                 .append("Localización: (").append(lavadora.getLocalizacion()[0]).append(", ")
                 .append(lavadora.getLocalizacion()[1]).append(")\n")
                 .append("Última actualización: ").append(lavadora.getEstadoActual().getFecha()).append("\n\n");

            lavadorasComboBox.addItem(lavadora.getId());
        }

        displayLavadoras.setText(texto.toString());
    }
    private void verHistorialLavadora() {
        String idSeleccionado = (String) lavadorasComboBox.getSelectedItem();
        if (idSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "Seleccione una lavadora.");
            return;
        }

        Lavadora lavadora = controlador.buscarLavadoraPorId(idSeleccionado);
        if (lavadora == null) {
            JOptionPane.showMessageDialog(this, "Lavadora no encontrada.");
            return;
        }

        StringBuilder historialTexto = new StringBuilder("Historial de " + lavadora.getId() + ":\n");
        for (var estado : estadoLavadoras.getHistorialEstados()) {
            historialTexto.append("- ").append(estado.getFecha()).append("\n");
        }

        JOptionPane.showMessageDialog(this, historialTexto.toString(), "Historial de Lavadora", JOptionPane.INFORMATION_MESSAGE);
    }
    
    
    private void crearPanelPedidos() {
    pedidosPanel = new JPanel(new BorderLayout());

    // Área de visualización de pedidos
    displayPedidos = new JTextArea();
    pedidosPanel.add(new JScrollPane(displayPedidos), BorderLayout.CENTER);

    // Panel de entrada de datos
    JPanel accionesPanel = new JPanel(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5); // Espaciado entre componentes
    gbc.anchor = GridBagConstraints.WEST; // Alinear a la izquierda
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.gridx = 0;
    gbc.gridy = 0;

    accionesPanel.add(new JLabel("ID Pedido:"), gbc);
    gbc.gridx = 1;
    gbc.weightx = 1.0;
    pedidoIdField = new JTextField(15);
    accionesPanel.add(pedidoIdField, gbc);

    gbc.gridx = 0;
    gbc.gridy = 1;
    gbc.weightx = 0;
    accionesPanel.add(new JLabel("Asignar Dirección:"), gbc);
    gbc.gridx = 1;
    gbc.weightx = 1.0;
    pedidoDireccionField = new JTextField(15);
    accionesPanel.add(pedidoDireccionField, gbc);

    gbc.gridx = 0;
    gbc.gridy = 2;
    accionesPanel.add(new JLabel("Comentarios:"), gbc);
    gbc.gridx = 1;
    pedidoComentariosField = new JTextField(15);
    accionesPanel.add(pedidoComentariosField, gbc);

    // Botón para agregar pedido
    gbc.gridx = 0;
    gbc.gridy = 3;
    gbc.gridwidth = 2;
    gbc.anchor = GridBagConstraints.CENTER;
    JButton addPedidoButton = new JButton("Agregar Pedido");
    addPedidoButton.addActionListener(e -> agregarPedido());
    accionesPanel.add(addPedidoButton, gbc);

    pedidosPanel.add(accionesPanel, BorderLayout.NORTH);

    // Panel para selección y visualización del estado de pedidos
    JPanel controlPanel = new JPanel(new FlowLayout());

    pedidosComboBox = new JComboBox<>();
    controlPanel.add(pedidosComboBox);

    verEstadoPedidoButton = new JButton("Ver Estado");
    verEstadoPedidoButton.addActionListener(e -> verEstadoPedido());
    controlPanel.add(verEstadoPedidoButton);

    JButton volverMenuButton = new JButton("Volver al Menú");
    volverMenuButton.addActionListener(e -> cardLayout.show(mainPanel, "MENU"));
    controlPanel.add(volverMenuButton);

    pedidosPanel.add(controlPanel, BorderLayout.SOUTH);

    mainPanel.add(pedidosPanel, "PEDIDOS");
}

    private void actualizarListaPedidos() {
        List<Pedido> pedidos = controlador.getPedidos();
        StringBuilder texto = new StringBuilder();

        pedidosComboBox.removeAllItems();

        for (Pedido pedido : pedidos) {
            texto.append("Pedido: ").append(pedido.getId()).append("    ")
                 .append("Dirección: ").append(pedido.getDireccion()).append("   ")
                 .append("Comentarios: ").append(pedido.getComentarios()).append("\n\n");

            pedidosComboBox.addItem(pedido.getId()); // Agregar al ComboBox
        }

        displayPedidos.setText(texto.toString());
    }

    private void verEstadoPedido() {
        String idSeleccionado = (String) pedidosComboBox.getSelectedItem();
        if (idSeleccionado == null) {
            JOptionPane.showMessageDialog(this, "Seleccione un pedido.");
            return;
        }

        Pedido pedido = controlador.buscarPedidoPorId(idSeleccionado);
        if (pedido == null || pedido.getEstado() == null) {
            JOptionPane.showMessageDialog(this, "No se encontró el pedido o no tiene un estado asignado.");
            return;
        }

        EstadoPedido estado = pedido.getEstado();

        // Construir mensaje con detalles del estado
        StringBuilder mensaje = new StringBuilder();
        mensaje.append("📌 Estado del Pedido: ").append(pedido.getId()).append("\n")
               .append("🌀 Programa de Lavado: ").append(estado.getPrograma()).append("\n")
               .append("⚖ Peso: ").append(estado.getPeso()).append(" kg\n")
               .append("📅 Fecha: ").append(estado.getFecha()).append("\n")
               .append("👕 Prendas:\n");

        for (EstadoPedido.Prenda prenda : estado.getPrendas()) {
            mensaje.append("   - ").append(prenda.name()).append("\n");
        }

        JOptionPane.showMessageDialog(this, mensaje.toString(), "Estado del Pedido", JOptionPane.INFORMATION_MESSAGE);
    }


    private void agregarPedido() {
        String idPedido = pedidoIdField.getText();
        String direccion = pedidoDireccionField.getText();
        String comentarios = pedidoComentariosField.getText();

        if (idPedido.isEmpty() || direccion.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese un ID de pedido y una dirección.");
            return;
        }

        // Ventana emergente para información adicional
        JPanel panel = new JPanel(new GridLayout(4, 2, 5, 5));

        // Selección de programa de lavado
        JLabel programaLabel = new JLabel("Programa de lavado:");
        JComboBox<EstadoPedido.Programa> programaComboBox = new JComboBox<>(EstadoPedido.Programa.values());

        // Ingreso del peso
        JLabel pesoLabel = new JLabel("Peso (kg):");
        JTextField pesoField = new JTextField();

        // Selección de prendas
        JLabel prendasLabel = new JLabel("Seleccione las prendas:");
        JPanel prendasPanel = new JPanel(new GridLayout(0, 2));
        JCheckBox[] prendasCheckBoxes = new JCheckBox[EstadoPedido.Prenda.values().length];

        int i = 0;
        for (EstadoPedido.Prenda prenda : EstadoPedido.Prenda.values()) {
            prendasCheckBoxes[i] = new JCheckBox(prenda.name());
            prendasPanel.add(prendasCheckBoxes[i]);
            i++;
        }

        // Agregar componentes al panel
        panel.add(programaLabel);
        panel.add(programaComboBox);
        panel.add(pesoLabel);
        panel.add(pesoField);
        panel.add(prendasLabel);
        panel.add(new JScrollPane(prendasPanel));

        int result = JOptionPane.showConfirmDialog(this, panel, "Información del Pedido", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {
            try {
                int peso = Integer.parseInt(pesoField.getText());

                List<EstadoPedido.Prenda> prendasSeleccionadas = new ArrayList<>();
                for (i = 0; i < prendasCheckBoxes.length; i++) {
                    if (prendasCheckBoxes[i].isSelected()) {
                        prendasSeleccionadas.add(EstadoPedido.Prenda.values()[i]);
                    }
                }

                if (prendasSeleccionadas.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Seleccione al menos una prenda.");
                    return;
                }

                EstadoPedido nuevoPedido = new EstadoPedido(idPedido, 
                    (EstadoPedido.Programa) programaComboBox.getSelectedItem(),
                    peso, prendasSeleccionadas, "2025-02-21");
                
                controlador.agregarPedido(idPedido,direccion,comentarios, nuevoPedido);
                actualizarListaPedidos();
                limpiarCamposPedidos();

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Ingrese un peso válido.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void limpiarCamposPedidos() {
        pedidoIdField.setText("");
        pedidoDireccionField.setText("");
        pedidoComentariosField.setText("");
    }


    
    

    

    
    
    
    
    
}
