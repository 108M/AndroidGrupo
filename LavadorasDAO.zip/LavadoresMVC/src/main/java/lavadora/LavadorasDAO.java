/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package lavadora;

/**
 *
 * @author Markel
 */
public class LavadorasDAO {

    public static void main(String[] args) {
     
            
        //
        LavanderiaControlador controlador = new LavanderiaControlador();
    }
}
