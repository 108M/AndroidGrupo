/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lavadora;

import interfaces.DirectorioLavadoras;
import interfaces.DirectorioPedidos;
import interfaces.RegistroHistorialLavadora;
import interfaces.interfaceEstadoLavadora;
import interfaces.interfaceLavadora;
import interfaces.interfacePedido;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import lavadora.vistas.LavanderiaVista;
import lavadoras.modelos.EstadoLavadora;
import lavadoras.modelos.EstadoPedido;
import lavadoras.modelos.Lavadora;
import lavadoras.modelos.Pedido;

/**
 *
 * @author Markel
 */
public class LavanderiaControlador {
    private RegistroHistorialLavadora estadosLavadora;
    private DirectorioLavadoras lavadoras;
    private DirectorioPedidos pedidos;
    LavanderiaVista vista;
    public LavanderiaControlador() {

        // Creando 3 lavadoras de ejemplo
        this.lavadoras = new DirectorioLavadoras(new ArrayList<>()); 
        this.pedidos = new DirectorioPedidos(new ArrayList<>()); 
        this.estadosLavadora = new RegistroHistorialLavadora(); 
        vista = new LavanderiaVista(this);
        
        
        // Inicializar la vista y mostrarla
        EstadoLavadora estadoInicial1 = new EstadoLavadora("LAV-001", new Date(), new float[]{0, 0, 0}, new ArrayList<>());
        estadosLavadora.añadirEstado(estadoInicial1);
        EstadoLavadora estadoInicial2 = new EstadoLavadora("LAV-002", new Date(), new float[]{0, 0, 0}, new ArrayList<>());
        estadosLavadora.añadirEstado(estadoInicial2);
        EstadoLavadora estadoInicial3 = new EstadoLavadora("LAV-003", new Date(), new float[]{0, 0, 0}, new ArrayList<>());
        estadosLavadora.añadirEstado(estadoInicial3);
        
        lavadoras.agregarLavadora("LAV-001", new float[]{1.2f, 3.4f}, estadoInicial1);
        lavadoras.agregarLavadora("LAV-002", new float[]{5.6f, 7.8f},estadoInicial2);
        lavadoras.agregarLavadora("LAV-003", new float[]{9.0f, 1.1f},estadoInicial3);
        
        
        
        EstadoPedido pedido1 = new EstadoPedido( "Pedido001",EstadoPedido.Programa.FRIO,5,Arrays.asList(EstadoPedido.Prenda.JERSEY, EstadoPedido.Prenda.CAMISA, EstadoPedido.Prenda.CALCETIN),"2025-02-21");

        EstadoPedido pedido2 = new EstadoPedido("Pedido002",EstadoPedido.Programa.ALGODON,8,Arrays.asList(EstadoPedido.Prenda.VAQUERO, EstadoPedido.Prenda.ABRIGO, EstadoPedido.Prenda.TOP),"2025-02-22"
        );

        EstadoPedido pedido3 = new EstadoPedido("Pedido003",EstadoPedido.Programa.DELICADO,3,Arrays.asList(EstadoPedido.Prenda.ROPA_INTERIOR_MUJER, EstadoPedido.Prenda.ALBORNOZ),"2025-02-23"
        );
        pedidos.agregarPedido("PED-01", "CALLE 1", "cuidado con el pantalon",pedido1);
        pedidos.agregarPedido("PED-02", "CALLE 2", "cuidado con la camiseta",pedido2);
        pedidos.agregarPedido("PED-03", "CALLE 3", "cuidado con el abrigo",pedido3);
        
        
        vista.setVisible(true);
    }

    public void agregarLavadora(String id, float[] localizacion) {
        EstadoLavadora nuevoEstado = new EstadoLavadora(id, new Date(), new float[]{0, 0, 0}, new ArrayList<>());
        estadosLavadora.añadirEstado(nuevoEstado);
        lavadoras.agregarLavadora(id, localizacion,nuevoEstado);
        vista.mostrarLavadoras(lavadoras.getLavadoras()); // Actualiza la vista
    }

   
    
    public List<Lavadora> getLavadoras() {
        return lavadoras.getLavadoras();
    }

    public List<Pedido> getPedidos() {
        return pedidos.getPedidos();
    }

    public void actualizarVista() {
        vista.mostrarLavadoras(lavadoras.getLavadoras());
    }
    
    public Lavadora buscarLavadoraPorId(String id) {
    for (Lavadora lavadora : lavadoras.getLavadoras()) {
        if (lavadora.getId().equals(id)) {
            return lavadora;
        }
    }
    return null;
    }
    
    public RegistroHistorialLavadora getHistorialLavadora() {
        return estadosLavadora;
    }
    
    
    
    public void agregarPedido(String idPedido, String direccion, String comentario, EstadoPedido estadoInicial) {
        
        pedidos.agregarPedido(idPedido,direccion,comentario,estadoInicial);
        actualizarVista();
        
    }
    public Pedido buscarPedidoPorId(String id) {
        for (Pedido pedido : pedidos.getPedidos()) {
            if (pedido.getId().equals(id)) {
                return pedido;
        }
        }
        return null;
    }
    
}