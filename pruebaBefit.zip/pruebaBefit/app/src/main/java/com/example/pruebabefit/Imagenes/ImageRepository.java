package com.example.pruebabefit.Imagenes;


import okhttp3.*;
import java.io.File;
import java.io.IOException;

public class ImageRepository {
    private final String APPLICATION_ID = "CdXSEGccBwT7HOAe8T3sE6CNuFiOyJDE9DNFEhJt";
    private final String REST_API_KEY = "jcxfHzxoP8jDYslcfGUSbhgMNQn8Iam1Cda35WpJ";
    private final String PARSE_FILES_URL = "https://parseapi.back4app.com/files/";
    
    private final OkHttpClient client = new OkHttpClient();

    public FileResource upload(File imageFile, String nameFileUpload) throws IOException {
        // Crear el cuerpo de la petición con el archivo
        RequestBody requestBody = RequestBody.create(
            MediaType.parse("image/jpeg"), 
            imageFile
        );

        // Construir la URL completa con el nombre del archivo
        String url = PARSE_FILES_URL + nameFileUpload;

        // Crear la petición
        Request request = new Request.Builder()
                .url(url)
                .post(requestBody)
                .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                .addHeader("Content-Type", "image/jpeg")
                .build();

        // Ejecutar la petición y procesar la respuesta
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Unexpected code " + response);
            }

            // Parsear la respuesta JSON
            String responseBody = response.body().string();
            return parseResponse(responseBody);
        }
    }

    private FileResource parseResponse(String jsonResponse) {
        // Aquí deberías usar un parser JSON como Gson o Jackson
        // Para simplificar, haremos un parseo básico
        String url = jsonResponse.split("\"url\":\"")[1].split("\"")[0];
        String name = jsonResponse.split("\"name\":\"")[1].split("\"")[0];
        
        FileResource resource = new FileResource();
        resource.url = url;
        resource.name = name;
        return resource;
    }
}