package com.example.pruebabefit.vista;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.pruebabefit.AppController;
import com.example.pruebabefit.R;
import com.example.pruebabefit.controlador.ControladorApp;
import com.example.pruebabefit.models.Usuario;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EditUsuarioActivity extends AppCompatActivity {

    private EditText editTextNombre, editTextPeso, editTextAltura, editTextEdad, editTextGenero;
    private Button   buttonGuardar;
    private ControladorApp controlador;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler         handler  = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_usuario);

        AppController.initControlador();
        controlador = AppController.getControlador();

        editTextNombre = findViewById(R.id.editTextNombre);
        editTextPeso   = findViewById(R.id.editTextPeso);
        editTextAltura = findViewById(R.id.editTextAltura);
        editTextEdad   = findViewById(R.id.editTextEdad);
        editTextGenero = findViewById(R.id.editTextGenero);
        buttonGuardar  = findViewById(R.id.buttonGuardar);

        Usuario u = controlador.getUsuarioActual();
        if (u != null) {
            editTextNombre.setText(u.getNombre());
            editTextPeso.setText(String.valueOf(u.getPeso()));
            editTextAltura.setText(String.valueOf(u.getAltura()));
            editTextEdad.setText(String.valueOf(u.getEdad()));
            editTextGenero.setText(u.getGenero().name());
            buttonGuardar.setText("Guardar cambios");
        } else {
            buttonGuardar.setText("Registrarse");
        }

        buttonGuardar.setOnClickListener(v -> guardarOActualizarUsuario());
    }

    private void guardarOActualizarUsuario() {
        String nombre  = editTextNombre.getText().toString().trim();
        String pesoStr = editTextPeso.getText().toString().trim();
        String altStr  = editTextAltura.getText().toString().trim();
        String edadStr = editTextEdad.getText().toString().trim();
        String genStr  = editTextGenero.getText().toString().trim().toUpperCase();

        if (nombre.isEmpty() || pesoStr.isEmpty() ||
                altStr.isEmpty() || edadStr.isEmpty() || genStr.isEmpty()) {
            Toast.makeText(this, "Rellena todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        executor.execute(() -> {
            boolean ok;
            try {
                float peso    = Float.parseFloat(pesoStr);
                float altura  = Float.parseFloat(altStr);
                int   edad    = Integer.parseInt(edadStr);
                Usuario.Genero genero = Usuario.Genero.valueOf(genStr);

                if (controlador.getUsuarioActual() == null) {
                    ok = controlador.registrarUsuario(nombre, peso, altura, edad, genero);
                } else {
                    ok = controlador.actualizarPerfil(nombre, peso, altura, edad, genero);
                }
            } catch (Exception e) {
                handler.post(() ->
                        Toast.makeText(this, "Formato de datos inválido", Toast.LENGTH_SHORT).show()
                );
                return;
            }

            handler.post(() -> {
                if (ok) {
                    Toast.makeText(this,
                            "Usuario guardado: " + controlador.getUsuarioActual().getNombre(),
                            Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(EditUsuarioActivity.this,
                            com.example.pruebabefit.MainActivity.class));
                    finish();
                } else {
                    Toast.makeText(this, "No se pudo guardar el usuario", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }
}
