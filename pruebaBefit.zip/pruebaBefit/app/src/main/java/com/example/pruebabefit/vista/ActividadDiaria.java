package com.example.pruebabefit.vista;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.pruebabefit.AppController;
import com.example.pruebabefit.MainActivity;
import com.example.pruebabefit.R;
import com.example.pruebabefit.controlador.ControladorApp;
import com.example.pruebabefit.models.ActividadFisica;
import com.example.pruebabefit.models.Ejercicio;

import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoField;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ActividadDiaria extends AppCompatActivity {

    private TextView tvTiempo, tvEjercicios;
    private Button btnFinalizar;
    private CountDownTimer countDownTimer;
    private long segundosRestantes;

    private ControladorApp controlador;
    private ActividadFisica actividad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_actividad_diaria);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Obtener referencias del layout
        tvTiempo = findViewById(R.id.tvTiempo);
        tvEjercicios = findViewById(R.id.tvEjercicios);
        btnFinalizar = findViewById(R.id.btnFinalizar);

        // Obtén la instancia del controlador
        android.util.Log.d("ActividadDiaria", "Obteniendo instancia del controlador...");
        controlador = AppController.getControlador();
        android.util.Log.d("ActividadDiaria", "Usuario actual: " + controlador.getUsuarioActual());

        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            // Esto se ejecuta en segundo plano
            ActividadFisica act = controlador.generarActividadDiaria();
            runOnUiThread(() -> {
                // Esto se ejecuta en el hilo principal
                if (act == null) {
                    Toast.makeText(ActividadDiaria.this, "No se pudo generar la actividad diaria", Toast.LENGTH_LONG).show();
                    finish();
                    return;
                }
                actividad = act;
                // Continuar con la configuración de la Activity
                cargarEjercicios(actividad);
                configurarTemporizador(actividad);
            });
        });

        // Configurar el botón para finalizar actividad
        btnFinalizar.setOnClickListener(v -> finalizarActividad());
    }

    private void cargarEjercicios(ActividadFisica actividad) {
        StringBuilder sb = new StringBuilder();
        sb.append("Ejercicios de hoy:\n");
        List<Ejercicio> listaEjercicios = actividad.getEjercicios();
        if (listaEjercicios != null && !listaEjercicios.isEmpty()) {
            for (Ejercicio ejercicio : listaEjercicios) {
                sb.append("- ").append(ejercicio.getNombre())
                        .append(": ").append(ejercicio.getTecnica())
                        .append("\n");
            }
        } else {
            sb.append("No hay ejercicios asignados.\n");
        }
        tvEjercicios.setText(sb.toString());
    }

    private void configurarTemporizador(ActividadFisica actividad) {
        try {
            String horaMaximaStr = actividad.getHoraMaximaActividad();
            if (horaMaximaStr == null || horaMaximaStr.trim().isEmpty()) {
                tvTiempo.setText("Error: Tiempo no definido");
                return;
            }
            // Define un formateador que acepte opcionalmente fracción de segundo
            DateTimeFormatter formatter = new DateTimeFormatterBuilder()
                    .appendPattern("HH:mm:ss")
                    .optionalStart()
                    .appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true)
                    .optionalEnd()
                    .toFormatter();
            LocalTime horaMaxima = LocalTime.parse(horaMaximaStr, formatter);
            LocalTime ahora = LocalTime.now();

            // Si la hora actual supera la hora máxima, se muestra que el tiempo se ha agotado
            if (ahora.isAfter(horaMaxima)) {
                tvTiempo.setText("¡Tiempo completado!");
                return;
            }

            Duration duracion = Duration.between(ahora, horaMaxima);
            segundosRestantes = duracion.getSeconds();

            // Configurar el CountDownTimer (los tiempos van en milisegundos)
            countDownTimer = new CountDownTimer(segundosRestantes * 1000, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    long segundos = millisUntilFinished / 1000;
                    long horas = segundos / 3600;
                    long minutos = (segundos % 3600) / 60;
                    long segs = segundos % 60;
                    tvTiempo.setText(String.format("Tiempo restante: %02d:%02d:%02d", horas, minutos, segs));
                }

                @Override
                public void onFinish() {
                    tvTiempo.setText("¡Tiempo terminado!");
                    Toast.makeText(ActividadDiaria.this, "¡Tiempo de actividad completado!", Toast.LENGTH_SHORT).show();
                }
            };
            countDownTimer.start();
        } catch (DateTimeParseException e) {
            tvTiempo.setText("Error: Formato de hora inválido");
            e.printStackTrace();
        } catch (Exception e) {
            tvTiempo.setText("Error al configurar el temporizador");
            e.printStackTrace();
        }
    }

    private void finalizarActividad() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        /*   FALTA IMPLEMENTAR ESTO DE LAS IMAGENES
        // Ejemplo: Se usa "prueba.png" como ruta de imagen. En una implementación real, probablemente abrirías la cámara.
        String pathImagen = "prueba.png";
        // Coordenadas de ejemplo (puedes obtenerlas dinámicamente)
        double latitud = 40.4168;
        double longitud = -3.7038;

        boolean exito = controlador.finalizarActividad(pathImagen, latitud, longitud);
        if (exito) {
            Toast.makeText(this, "¡Actividad completada con éxito!", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Error al finalizar la actividad", Toast.LENGTH_LONG).show();
        }*/

        // Finalmente, redirigir al MenuPrincipal
        Intent intent = new Intent(ActividadDiaria.this, MenuPrincipal.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }

}