package com.example.pruebabefit.dao;


import com.example.pruebabefit.models.ActividadFisica;
import java.util.List;

public interface ActividadFisicaDAO {
    // Crear una nueva actividad física
    void crearActividadFisica(ActividadFisica actividadFisica);

    // Obtener una actividad física por su ID
    ActividadFisica obtenerActividadFisicaPorId(String objectId);

    // Obtener todas las actividades físicas
    List<ActividadFisica> obtenerTodasLasActividadesFisicas();

    // Actualizar una actividad física existente
    void actualizarActividadFisica(ActividadFisica actividadFisica);

    // Eliminar una actividad física por su ID
    void eliminarActividadFisica(String objectId);
}