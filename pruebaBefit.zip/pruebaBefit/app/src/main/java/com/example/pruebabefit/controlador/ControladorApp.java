package com.example.pruebabefit.controlador;

import com.example.pruebabefit.dao.*;
import java.io.File;
import java.time.LocalTime;
import java.util.ArrayList;
import com.example.pruebabefit.models.*;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

public class ControladorApp {
    private UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
    private ActividadFisicaDAO actividadFisicaDAO = new ActividadFisicaDAOImpl();
    private EjercicioDAO ejercicioDAO = new EjercicioDAOImpl();
    private HistoriaDAO historiaDAO = new HistoriaDAOImpl();
    private HistorialesDeUsuarioDAO historialesDeUsuarioDAO = new HistorialesDeUsuarioDAOImpl();

    private Usuario usuarioActual;
    private ActividadFisica actividadActual;

    public void setUsuarioActual(Usuario usuario) {
        this.usuarioActual = usuario;
    }

    public Usuario getUsuarioActual() {
        return usuarioActual;
    }

    public ActividadFisica generarActividadDiaria() {
        android.util.Log.d("ControladorApp", "Generando actividad diaria...");

        if (usuarioActual == null) {
            android.util.Log.e("ControladorApp", "Error: usuarioActual es null");
            return null;
        }

        List<Ejercicio> ejercicios = ejercicioDAO.obtenerTodosLosEjercicios();
        if (ejercicios.isEmpty()) {
            return null;
        }

        Random rand = new Random();
        int cantidadEjercicios = 3 + rand.nextInt(3); // Entre 3 y 5 ejercicios
        List<Ejercicio> ejerciciosDeHoy = new ArrayList<>();
        float tiempoTotal = 0;

        // Seleccionar ejercicios aleatorios y calcular tiempo total
        for (int i = 0; i < cantidadEjercicios; i++) {
            Ejercicio ej = ejercicios.get(rand.nextInt(ejercicios.size()));
            ejerciciosDeHoy.add(ej);
            tiempoTotal += ej.getTiempoMax();
            tiempoTotal += 10; // 10 segundos de descanso
        }

        LocalTime horaComienzo = LocalTime.now();
        LocalTime horaMaxima = horaComienzo.plusSeconds((long) tiempoTotal);
        if (horaMaxima.isAfter(LocalTime.MAX)) {
            horaMaxima = LocalTime.MAX;
        }

        actividadActual = new ActividadFisica(
                new ArrayList<>(ejerciciosDeHoy.stream().map(Ejercicio::getObjectId).collect(Collectors.toList())),
                horaComienzo,
                horaMaxima,
                false
        );

        actividadFisicaDAO.crearActividadFisica(actividadActual);

        actividadActual.setEjercicios(ejerciciosDeHoy);

        return actividadActual;
    }

    public boolean registrarUsuario(String nombre, float peso, float altura, int edad, Usuario.Genero genero) {
        if (nombre == null || nombre.trim().isEmpty() || peso <= 0 || altura <= 0 || edad <= 0) {
            return false;
        }

        // Realizar la verificación de si el usuario ya existe en un hilo en segundo plano
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Future<Boolean> result = executor.submit(() -> usuarioExiste(nombre));
        try {
            if (result.get()) {
                return false;  // Si ya existe el usuario, no lo creamos
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return false;
        }

        // Crear un nuevo usuario
        Usuario usuario = new Usuario(nombre, peso, altura, edad, genero);
        usuarioDAO.crearUsuario(usuario);

        HistorialesDeUsuario historial = new HistorialesDeUsuario(usuario.getObjectId(), new ArrayList<>());
        historialesDeUsuarioDAO.crearHistorialDeUsuario(historial);

        this.usuarioActual = usuario;
        return true;
    }

    public boolean actualizarPerfil(String nombre, float peso, float altura, int edad, Usuario.Genero genero) {
        if (usuarioActual == null) {
            return false;
        }

        if (nombre == null || nombre.trim().isEmpty() || peso <= 0 || altura <= 0 || edad <= 0) {
            return false;
        }

        if (!usuarioActual.getNombre().equalsIgnoreCase(nombre) && usuarioExiste(nombre)) {
            return false;
        }

        usuarioActual.setNombre(nombre);
        usuarioActual.setPeso(peso);
        usuarioActual.setAltura(altura);
        usuarioActual.setEdad(edad);
        usuarioActual.setGenero(genero);

        usuarioDAO.actualizarUsuario(usuarioActual);
        return true;
    }

    public boolean iniciarSesion(String nombre) {
        List<Usuario> usuarios = usuarioDAO.obtenerTodosLosUsuarios();
        for (Usuario u : usuarios) {
            if (u.getNombre().equalsIgnoreCase(nombre)) {
                this.usuarioActual = u;
                return true;
            }
        }
        return false;
    }

    public boolean usuarioExiste(String nombre) {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Future<Boolean> result = executor.submit(() -> {
            try {
                return usuarioDAO.obtenerTodosLosUsuarios().stream()
                        .anyMatch(usuario -> usuario.getNombre().equals(nombre));
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        });

        try {
            return result.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Historia> obtenerHistorialUsuario() {
        if (usuarioActual == null) return new ArrayList<>();

        HistorialesDeUsuario historial = historialesDeUsuarioDAO
                .obtenerHistorialDeUsuarioPorIdUsuario(usuarioActual.getObjectId());

        if (historial == null) return new ArrayList<>();

        return historial.getHistorialUsuarioIds().stream()
                .map(id -> historiaDAO.obtenerHistoriaPorId(id))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    public boolean finalizarActividad(String imagenPath, double latitud, double longitud) {
        if (actividadActual == null || usuarioActual == null) {
            return false;
        }

        try {
            actividadActual.setHoraFinalizacionActividad(LocalTime.now());
            actividadActual.setEstado(true);
            actividadFisicaDAO.actualizarActividadFisica(actividadActual);

            Historia.estadoFinalizacion estado;
            LocalTime horaFin = LocalTime.now();
            LocalTime horaMax = LocalTime.parse(actividadActual.getHoraMaximaActividad());

            if (horaFin.isBefore(horaMax.minusMinutes(30))) {
                estado = Historia.estadoFinalizacion.FACIL;
            } else if (horaFin.isBefore(horaMax)) {
                estado = Historia.estadoFinalizacion.MEDIO;
            } else if (horaFin.isBefore(horaMax.plusMinutes(30))) {
                estado = Historia.estadoFinalizacion.DIFICIL;
            } else {
                estado = Historia.estadoFinalizacion.IMPOSIBLE;
            }

            Historia historia = new Historia(
                    new Date(),
                    actividadActual.getObjectId(),
                    estado,
                    imagenPath,
                    latitud,
                    longitud
            );

            historiaDAO.crearHistoria(historia, new File(imagenPath));

            HistorialesDeUsuario historial = historialesDeUsuarioDAO
                    .obtenerHistorialDeUsuarioPorIdUsuario(usuarioActual.getObjectId());

            if (historial == null) {
                historial = new HistorialesDeUsuario(usuarioActual.getObjectId(), new ArrayList<>());
                historialesDeUsuarioDAO.crearHistorialDeUsuario(historial);
            }

            historial.getHistorialUsuarioIds().add(historia.getObjectId());
            historialesDeUsuarioDAO.actualizarHistorialDeUsuario(historial);

            actividadActual = null;
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public ActividadFisicaDAO getActividadFisicaDAO() {
        return actividadFisicaDAO;
    }
}
