package com.example.pruebabefit.dao;

import com.example.pruebabefit.Imagenes.FileResource;
import com.example.pruebabefit.Imagenes.ImageRepository;
import com.example.pruebabefit.models.Historia;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import java.io.File;
import okhttp3.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HistoriaDAOImpl implements HistoriaDAO {
    
    private final String API_URL = "https://parseapi.back4app.com/classes/Historia";
    private final String APPLICATION_ID = "CdXSEGccBwT7HOAe8T3sE6CNuFiOyJDE9DNFEhJt";
    private final String REST_API_KEY = "jcxfHzxoP8jDYslcfGUSbhgMNQn8Iam1Cda35WpJ";
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new GsonBuilder()
        .registerTypeAdapter(Date.class, new DateTypeAdapter())
        .create();
    
    private final ImageRepository imageRepo = new ImageRepository();

    @Override
    public void crearHistoria(Historia historia, File imagenFile) {
        try {
            // Subir imagen si existe
            if (imagenFile != null && imagenFile.exists()) {
                FileResource imagenResource = imageRepo.upload(imagenFile, generarNombreArchivo(imagenFile));
                historia.setImagen(imagenResource.url);
                System.out.println("Imagen subida correctamente. URL: " + imagenResource.url);
            }

            // Crear la historia en Parse
            RequestBody body = RequestBody.create(
                gson.toJson(historia), 
                MediaType.get("application/json; charset=utf-8")
            );

            Request request = new Request.Builder()
                .url(API_URL)
                .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build();

            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    throw new IOException("Error al crear historia: " + response.body().string());
                }

                JsonObject jsonResponse = gson.fromJson(response.body().string(), JsonObject.class);
                historia.setObjectId(jsonResponse.get("objectId").getAsString());
            }
        } catch (IOException e) {
            System.err.println("Error en crearHistoria: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Error al crear la historia", e);
        }
    }

    private String generarNombreArchivo(File file) {
        return "historia_" + System.currentTimeMillis() + "_" + file.getName();
    }

    @Override
    public Historia obtenerHistoriaPorId(String objectId) {
        try {
            Request request = new Request.Builder()
                .url(API_URL + "/" + objectId)
                .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                .get()
                .build();

            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    System.err.println("Error al obtener historia: " + response.body().string());
                    return null;
                }
                return gson.fromJson(response.body().string(), Historia.class);
            }
        } catch (IOException e) {
            System.err.println("Error al obtener historia: " + e.getMessage());
            return null;
        }
    }

    @Override
    public void actualizarHistoria(Historia historia) {
        try {
            RequestBody body = RequestBody.create(
                gson.toJson(historia), 
                MediaType.get("application/json")
            );

            Request request = new Request.Builder()
                .url(API_URL + "/" + historia.getObjectId())
                .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                .put(body)
                .build();

            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    throw new IOException("Error al actualizar: " + response.body().string());
                }
            }
        } catch (IOException e) {
            System.err.println("Error al actualizar historia: " + e.getMessage());
        }
    }

    @Override
    public void eliminarHistoria(String objectId) {
        try {
            Request request = new Request.Builder()
                .url(API_URL + "/" + objectId)
                .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                .delete()
                .build();

            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    throw new IOException("Error al eliminar: " + response.body().string());
                }
            }
        } catch (IOException e) {
            System.err.println("Error al eliminar historia: " + e.getMessage());
        }
    }

    @Override
    public List<Historia> obtenerTodasLasHistorias() {
        List<Historia> historias = new ArrayList<>();
        try {
            Request request = new Request.Builder()
                .url(API_URL)
                .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                .get()
                .build();

            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    System.err.println("Error al obtener historias: " + response.body().string());
                    return historias;
                }

                JsonObject jsonResponse = gson.fromJson(response.body().string(), JsonObject.class);
                JsonArray resultados = jsonResponse.getAsJsonArray("results");
                
                for (int i = 0; i < resultados.size(); i++) {
                    historias.add(gson.fromJson(resultados.get(i), Historia.class));
                }
            }
        } catch (IOException e) {
            System.err.println("Error al obtener historias: " + e.getMessage());
        }
        return historias;
    }
}