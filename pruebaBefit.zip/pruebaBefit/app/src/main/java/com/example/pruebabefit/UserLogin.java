package com.example.pruebabefit;

import android.os.Bundle;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.pruebabefit.models.Usuario;
import com.example.pruebabefit.controlador.ControladorApp;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class UserLogin extends AppCompatActivity {

    private EditText editTextNombreLogin;
    private Button buttonIniciarSesion2;
    private ControladorApp controlador;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        controlador = AppController.getControlador();
        editTextNombreLogin = findViewById(R.id.editTextNombreLogin);

        buttonIniciarSesion2 = findViewById(R.id.buttonIniciarSesion2);
        buttonIniciarSesion2.setOnClickListener(v -> iniciarSesion());
    }
    private void iniciarSesion() {
        String nombre = editTextNombreLogin.getText().toString();

        // Ejecutamos el inicio de sesion del usuario en segundo plano
        executor.execute(() -> {
            boolean iniciaSesion = controlador.iniciarSesion(nombre);
            handler.post(() -> {
                // Esto se ejecuta en el hilo principal
                if (iniciaSesion) {
                    Toast.makeText(this, "Usuario ha iniciado la sesion: " + controlador.getUsuarioActual().getNombre(), Toast.LENGTH_SHORT).show();
                    finish(); // Cierra la Activity
                } else {
                    Toast.makeText(this, "No se pudo registrar el usuario", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown(); // Cierra el executor al destruir la Activity
    }


}