package com.example.pruebabefit.dao;

public class Claves {
    private final String APPLICATION_ID = "CdXSEGccBwT7HOAe8T3sE6CNuFiOyJDE9DNFEhJt";
    private final String REST_API_KEY = "jcxfHzxoP8jDYslcfGUSbhgMNQn8Iam1Cda35WpJ";

    public String getAPPLICATION_ID() {
        return APPLICATION_ID;
    }

    public String getREST_API_KEY() {
        return REST_API_KEY;
    }

}
