package com.example.pruebabefit;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pruebabefit.models.Usuario;

public class EditUsuarioActivity extends AppCompatActivity {

    private EditText editTextNombre, editTextPeso, editTextAltura, editTextEdad, editTextGenero;
    private Button buttonGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_usuario);

        editTextNombre = findViewById(R.id.editTextNombre);
        editTextPeso = findViewById(R.id.editTextPeso);
        editTextAltura = findViewById(R.id.editTextAltura);
        editTextEdad = findViewById(R.id.editTextEdad);
        editTextGenero = findViewById(R.id.editTextGenero);

        buttonGuardar = findViewById(R.id.buttonGuardar);

        buttonGuardar.setOnClickListener(v -> guardarUsuario());
    }

    private void guardarUsuario() {
        try {
            String nombre = editTextNombre.getText().toString();

            float peso = Float.parseFloat(editTextPeso.getText().toString());
            float altura = Float.parseFloat(editTextAltura.getText().toString());
            int edad = Integer.parseInt(editTextEdad.getText().toString());
            String generoStr = editTextGenero.getText().toString().toUpperCase();


            Usuario.Genero genero = Usuario.Genero.valueOf(generoStr);



            Usuario usuario = new Usuario( nombre, peso, altura, edad, genero);

            // Aquí podrías guardar el usuario en una lista estática, BD, etc.
            Toast.makeText(this, "Usuario guardado: " + usuario.getNombre(), Toast.LENGTH_SHORT).show();

            finish(); // Cierra la Activity

        } catch (Exception e) {
            Toast.makeText(this, "Error al guardar usuario: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
