package com.example.pruebabefit;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.pruebabefit.models.Usuario;
import com.example.pruebabefit.controlador.ControladorApp;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EditUsuarioActivity extends AppCompatActivity {

    private EditText editTextNombre, editTextPeso, editTextAltura, editTextEdad, editTextGenero;
    private Button buttonGuardar;
    private ControladorApp controlador;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_usuario);
        controlador = AppController.getControlador();

        editTextNombre = findViewById(R.id.editTextNombre);
        editTextPeso = findViewById(R.id.editTextPeso);
        editTextAltura = findViewById(R.id.editTextAltura);
        editTextEdad = findViewById(R.id.editTextEdad);
        editTextGenero = findViewById(R.id.editTextGenero);

        buttonGuardar = findViewById(R.id.buttonGuardar);
        buttonGuardar.setOnClickListener(v -> guardarUsuario());
    }

    private void guardarUsuario() {
        String nombre = editTextNombre.getText().toString();
        float peso = Float.parseFloat(editTextPeso.getText().toString());
        float altura = Float.parseFloat(editTextAltura.getText().toString());
        int edad = Integer.parseInt(editTextEdad.getText().toString());
        String generoStr = editTextGenero.getText().toString().toUpperCase();

        Usuario.Genero genero;
        try {
            genero = Usuario.Genero.valueOf(generoStr);
        } catch (IllegalArgumentException e) {
            Toast.makeText(this, "Género no válido", Toast.LENGTH_SHORT).show();
            return;
        }
        // Ejecutamos el registro del usuario en segundo plano
        executor.execute(() -> {
            boolean registrado = controlador.registrarUsuario(nombre, peso, altura, edad, genero);
            handler.post(() -> {
                // Esto se ejecuta en el hilo principal
                if (registrado) {
                    Toast.makeText(this, "Usuario guardado: " + controlador.getUsuarioActual().getNombre(), Toast.LENGTH_SHORT).show();
                    finish(); // Cierra la Activity
                } else {
                    Toast.makeText(this, "No se pudo registrar el usuario", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown(); // Cierra el executor al destruir la Activity
    }
}
