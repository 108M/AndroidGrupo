package com.example.pruebabefit.dao;

import java.io.File;
import com.example.pruebabefit.models.Historia;
import java.util.List;

public interface HistoriaDAO {
    // Crear una nueva historia
    void crearHistoria(Historia historia, File imagenFile);

    // Obtener una historia por su ID
    Historia obtenerHistoriaPorId(String objectId);

    // Obtener todas las historias
    List<Historia> obtenerTodasLasHistorias();

    // Actualizar una historia existente
    void actualizarHistoria(Historia historia);

    // Eliminar una historia por su ID
    void eliminarHistoria(String objectId);
}