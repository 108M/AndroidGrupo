package com.example.pruebabefit.dao;

import com.example.pruebabefit.models.HistorialesDeUsuario;
import java.util.List;

public interface HistorialesDeUsuarioDAO {
    // Crear un nuevo historial de usuario
    void crearHistorialDeUsuario(HistorialesDeUsuario historialDeUsuario);

    // Obtener un historial de usuario por su ID
    HistorialesDeUsuario obtenerHistorialDeUsuarioPorId(String objectId);
    
    // Nuevo método para buscar por idUsuario
    HistorialesDeUsuario obtenerHistorialDeUsuarioPorIdUsuario(String idUsuario);
    
    // Obtener todos los historiales de usuario
    List<HistorialesDeUsuario> obtenerTodosLosHistorialesDeUsuario();

    // Actualizar un historial de usuario existente
    void actualizarHistorialDeUsuario(HistorialesDeUsuario historialDeUsuario);

    // Eliminar un historial de usuario por su ID
    void eliminarHistorialDeUsuario(String objectId);
    
}