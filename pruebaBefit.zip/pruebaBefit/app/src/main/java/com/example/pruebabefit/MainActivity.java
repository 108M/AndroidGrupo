package com.example.pruebabefit;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnRegistrarse = findViewById(R.id.btnRegistrarse);
        Button btnIniciarSesion = findViewById(R.id.btnIniciarSesion);

        // Botón para abrir la pantalla de Registrarse
        btnRegistrarse.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditUsuarioActivity.class);
            startActivity(intent);
        });

        // Botón para abrir la pantalla de Inicio de Sesion
        btnIniciarSesion.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, UserLogin.class);
            startActivity(intent);
        });

    }
}