package com.example.pruebabefit;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pruebabefit.vista.EditUsuarioActivity;
import com.example.pruebabefit.vista.UserLogin;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar el controlador global una vez
        AppController.initControlador();

        Button btnRegistrarse = findViewById(R.id.btnRegistrarse);
        Button btnIniciarSesion = findViewById(R.id.btnIniciarSesion);

        // Ir a la actividad de registro
        btnRegistrarse.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, EditUsuarioActivity.class);
            startActivity(intent);
        });

        // Ir a la actividad de inicio de sesión
        btnIniciarSesion.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, UserLogin.class);
            startActivity(intent);
        });
    }
}
