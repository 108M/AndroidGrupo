package com.example.pruebabefit.models;

import java.util.Date;

public class Historia {
    private String objectId;
    private Date fecha;
    private String actividadRegistradaId;
    private estadoFinalizacion estadoFinalizacion;
    private String imagen; // Ahora será un String con la URL o referencia de la imagen en Back4App
    private double latitud;
    private double longitud;

    public Historia(Date fecha, String actividadRegistradaId, estadoFinalizacion estadoFinalizacion,
                    String imagen, double latitud, double longitud) {
        this.fecha = fecha;
        this.actividadRegistradaId = actividadRegistradaId;
        this.estadoFinalizacion = estadoFinalizacion;
        this.imagen = imagen;
        this.latitud = latitud;
        this.longitud = longitud;
    }

    // Getters y Setters
    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        if (fecha == null) {
            throw new IllegalArgumentException("La fecha no puede ser null.");
        }
        this.fecha = fecha;
    }

    public String getActividadRegistradaId() {
        return actividadRegistradaId;
    }

    public void setActividadRegistradaId(String actividadRegistradaId) {
        if (actividadRegistradaId == null || actividadRegistradaId.trim().isEmpty()) {
            throw new IllegalArgumentException("La actividad registrada ID no puede estar vacío.");
        }
        this.actividadRegistradaId = actividadRegistradaId;
    }

    public estadoFinalizacion getEstadoFinalizacion() {
        return estadoFinalizacion;
    }

    public void setEstadoFinalizacion(estadoFinalizacion estadoFinalizacion) {
        if (estadoFinalizacion == null) {
            throw new IllegalArgumentException("El estado de finalización no puede ser null.");
        }
        this.estadoFinalizacion = estadoFinalizacion;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public double getLatitud() {
        return latitud;
    }

    public void setLatitud(double latitud) {
        this.latitud = latitud;
    }

    public double getLongitud() {
        return longitud;
    }

    public void setLongitud(double longitud) {
        this.longitud = longitud;
    }

    public enum estadoFinalizacion {
        FACIL, MEDIO, DIFICIL, IMPOSIBLE
    }
}