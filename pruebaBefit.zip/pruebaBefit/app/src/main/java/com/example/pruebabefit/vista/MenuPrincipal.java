package com.example.pruebabefit.vista;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.example.pruebabefit.MainActivity;
import com.example.pruebabefit.R;
import com.example.pruebabefit.vista.EditUsuarioActivity;      // <- Perfil
import com.example.pruebabefit.vista.ActividadDiaria;         // <- Realizar Actividad
import com.example.pruebabefit.vista.Historial;               // <- Historial

public class MenuPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_menu_principal);

        // Ajuste de padding para barras sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        // Mostrar nombre de usuario pasado por Intent
        String nombreUsuario = getIntent().getStringExtra("nombre");
        TextView tvNombreUsuario = findViewById(R.id.textView3);
        tvNombreUsuario.setText("Bienvenido, " + nombreUsuario);
    }

    public void cerrarSesion(View view) {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    public void actividadDiaria(View view) {
        startActivity(new Intent(this, ActividadDiaria.class));
        finish();
    }

    public void historial(View view) {
        startActivity(new Intent(this, Historial.class));
        finish();
    }

    public void perfil(View view) {
        startActivity(new Intent(this, EditUsuarioActivity.class));
        finish();
    }
}
