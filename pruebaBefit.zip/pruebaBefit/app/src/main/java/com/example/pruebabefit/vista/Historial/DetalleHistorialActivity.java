package com.example.pruebabefit.vista.Historial;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.example.pruebabefit.R;
import com.example.pruebabefit.models.Historia;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class DetalleHistorialActivity extends AppCompatActivity {

    private TextView tvInfoDetalle;
    private ImageView ivDetalleImagen;
    private Button btnCerrarDetalle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_historia);

        tvInfoDetalle = findViewById(R.id.tvInfoDetalle);
        ivDetalleImagen = findViewById(R.id.ivDetalleImagen);
        btnCerrarDetalle = findViewById(R.id.btnCerrarDetalle);

        // Recibir el objeto Historia pasado por el Intent. Se asume que Historia implementa Serializable
        Historia historia = (Historia) getIntent().getSerializableExtra("historia");
        if (historia != null) {
            String info = "Fecha: " + new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(historia.getFecha()) +
                    "\nUbicación: Lat " + historia.getLatitud() + ", Long " + historia.getLongitud() +
                    "\nEstado: " + (historia.getEstadoFinalizacion() != null ? historia.getEstadoFinalizacion().toString() : "Sin estado");
            tvInfoDetalle.setText(info);

            // Si hay imagen registrada, usar Glide para cargarla
            if (historia.getImagen() != null && !historia.getImagen().isEmpty()) {
                Glide.with(this)
                        .load(historia.getImagen())
                        .into(ivDetalleImagen);
            }
        }

        btnCerrarDetalle.setOnClickListener(v -> finish());
    }
}
