package com.example.pruebabefit;

import com.example.pruebabefit.controlador.ControladorApp;

public class AppController {
    private static ControladorApp controlador;

    public static void initControlador() {
        if (controlador == null) {
            controlador = new ControladorApp();
        }
    }

    public static ControladorApp getControlador() {
        return controlador;
    }
}
