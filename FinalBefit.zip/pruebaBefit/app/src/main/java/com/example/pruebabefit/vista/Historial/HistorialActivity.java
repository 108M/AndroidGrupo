package com.example.pruebabefit.vista.Historial;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pruebabefit.AppController;
import com.example.pruebabefit.R;
import com.example.pruebabefit.controlador.ControladorApp;
import com.example.pruebabefit.models.Historia;
import com.example.pruebabefit.vista.Historial.HistorialAdapter;
import com.example.pruebabefit.vista.MenuPrincipal;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HistorialActivity extends AppCompatActivity {
    private ControladorApp controlador;
    private RecyclerView rvHistorial;
    private Button btnVolver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial);

        rvHistorial = findViewById(R.id.rvHistorial);
        btnVolver = findViewById(R.id.btnVolver);

        controlador = AppController.getControlador();

        // Usamos ExecutorService para ejecutar la operación en background.
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            // Esta llamada se ejecuta en segundo plano
            List<Historia> historial = controlador.obtenerHistorialUsuario();
            // Una vez obtenido el historial, se actualiza la UI en el hilo principal.
            runOnUiThread(() -> {
                rvHistorial.setLayoutManager(new LinearLayoutManager(HistorialActivity.this));
                HistorialAdapter adapter = new HistorialAdapter(historial, historia -> {
                    // Al tocar un ítem, lanzamos la Activity de detalle
                    Intent intent = new Intent(HistorialActivity.this, DetalleHistorialActivity.class);
                    intent.putExtra("historia", historia); // Asegúrate de que Historia implemente Serializable o Parcelable.
                    startActivity(intent);
                });
                rvHistorial.setAdapter(adapter);
            });
        });

        btnVolver.setOnClickListener(v -> {
            Intent intent = new Intent(HistorialActivity.this, MenuPrincipal.class);
            startActivity(intent);
        });
    }
}