package com.example.pruebabefit.models;

import java.util.ArrayList;
import java.util.List;

public class HistorialesDeUsuario {
    private String objectId; // Este campo será asignado por Back4App
    private String idUsuario; // Ahora es un String (objectId de Usuario)
    private List<String> historialUsuarioIds; // Lista de objectIds de Historias

    public HistorialesDeUsuario(String idUsuario, List<String> historialUsuarioIds) {
        this.idUsuario = idUsuario;
        this.historialUsuarioIds = historialUsuarioIds;
    }

    // Getters y Setters
    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        if (idUsuario == null || idUsuario.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID de usuario no puede ser nulo ni vacío.");
        }
        this.idUsuario = idUsuario;
    }

    public List<String> getHistorialUsuarioIds() {
        return historialUsuarioIds;
    }

    public void setHistorialUsuarioIds(List<String> historialUsuarioIds) {
        if (historialUsuarioIds == null || historialUsuarioIds.isEmpty()) {
            throw new IllegalArgumentException("La lista de historial de usuario no puede ser nula ni vacía.");
        }
        this.historialUsuarioIds = historialUsuarioIds;
    }

    public void agregarHistoria(String historiaId) {
        if (historialUsuarioIds == null) {
            historialUsuarioIds = new ArrayList<>();
        }
        historialUsuarioIds.add(historiaId);
    }
}