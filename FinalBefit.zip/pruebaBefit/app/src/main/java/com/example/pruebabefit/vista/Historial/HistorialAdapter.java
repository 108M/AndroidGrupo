package com.example.pruebabefit.vista.Historial;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.pruebabefit.R;
import com.example.pruebabefit.models.Historia;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class HistorialAdapter extends RecyclerView.Adapter<HistorialAdapter.HistorialViewHolder> {

    private List<Historia> historialList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Historia historia);
    }

    public HistorialAdapter(List<Historia> historialList, OnItemClickListener listener) {
        this.historialList = historialList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public HistorialViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_historial, parent, false);
        return new HistorialViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull HistorialViewHolder holder, int position) {
        Historia historia = historialList.get(position);
        String estado = (historia.getEstadoFinalizacion() != null) ? historia.getEstadoFinalizacion().toString() : "Sin estado";
        String fecha = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(historia.getFecha());
        // Opcional: agregar el icono de cámara si hay imagen
        String texto = fecha + " - " + estado + ( (historia.getImagen() != null && !historia.getImagen().isEmpty()) ? " 📷" : "");
        holder.tvItem.setText(texto);
        holder.itemView.setOnClickListener(v -> listener.onItemClick(historia));
    }

    @Override
    public int getItemCount() {
        return historialList.size();
    }

    static class HistorialViewHolder extends RecyclerView.ViewHolder {
        TextView tvItem;

        HistorialViewHolder(@NonNull View itemView) {
            super(itemView);
            tvItem = itemView.findViewById(R.id.tvHistorialItem);
        }
    }
}
