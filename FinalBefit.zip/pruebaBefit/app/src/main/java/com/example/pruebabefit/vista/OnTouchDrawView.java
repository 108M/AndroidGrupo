package com.example.pruebabefit.vista;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Random;

public class OnTouchDrawView extends View {

    private final Path   path  = new Path();
    private final Paint  paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint  grid  = new Paint();
    private       Bitmap cache;
    private       Canvas cCanvas;
    private final Random rnd = new Random();
    private int color = Color.MAGENTA;

    public OnTouchDrawView(Context ctx, AttributeSet a) { super(ctx, a); init(); }
    public OnTouchDrawView(Context ctx)                 { super(ctx);   init(); }

    private void init() {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(8f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setShadowLayer(8, 0, 0, Color.DKGRAY);
        grid.setColor(0x22FFFFFF);
        grid.setStrokeWidth(1f);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        cache   = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        cCanvas = new Canvas(cache);
    }

    @Override protected void onDraw(Canvas canvas) {
        int step = 40;
        for (int x = 0; x < getWidth(); x += step) canvas.drawLine(x, 0, x, getHeight(), grid);
        for (int y = 0; y < getHeight(); y += step) canvas.drawLine(0, y, getWidth(), y, grid);
        canvas.drawBitmap(cache, 0, 0, null);
        paint.setColor(color);
        canvas.drawPath(path, paint);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN: path.moveTo(x, y); return true;
            case MotionEvent.ACTION_MOVE: path.lineTo(x, y); invalidate(); return true;
            case MotionEvent.ACTION_UP:
                paint.setColor(color);
                cCanvas.drawPath(path, paint);
                path.reset();
                color = Color.rgb(rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
                invalidate();
                return true;
        }
        return false;
    }

    public void clear() {
        cCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        invalidate();
    }

    public File exportPng(String prefix) {
        try {

            File dir = getContext().getExternalFilesDir(
                    android.os.Environment.DIRECTORY_PICTURES);

            if (dir == null)
                dir = new File(getContext().getFilesDir(), "Pictures");

            if (!dir.exists()) dir.mkdirs();

            File f = new File(dir, prefix + System.currentTimeMillis() + ".png");

            FileOutputStream fos = new FileOutputStream(f);
            cache.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();

            android.util.Log.d("EXPORT_PNG",
                    "Guardado en → " + f.getAbsolutePath() + " | Existe: " + f.exists());

            return f;
        } catch (Exception e) {
            android.util.Log.e("EXPORT_PNG", "Error al guardar PNG", e);
            return null;
        }
    }

}
