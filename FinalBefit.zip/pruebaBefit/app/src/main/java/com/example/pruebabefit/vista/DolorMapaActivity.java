package com.example.pruebabefit.vista;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pruebabefit.AppController;
import com.example.pruebabefit.Imagenes.FileResource;
import com.example.pruebabefit.Imagenes.ImageRepository;
import com.example.pruebabefit.R;
import com.example.pruebabefit.controlador.ControladorApp;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class DolorMapaActivity extends AppCompatActivity {

    private OnTouchDrawView drawOverlay;
    private String fotoUri;
    private double lat, lon;
    private ControladorApp controlador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dolor_mapa);

        controlador = AppController.getControlador();

        fotoUri = getIntent().getStringExtra("foto");
        lat     = getIntent().getDoubleExtra("lat", 0);
        lon     = getIntent().getDoubleExtra("lon", 0);

        drawOverlay = findViewById(R.id.drawOverlay);
        Button btnGuardar = findViewById(R.id.btnGuardar);
        btnGuardar.setOnClickListener(v -> guardarDolor());
    }

    private void guardarDolor() {
        File png = drawOverlay.exportPng("dolor_");
        if (png == null) {
            Toast.makeText(this, "No se pudo guardar la imagen", Toast.LENGTH_SHORT).show();
            return;
        }

        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            boolean ok = controlador.finalizarActividad(fotoUri, lat, lon);
            if (ok) {
                try {
                    // Subir imagen del mapa de dolor
                    ImageRepository imageRepo = new ImageRepository();
                    FileResource uploaded = imageRepo.upload(png, png.getName());

                    // Guardar URL remota en la historia
                    controlador.subirMapaDolor(controlador.getUltimaHistoriaId(), uploaded.url);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            runOnUiThread(() -> {
                Toast.makeText(this,
                        ok ? "Actividad registrada" : "Error al guardar",
                        Toast.LENGTH_LONG).show();
                startActivity(new Intent(this, MenuPrincipal.class));
                finish();
            });
            exec.shutdown();
        });
    }

}
