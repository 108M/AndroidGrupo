package com.example.pruebabefit.vista;

import android.content.Intent;
import android.os.Bundle;

import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.pruebabefit.AppController;
import com.example.pruebabefit.R;
import com.example.pruebabefit.controlador.ControladorApp;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class UserLogin extends AppCompatActivity {

    private EditText editTextNombreLogin;
    private Button buttonIniciarSesion2;
    private ControladorApp controlador;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        controlador = AppController.getControlador();
        editTextNombreLogin = findViewById(R.id.editTextNombreLogin);

        buttonIniciarSesion2 = findViewById(R.id.buttonIniciarSesion2);
        buttonIniciarSesion2.setOnClickListener(v -> iniciarSesion());
    }
    private void iniciarSesion() {
        String nombre = editTextNombreLogin.getText().toString();

        // Ejecutamos el inicio de sesión en segundo plano
        executor.execute(() -> {
            boolean iniciaSesion = controlador.iniciarSesion(nombre);
            handler.post(() -> {
                // Esto se ejecuta en el hilo principal
                if (iniciaSesion) {
                    Toast.makeText(UserLogin.this, "Usuario ha iniciado sesión: "
                            + controlador.getUsuarioActual().getNombre(), Toast.LENGTH_SHORT).show();

                    // Iniciar la nueva Activity MenuPrincipal:
                    Intent intent = new Intent(UserLogin.this, MenuPrincipal.class);

                    // Pasar el nombre del usuario a la siguiente Activity
                    intent.putExtra("nombre", controlador.getUsuarioActual().getNombre());

                    // Lanzaar la actividad
                    startActivity(intent);

                    // Finalizamos la Activity de login
                    finish();
                } else {
                    Toast.makeText(UserLogin.this, "No se pudo iniciar la sesión", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown(); // Cierra el executor al destruir la Activity
    }


}