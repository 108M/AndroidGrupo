package modelos;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import modelos.Usuario;
import modelos.Usuario.Genero;

public class UsuarioTest {
    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuario = new Usuario("Carlos", 70.5f, 1.75f, 25, Genero.HOMBRE);
    }
    
    //Tests normales

    @Test
    void testConstructorValoresIniciales() {
        assertEquals("Carlos", usuario.getNombre());
        assertEquals(70.5f, usuario.getPeso(), 0.001);
        assertEquals(1.75f, usuario.getAltura(), 0.001);
        assertEquals(25, usuario.getEdad());
        assertEquals(Genero.HOMBRE, usuario.getGenero());
    }

    @Test
    void testSetNombre() {
        usuario.setNombre("Ana");
        assertEquals("Ana", usuario.getNombre());
    }

    @Test
    void testSetPeso() {
        usuario.setPeso(65.0f);
        assertEquals(65.0f, usuario.getPeso(), 0.001);
    }

    @Test
    void testSetAltura() {
        usuario.setAltura(1.80f);
        assertEquals(1.80f, usuario.getAltura(), 0.001);
    }

    @Test
    void testSetEdad() {
        usuario.setEdad(30);
        assertEquals(30, usuario.getEdad());
    }

    @Test
    void testSetGenero() {
        usuario.setGenero(Genero.MUJER);
        assertEquals(Genero.MUJER, usuario.getGenero());
    }

    @Test
    void testSetObjectId() {
        usuario.setObjectId("12345");
        assertEquals("12345", usuario.getObjectId());
    }
    
    //Test de lanzamiento de excepciones
    @Test
    void testNombreNoVacio() {
        assertThrows(IllegalArgumentException.class, () -> {
            usuario.setNombre("");
        });
    }

    @Test
    void testPesoPositivo() {
        assertThrows(IllegalArgumentException.class, () -> {
            usuario.setPeso(-5.0f);
        });
    }

    @Test
    void testAlturaPositiva() {
        assertThrows(IllegalArgumentException.class, () -> {
            usuario.setAltura(-1.70f);
        });
    }

    @Test
    void testEdadPositiva() {
        assertThrows(IllegalArgumentException.class, () -> {
            usuario.setEdad(-10);
        });
    }
}
