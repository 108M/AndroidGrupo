package modelos;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import modelos.Ejercicio;

public class EjercicioTest {
    private Ejercicio ejercicio;

    @BeforeEach
    public void setUp() {
        ejercicio = new Ejercicio("Correr", 5, "path/imagen.png", "Correcta postura", 30.0f);
    }

    @Test
    public void testCreacionCorrecta() {
        assertEquals("Correr", ejercicio.getNombre());
        assertEquals(5, ejercicio.getIntensidad());
        assertEquals("path/imagen.png", ejercicio.getImagenPath());
        assertEquals("Correcta postura", ejercicio.getTecnica());
        assertEquals(30.0f, ejercicio.getTiempoMax());
    }

    @Test
    public void testNombreNoVacio() {
        assertThrows(IllegalArgumentException.class, () -> {
            ejercicio.setNombre("");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            ejercicio.setNombre(null);
        });
    }

    @Test
    public void testIntensidadValida() {
        assertThrows(IllegalArgumentException.class, () -> {
            ejercicio.setIntensidad(-1);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            ejercicio.setIntensidad(11);
        });
    }

    @Test
    public void testTiempoMaxPositivo() {
        assertThrows(IllegalArgumentException.class, () -> {
            ejercicio.setTiempoMax(-5.0f);
        });
    }

    @Test
    public void testTecnicaNoVacia() {
        assertThrows(IllegalArgumentException.class, () -> {
            ejercicio.setTecnica("");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            ejercicio.setTecnica(null);
        });
    }

    @Test
    public void testImagenPathNoVacio() {
        assertThrows(IllegalArgumentException.class, () -> {
            ejercicio.setImagenPath("");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            ejercicio.setImagenPath(null);
        });
    }
}
