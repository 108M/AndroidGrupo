import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import modelos.ActividadFisica;
import java.util.ArrayList;

public class ActividadFisicaTest {
    private ActividadFisica actividadFisica;

    @BeforeEach
    public void setUp() {
        ArrayList<String> listaEjercicios = new ArrayList<>();
        listaEjercicios.add("ejercicio1");
        listaEjercicios.add("ejercicio2");

        actividadFisica = new ActividadFisica(listaEjercicios, 
                                              java.time.LocalTime.of(9, 0), 
                                              java.time.LocalTime.of(10, 30), 
                                              true);
    }

    @Test
    public void testCreacionCorrecta() {
        assertNotNull(actividadFisica.getListaEjerciciosIds());
        assertEquals(2, actividadFisica.getListaEjerciciosIds().size());
        assertEquals("ejercicio1", actividadFisica.getListaEjerciciosIds().get(0));
        assertEquals("09:00", actividadFisica.getHoraComienzoActividad());
        assertEquals("10:30", actividadFisica.getHoraMaximaActividad());
        assertEquals("11:00", actividadFisica.getHoraFinalizacionActividad());
        assertTrue(actividadFisica.getEstado());
    }

    @Test
    public void testListaEjerciciosIdsNoVacia() {
        assertThrows(IllegalArgumentException.class, () -> {
            actividadFisica.setListaEjerciciosIds(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            actividadFisica.setListaEjerciciosIds(new ArrayList<>());
        });
    }

    @Test
    public void testHorasNoVacias() {
        assertThrows(IllegalArgumentException.class, () -> {
            actividadFisica.setHoraComienzoActividad("");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            actividadFisica.setHoraMaximaActividad("");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            actividadFisica.setHoraFinalizacionActividad("");
        });
    }

    @Test
    public void testEstadoValido() {
        assertThrows(IllegalArgumentException.class, () -> {
            actividadFisica.setEstado(null);
        });
    }
}
