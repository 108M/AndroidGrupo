package modelos;

import java.util.ArrayList;
import java.util.Date;

public class Historia {
    private String objectId;
    private Date fecha;
    private String actividadRegistradaId;
    private estadoFinalizacion estadoFinalizacion;
    private ArrayList<String> imagenesEjerciciosPaths; // Rutas de las imágenes en lugar de ImageIcon

    // Constructor
    public Historia(Date fecha, String actividadRegistradaId, estadoFinalizacion estadoFinalizacion, ArrayList<String> imagenesEjerciciosPaths) {
        this.fecha = fecha;
        this.actividadRegistradaId = actividadRegistradaId;
        this.estadoFinalizacion = estadoFinalizacion;
        this.imagenesEjerciciosPaths = imagenesEjerciciosPaths;
    }

    // Getters y Setters
    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        if (fecha == null) {
            throw new IllegalArgumentException("La fecha no puede ser null.");
        }
        this.fecha = fecha;
    }

    public String getActividadRegistradaId() {
        return actividadRegistradaId;
    }

    public void setActividadRegistradaId(String actividadRegistradaId) {
        if (actividadRegistradaId == null || actividadRegistradaId.trim().isEmpty()) {
            throw new IllegalArgumentException("La actividad registrada ID no puede estar vacío.");
        }
        this.actividadRegistradaId = actividadRegistradaId;
    }

    public estadoFinalizacion getEstadoFinalizacion() {
        return estadoFinalizacion;
    }

    public void setEstadoFinalizacion(estadoFinalizacion estadoFinalizacion) {
        if (estadoFinalizacion == null) {
            throw new IllegalArgumentException("El estado de finalización no puede ser null.");
        }
        this.estadoFinalizacion = estadoFinalizacion;
    }

    public ArrayList<String> getImagenesEjerciciosPaths() {
        return imagenesEjerciciosPaths;
    }

    public void setImagenesEjerciciosPaths(ArrayList<String> imagenesEjerciciosPaths) {
        if (imagenesEjerciciosPaths == null || imagenesEjerciciosPaths.isEmpty()) {
            throw new IllegalArgumentException("Las imágenes no pueden estar vacías.");
        }
        for (String imagenPath : imagenesEjerciciosPaths) {
            if (imagenPath == null || imagenPath.trim().isEmpty()) {
                throw new IllegalArgumentException("Las rutas de las imágenes no pueden estar vacías.");
            }
        }
        this.imagenesEjerciciosPaths = imagenesEjerciciosPaths;
    }

    public enum estadoFinalizacion {
        FACIL, MEDIO, DIFICIL, IMPOSIBLE
    }
}