package vista;

import controlador.App;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import modelos.Usuario;

public class LoginRegistroVista extends JFrame {
    private App controlador;
    private JPanel cardPanel;
    private CardLayout cardLayout;
    
    public LoginRegistroVista() {
        this.controlador = new App();
        setTitle("BeFit - Login/Registro");
        setSize(400, 350); // Aumentamos el tamaño para el formulario de registro
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Usamos CardLayout para cambiar entre login y registro
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        
        // Crear paneles
        cardPanel.add(crearPanelLogin(), "login");
        cardPanel.add(crearPanelRegistro(), "registro");
        
        // Mostrar primero el panel de login
        cardLayout.show(cardPanel, "login");
        
        add(cardPanel);
    }
    
    private JPanel crearPanelLogin() {
        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel lblTitulo = new JLabel("BeFit", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        
        JTextField txtNombre = new JTextField();
        txtNombre.setBorder(BorderFactory.createTitledBorder("Nombre de Usuario"));
        
        JButton btnLogin = new JButton("Iniciar Sesión");
        JButton btnIrARegistro = new JButton("Registrarse");
        
        btnLogin.addActionListener(e -> {
            String nombre = txtNombre.getText().trim();
            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingresa un nombre de usuario");
                return;
            }
            
            if (controlador.iniciarSesion(nombre)) {
                new MenuPrincipalVista(controlador).mostrar();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Usuario no encontrado");
            }
        });
        
        btnIrARegistro.addActionListener(e -> {
            cardLayout.show(cardPanel, "registro");
        });
        
        panel.add(lblTitulo);
        panel.add(txtNombre);
        
        JPanel botonesPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        botonesPanel.add(btnLogin);
        botonesPanel.add(btnIrARegistro);
        panel.add(botonesPanel);
        
        return panel;
    }
    
    private JPanel crearPanelRegistro() {
        JPanel panel = new JPanel(new GridLayout(7, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JTextField txtNombre = new JTextField();
        JTextField txtPeso = new JTextField();
        JTextField txtAltura = new JTextField();
        JTextField txtEdad = new JTextField();
        JComboBox<Usuario.Genero> comboGenero = new JComboBox<>(Usuario.Genero.values());
        
        panel.add(new JLabel("Nombre:"));
        panel.add(txtNombre);
        panel.add(new JLabel("Peso (kg):"));
        panel.add(txtPeso);
        panel.add(new JLabel("Altura (m):"));
        panel.add(txtAltura);
        panel.add(new JLabel("Edad:"));
        panel.add(txtEdad);
        panel.add(new JLabel("Género:"));
        panel.add(comboGenero);

        JButton btnRegistrar = new JButton("Registrarse");
        JButton btnVolver = new JButton("Volver a Login");
        
        btnRegistrar.addActionListener(e -> {
            try {
                String nombre = txtNombre.getText().trim();
                float peso = Float.parseFloat(txtPeso.getText());
                float altura = Float.parseFloat(txtAltura.getText());
                int edad = Integer.parseInt(txtEdad.getText());
                Usuario.Genero genero = (Usuario.Genero) comboGenero.getSelectedItem();

                if (nombre.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "El nombre no puede estar vacío");
                    return;
                }

                if (controlador.registrarUsuario(nombre, peso, altura, edad, genero)) {
                    new MenuPrincipalVista(controlador).mostrar();
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "El nombre de usuario ya existe");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese valores válidos para peso, altura y edad");
            }
        });
        
        btnVolver.addActionListener(e -> {
            cardLayout.show(cardPanel, "login");
        });

        panel.add(btnRegistrar);
        panel.add(btnVolver);

        return panel;
    }
    
    public void mostrar() {
        setVisible(true);
    }
}