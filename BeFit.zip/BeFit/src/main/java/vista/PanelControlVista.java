package vista;

import controlador.ControladorJFrame;
import modelos.Usuario;
import modelos.Historia;
import javax.swing.*;
import java.awt.*;
import java.util.Date;

public class PanelControlVista extends JFrame {

    private ControladorJFrame controlador;

    public PanelControlVista(ControladorJFrame controlador) {
        this.controlador = controlador;
        setTitle("Panel de Control");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Crear botones
        JButton btnCrearUsuario = new JButton("Crear Usuario");
        JButton btnListarUsuarios = new JButton("Listar Usuarios");
        JButton btnCrearActividad = new JButton("Crear Actividad");
        JButton btnListarActividades = new JButton("Listar Actividades");
        JButton btnCrearEjercicio = new JButton("Crear Ejercicio");
        JButton btnListarEjercicios = new JButton("Listar Ejercicios");
        JButton btnCrearHistoria = new JButton("Crear Historia");
        JButton btnListarHistorias = new JButton("Listar Historias");
        JButton btnCrearHistorial = new JButton("Crear Historial");
        JButton btnListarHistoriales = new JButton("Listar Historiales");

        // Configurar el layout
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.add(btnCrearUsuario);
        panel.add(btnListarUsuarios);
        panel.add(btnCrearActividad);
        panel.add(btnListarActividades);
        panel.add(btnCrearEjercicio);
        panel.add(btnListarEjercicios);
        panel.add(btnCrearHistoria);
        panel.add(btnListarHistorias);
        panel.add(btnCrearHistorial);
        panel.add(btnListarHistoriales);

        // Añadir el panel al JFrame
        add(panel);

        // Asignar acciones a los botones
        btnCrearUsuario.addActionListener(e -> crearUsuario());
        btnListarUsuarios.addActionListener(e -> listarUsuarios());
        btnCrearActividad.addActionListener(e -> crearActividad());
        btnListarActividades.addActionListener(e -> listarActividades());
        btnCrearEjercicio.addActionListener(e -> crearEjercicio());
        btnListarEjercicios.addActionListener(e -> listarEjercicios());
        btnCrearHistoria.addActionListener(e -> crearHistoria());
        btnListarHistorias.addActionListener(e -> listarHistorias());
        btnCrearHistorial.addActionListener(e -> crearHistorial());
        btnListarHistoriales.addActionListener(e -> listarHistoriales());
    }

    private void crearUsuario() {
        JTextField nombreField = new JTextField();
        JTextField idField = new JTextField();
        JTextField pesoField = new JTextField();
        JTextField alturaField = new JTextField();
        JTextField edadField = new JTextField();
        JComboBox<Usuario.Genero> generoCombo = new JComboBox<>(Usuario.Genero.values());

        JPanel panel = new JPanel(new GridLayout(6, 2));
        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("ID:"));
        panel.add(idField);
        panel.add(new JLabel("Peso:"));
        panel.add(pesoField);
        panel.add(new JLabel("Altura:"));
        panel.add(alturaField);
        panel.add(new JLabel("Edad:"));
        panel.add(edadField);
        panel.add(new JLabel("Género:"));
        panel.add(generoCombo);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Usuario", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String nombre = nombreField.getText();
            int id = Integer.parseInt(idField.getText());
            float peso = Float.parseFloat(pesoField.getText());
            float altura = Float.parseFloat(alturaField.getText());
            int edad = Integer.parseInt(edadField.getText());
            Usuario.Genero genero = (Usuario.Genero) generoCombo.getSelectedItem();

            controlador.crearUsuario(nombre, id, peso, altura, edad, genero);
        }
    }

    private void listarUsuarios() {
        JList<String> list = new JList<>(controlador.getListModelUsuarios());
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Usuarios", JOptionPane.PLAIN_MESSAGE);
    }

    private void crearActividad() {
        JTextField idField = new JTextField();
        JTextField horaComienzoField = new JTextField();
        JTextField horaMaximaField = new JTextField();
        JTextField horaFinalizacionField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("ID:"));
        panel.add(idField);
        panel.add(new JLabel("Hora de comienzo (HH:MM):"));
        panel.add(horaComienzoField);
        panel.add(new JLabel("Hora máxima (HH:MM):"));
        panel.add(horaMaximaField);
        panel.add(new JLabel("Hora de finalización (HH:MM):"));
        panel.add(horaFinalizacionField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Actividad", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            int id = Integer.parseInt(idField.getText());
            String horaComienzo = horaComienzoField.getText();
            String horaMaxima = horaMaximaField.getText();
            String horaFinalizacion = horaFinalizacionField.getText();

            controlador.crearActividad(id, horaComienzo, horaMaxima, horaFinalizacion);
        }
    }

    private void listarActividades() {
        JList<String> list = new JList<>(controlador.getListModelActividades());
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Actividades", JOptionPane.PLAIN_MESSAGE);
    }

    private void crearEjercicio() {
        JTextField nombreField = new JTextField();
        JTextField intensidadField = new JTextField();
        JTextField tecnicaField = new JTextField();
        JTextField tiempoMaxField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("Intensidad:"));
        panel.add(intensidadField);
        panel.add(new JLabel("Técnica:"));
        panel.add(tecnicaField);
        panel.add(new JLabel("Tiempo máximo (minutos):"));
        panel.add(tiempoMaxField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Ejercicio", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String nombre = nombreField.getText();
            int intensidad = Integer.parseInt(intensidadField.getText());
            String tecnica = tecnicaField.getText();
            float tiempoMax = Float.parseFloat(tiempoMaxField.getText());

            controlador.crearEjercicio(nombre, intensidad, tecnica, tiempoMax);
        }
    }

    private void listarEjercicios() {
        JList<String> list = new JList<>(controlador.getListModelEjercicios());
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Ejercicios", JOptionPane.PLAIN_MESSAGE);
    }

    private void crearHistoria() {
        JTextField idActividadField = new JTextField();
        JComboBox<Historia.estadoFinalizacion> estadoCombo = new JComboBox<>(Historia.estadoFinalizacion.values());

        JPanel panel = new JPanel(new GridLayout(2, 2));
        panel.add(new JLabel("ID de la actividad:"));
        panel.add(idActividadField);
        panel.add(new JLabel("Estado de finalización:"));
        panel.add(estadoCombo);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Historia", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            int idActividad = Integer.parseInt(idActividadField.getText());
            Historia.estadoFinalizacion estado = (Historia.estadoFinalizacion) estadoCombo.getSelectedItem();

            controlador.crearHistoria(new Date(), idActividad, estado);
        }
    }

    private void listarHistorias() {
        JList<String> list = new JList<>(controlador.getListModelHistorias());
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Historias", JOptionPane.PLAIN_MESSAGE);
    }

    private void crearHistorial() {
        JTextField idUsuarioField = new JTextField();
        JTextField idHistoriaField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(2, 2));
        panel.add(new JLabel("ID del usuario:"));
        panel.add(idUsuarioField);
        panel.add(new JLabel("ID de la historia:"));
        panel.add(idHistoriaField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Historial", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            int idUsuario = Integer.parseInt(idUsuarioField.getText());
            int idHistoria = Integer.parseInt(idHistoriaField.getText());

            controlador.crearHistorial(idUsuario, idHistoria);
        }
    }

    private void listarHistoriales() {
        JList<String> list = new JList<>(controlador.getListModelHistoriales());
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Historiales", JOptionPane.PLAIN_MESSAGE);
    }

    public void mostrar() {
        setVisible(true);
    }
}