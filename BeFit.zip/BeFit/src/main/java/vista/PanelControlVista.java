package vista;

import controlador.ControladorJFrame;
import modelos.Usuario;
import modelos.Historia;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import javax.imageio.ImageIO;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class PanelControlVista extends JFrame {

    private ControladorJFrame controlador;
    private final OkHttpClient httpClient = new OkHttpClient();

    public PanelControlVista(ControladorJFrame controlador) {
        this.controlador = controlador;
        setTitle("Panel de Control");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Crear botones
        JButton btnCrearUsuario = new JButton("Crear Usuario");
        JButton btnListarUsuarios = new JButton("Listar Usuarios");
        JButton btnCrearActividad = new JButton("Crear Actividad");
        JButton btnListarActividades = new JButton("Listar Actividades");
        JButton btnCrearEjercicio = new JButton("Crear Ejercicio");
        JButton btnListarEjercicios = new JButton("Listar Ejercicios");
        JButton btnCrearHistoria = new JButton("Crear Historia");
        JButton btnListarHistorias = new JButton("Listar Historias");
        JButton btnCrearHistorial = new JButton("Crear Historial");
        JButton btnListarHistoriales = new JButton("Listar Historiales");

        // Configurar el layout
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.add(btnCrearUsuario);
        panel.add(btnListarUsuarios);
        panel.add(btnCrearActividad);
        panel.add(btnListarActividades);
        panel.add(btnCrearEjercicio);
        panel.add(btnListarEjercicios);
        panel.add(btnCrearHistoria);
        panel.add(btnListarHistorias);
        panel.add(btnCrearHistorial);
        panel.add(btnListarHistoriales);

        // Añadir el panel al JFrame
        add(panel);

        // Asignar acciones a los botones
        btnCrearUsuario.addActionListener(e -> crearUsuario());
        btnListarUsuarios.addActionListener(e -> listarUsuarios());
        btnCrearActividad.addActionListener(e -> crearActividad());
        btnListarActividades.addActionListener(e -> listarActividades());
        btnCrearEjercicio.addActionListener(e -> crearEjercicio());
        btnListarEjercicios.addActionListener(e -> listarEjercicios());
        btnCrearHistoria.addActionListener(e -> crearHistoria());
        btnListarHistorias.addActionListener(e -> listarHistorias());
        btnCrearHistorial.addActionListener(e -> crearHistorial());
        btnListarHistoriales.addActionListener(e -> listarHistoriales());
        
        
    }

    private void crearUsuario() {
        JTextField nombreField = new JTextField();
        JTextField pesoField = new JTextField();
        JTextField alturaField = new JTextField();
        JTextField edadField = new JTextField();
        JComboBox<Usuario.Genero> generoCombo = new JComboBox<>(Usuario.Genero.values());

        JPanel panel = new JPanel(new GridLayout(5, 2));
        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("Peso:"));
        panel.add(pesoField);
        panel.add(new JLabel("Altura:"));
        panel.add(alturaField);
        panel.add(new JLabel("Edad:"));
        panel.add(edadField);
        panel.add(new JLabel("Género:"));
        panel.add(generoCombo);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Usuario", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String nombre = nombreField.getText();
                float peso = Float.parseFloat(pesoField.getText());
                float altura = Float.parseFloat(alturaField.getText());
                int edad = Integer.parseInt(edadField.getText());
                Usuario.Genero genero = (Usuario.Genero) generoCombo.getSelectedItem();

                controlador.crearUsuario(nombre, peso, altura, edad, genero);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Ingresa valores numéricos válidos para peso, altura y edad.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void listarUsuarios() {
        JList<String> list = new JList<>(controlador.getListModelUsuarios());
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Usuarios", JOptionPane.PLAIN_MESSAGE);
    }

    private void crearActividad() {
        JTextField horaComienzoField = new JTextField();
        JTextField horaMaximaField = new JTextField();
        JTextField horaFinalizacionField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(new JLabel("Hora de comienzo (HH:MM):"));
        panel.add(horaComienzoField);
        panel.add(new JLabel("Hora máxima (HH:MM):"));
        panel.add(horaMaximaField);
        panel.add(new JLabel("Hora de finalización (HH:MM):"));
        panel.add(horaFinalizacionField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Actividad", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String horaComienzo = horaComienzoField.getText();
            String horaMaxima = horaMaximaField.getText();
            String horaFinalizacion = horaFinalizacionField.getText();

            controlador.crearActividad(horaComienzo, horaMaxima, horaFinalizacion);
        }
    }

    private void listarActividades() {
        JList<String> list = new JList<>(controlador.getListModelActividades());
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Actividades", JOptionPane.PLAIN_MESSAGE);
    }

    private void crearEjercicio() {
        JTextField nombreField = new JTextField();
        JTextField intensidadField = new JTextField();
        JTextField imagenPathField = new JTextField(); // Campo para la ruta de la imagen
        JTextField tecnicaField = new JTextField();
        JTextField tiempoMaxField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(5, 2));
        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("Intensidad:"));
        panel.add(intensidadField);
        panel.add(new JLabel("Ruta de la imagen:"));
        panel.add(imagenPathField);
        panel.add(new JLabel("Técnica:"));
        panel.add(tecnicaField);
        panel.add(new JLabel("Tiempo máximo (minutos):"));
        panel.add(tiempoMaxField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Ejercicio", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String nombre = nombreField.getText();
                int intensidad = Integer.parseInt(intensidadField.getText());
                String imagenPath = imagenPathField.getText(); // Obtener la ruta de la imagen
                String tecnica = tecnicaField.getText();
                float tiempoMax = Float.parseFloat(tiempoMaxField.getText());

                controlador.crearEjercicio(nombre, intensidad, imagenPath, tecnica, tiempoMax);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Ingresa valores numéricos válidos para intensidad y tiempo máximo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void listarEjercicios() {
        JList<String> list = new JList<>(controlador.getListModelEjercicios());
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Ejercicios", JOptionPane.PLAIN_MESSAGE);
    }

    private void crearHistoria() {
        JTextField idActividadField = new JTextField();
        JComboBox<Historia.estadoFinalizacion> estadoCombo = new JComboBox<>(Historia.estadoFinalizacion.values());
        JTextField imagenPathField = new JTextField();
        JTextField latitudField = new JTextField();
        JTextField longitudField = new JTextField();

        JButton btnSeleccionarImagen = new JButton("Seleccionar Imagen");
        btnSeleccionarImagen.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                imagenPathField.setText(fileChooser.getSelectedFile().getAbsolutePath());
            }
        });

        JPanel panel = new JPanel(new GridLayout(6, 2));
        panel.add(new JLabel("ID de la actividad:"));
        panel.add(idActividadField);
        panel.add(new JLabel("Estado de finalización:"));
        panel.add(estadoCombo);
        panel.add(new JLabel("Imagen:"));
        panel.add(imagenPathField);
        panel.add(new JLabel(""));
        panel.add(btnSeleccionarImagen);
        panel.add(new JLabel("Latitud:"));
        panel.add(latitudField);
        panel.add(new JLabel("Longitud:"));
        panel.add(longitudField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Historia", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String idActividad = idActividadField.getText();
                Historia.estadoFinalizacion estado = (Historia.estadoFinalizacion) estadoCombo.getSelectedItem();
                File imagenFile = new File(imagenPathField.getText());
                double latitud = Double.parseDouble(latitudField.getText());
                double longitud = Double.parseDouble(longitudField.getText());

                controlador.crearHistoria(new Date(), idActividad, estado, imagenFile, latitud, longitud);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Latitud y longitud deben ser números válidos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void listarHistorias() {
        DefaultListModel<String> model = controlador.getListModelHistorias();
        JList<String> list = new JList<>(model);
        
        // Agregar listener para mostrar la imagen al hacer clic
        list.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 1) { // Simple clic
                    int index = list.locationToIndex(evt.getPoint());
                    if (index >= 0) {
                        mostrarDetalleHistoria(index);
                    }
                }
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Historias", JOptionPane.PLAIN_MESSAGE);
    }
    
    private void mostrarDetalleHistoria(int index) {
        // Obtener todas las historias
        java.util.List<Historia> historias = controlador.getHistoriaDAO().obtenerTodasLasHistorias();
        if (index >= 0 && index < historias.size()) {
            Historia historia = historias.get(index);
            
            // Crear diálogo para mostrar detalles
            JDialog detalleDialog = new JDialog(this, "Detalles de Historia", true);
            detalleDialog.setSize(600, 500);
            detalleDialog.setLayout(new BorderLayout());
            
            // Panel de información
            JPanel infoPanel = new JPanel(new GridLayout(0, 1));
            infoPanel.add(new JLabel("Fecha: " + new SimpleDateFormat("dd/MM/yyyy HH:mm").format(historia.getFecha())));
            infoPanel.add(new JLabel("Estado: " + historia.getEstadoFinalizacion()));
            infoPanel.add(new JLabel("Ubicación: Lat " + historia.getLatitud() + ", Long " + historia.getLongitud()));
            
            // Panel de imagen
            JPanel imagenPanel = new JPanel(new BorderLayout());
            
            if (historia.getImagen() != null && !historia.getImagen().isEmpty()) {
                cargarImagen(historia.getImagen(), imagenPanel);
            } else {
                imagenPanel.add(new JLabel("No hay imagen disponible", SwingConstants.CENTER), BorderLayout.CENTER);
            }
            
            // Panel principal con split pane
            JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, 
                new JScrollPane(infoPanel), imagenPanel);
            splitPane.setResizeWeight(0.3);
            
            detalleDialog.add(splitPane, BorderLayout.CENTER);
            
            // Botón de cerrar
            JButton btnCerrar = new JButton("Cerrar");
            btnCerrar.addActionListener(e -> detalleDialog.dispose());
            detalleDialog.add(btnCerrar, BorderLayout.SOUTH);
            
            detalleDialog.setLocationRelativeTo(this);
            detalleDialog.setVisible(true);
        }
    }
    
    private void cargarImagen(String imageUrl, JPanel imagenPanel) {
        JLabel lblCargando = new JLabel("Cargando imagen...", SwingConstants.CENTER);
        imagenPanel.add(lblCargando, BorderLayout.CENTER);
        imagenPanel.revalidate();

        new SwingWorker<ImageIcon, Void>() {
            @Override
            protected ImageIcon doInBackground() throws Exception {
                return descargarImagen(imageUrl);
            }

            @Override
            protected void done() {
                try {
                    ImageIcon imageIcon = get();
                    imagenPanel.removeAll();

                    if (imageIcon != null) {
                        // Escalar la imagen manteniendo el aspect ratio
                        Image img = imageIcon.getImage();
                        int ancho = 400;
                        int alto = (int) (ancho * ((double) img.getHeight(null) / img.getWidth(null)));
                        Image scaledImage = img.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);

                        JLabel lblImagen = new JLabel(new ImageIcon(scaledImage));
                        lblImagen.setHorizontalAlignment(SwingConstants.CENTER);
                        imagenPanel.add(lblImagen, BorderLayout.CENTER);
                    } else {
                        imagenPanel.add(new JLabel("No se pudo cargar la imagen", SwingConstants.CENTER), BorderLayout.CENTER);
                    }
                } catch (Exception e) {
                    imagenPanel.add(new JLabel("Error al cargar imagen", SwingConstants.CENTER), BorderLayout.CENTER);
                    e.printStackTrace();
                }
                imagenPanel.revalidate();
                imagenPanel.repaint();
            }
        }.execute();
    }

    private ImageIcon descargarImagen(String imageUrl) {
        try {
            Request request = new Request.Builder()
                .url(imageUrl)
                .addHeader("X-Parse-Application-Id", "CdXSEGccBwT7HOAe8T3sE6CNuFiOyJDE9DNFEhJt")
                .addHeader("X-Parse-REST-API-Key", "jcxfHzxoP8jDYslcfGUSbhgMNQn8Iam1Cda35WpJ")
                .build();

            try (Response response = httpClient.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    System.err.println("Error al descargar imagen: " + response.code());
                    return null;
                }

                byte[] imageData = response.body().bytes();
                BufferedImage img = ImageIO.read(new java.io.ByteArrayInputStream(imageData));
                return img != null ? new ImageIcon(img) : null;
            }
        } catch (IOException e) {
            System.err.println("Error al descargar imagen: " + e.getMessage());
            return null;
        }
    }

    private void crearHistorial() {
        JTextField idUsuarioField = new JTextField();
        JTextField idHistoriaField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(2, 2));
        panel.add(new JLabel("ID del usuario:"));
        panel.add(idUsuarioField);
        panel.add(new JLabel("ID de la historia:"));
        panel.add(idHistoriaField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Historial", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String idUsuario = idUsuarioField.getText();
            String idHistoria = idHistoriaField.getText();

            controlador.crearHistorial(idUsuario, idHistoria);
        }
    }

    private void listarHistoriales() {
        JList<String> list = new JList<>(controlador.getListModelHistoriales());
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Historiales", JOptionPane.PLAIN_MESSAGE);
    }

    public void mostrar() {
        setVisible(true);
    }
}