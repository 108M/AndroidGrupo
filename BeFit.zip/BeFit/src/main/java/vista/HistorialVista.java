package vista;

import controlador.ControladorApp;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.imageio.ImageIO;
import modelos.ActividadFisica;
import modelos.Ejercicio;
import modelos.Historia;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class HistorialVista extends JFrame {
    private ControladorApp controlador;
    private final OkHttpClient httpClient = new OkHttpClient();
    private final String APPLICATION_ID = "CdXSEGccBwT7HOAe8T3sE6CNuFiOyJDE9DNFEhJt";
    private final String REST_API_KEY = "jcxfHzxoP8jDYslcfGUSbhgMNQn8Iam1Cda35WpJ";

    public HistorialVista(ControladorApp controlador) {
        this.controlador = controlador;
        initUI();
    }

    private void initUI() {
        setTitle("BeFit - Mi Historial");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());
        List<Historia> historial = controlador.obtenerHistorialUsuario();

        if (historial.isEmpty()) {
            panel.add(new JLabel("No hay actividades registradas", SwingConstants.CENTER), BorderLayout.CENTER);
        } else {
            DefaultListModel<String> listModel = new DefaultListModel<>();
            for (Historia h : historial) {
                String estado = h.getEstadoFinalizacion() != null ? h.getEstadoFinalizacion().toString() : "Sin estado";
                String fecha = new SimpleDateFormat("dd/MM/yyyy").format(h.getFecha());
                listModel.addElement(fecha + " - " + estado + (h.getImagen() != null ? " 📷" : ""));
            }

            JList<String> listaHistorial = new JList<>(listModel);
            listaHistorial.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            listaHistorial.setFont(new Font("SansSerif", Font.PLAIN, 14));

            listaHistorial.addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting()) {
                    int index = listaHistorial.getSelectedIndex();
                    if (index >= 0) {
                        mostrarDetalleActividad(historial.get(index));
                    }
                }
            });

            panel.add(new JScrollPane(listaHistorial), BorderLayout.CENTER);
        }

        JButton btnVolver = new JButton("Volver al Menú");
        btnVolver.addActionListener(e -> {
            new MenuPrincipalVista(controlador).mostrar();
            dispose();
        });

        panel.add(btnVolver, BorderLayout.SOUTH);
        add(panel);
    }

    private void mostrarDetalleActividad(Historia historia) {
        JDialog detalleDialog = new JDialog(this, "Detalle de Actividad", true);
        detalleDialog.setSize(800, 600);
        detalleDialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel de información
        ActividadFisica actividad = controlador.getActividadFisicaDAO()
            .obtenerActividadFisicaPorId(historia.getActividadRegistradaId());
        
        JPanel infoPanel = new JPanel(new GridLayout(0, 1, 5, 5));
        infoPanel.add(new JLabel("Fecha: " + new SimpleDateFormat("dd/MM/yyyy HH:mm").format(historia.getFecha())));
        infoPanel.add(new JLabel("Ubicación: Lat " + historia.getLatitud() + ", Long " + historia.getLongitud()));
        infoPanel.add(new JLabel("Estado: " + historia.getEstadoFinalizacion().toString()));

        if (actividad != null) {
            infoPanel.add(new JLabel("Duración: " + actividad.getHoraComienzoActividad() + 
                                   " - " + actividad.getHoraFinalizacionActividad()));

            if (actividad.getEjercicios() != null && !actividad.getEjercicios().isEmpty()) {
                //infoPanel.add(new JLabel(" "));
                infoPanel.add(new JLabel("Ejercicios realizados:"));

                for (Ejercicio ejercicio : actividad.getEjercicios()) {
                    infoPanel.add(new JLabel(" - " + ejercicio.getNombre() + 
                                           " (Intensidad: " + ejercicio.getIntensidad() + 
                                           ", Tiempo: " + ejercicio.getTiempoMax() + " min)"));
                }
            }
        }
        
        // Panel de imagen
        JPanel imagenPanel = new JPanel(new BorderLayout());
        imagenPanel.setPreferredSize(new Dimension(400, 400));

        if (historia.getImagen() != null && !historia.getImagen().isEmpty()) {
            cargarImagenAsync(historia.getImagen(), imagenPanel);
        } else {
            imagenPanel.add(new JLabel("No hay imagen registrada", SwingConstants.CENTER), BorderLayout.CENTER);
        }

        JScrollPane scrollInfo = new JScrollPane(infoPanel);
        scrollInfo.setPreferredSize(new Dimension(300, 400));

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollInfo, imagenPanel);
        splitPane.setResizeWeight(0.5);

        panel.add(splitPane, BorderLayout.CENTER);

        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.addActionListener(e -> detalleDialog.dispose());
        panel.add(btnCerrar, BorderLayout.SOUTH);

        detalleDialog.add(panel);
        detalleDialog.setVisible(true);
    }

    private void cargarImagenAsync(String imageUrl, JPanel imagenPanel) {
        JLabel lblCargando = new JLabel("Cargando imagen...", SwingConstants.CENTER);
        imagenPanel.add(lblCargando, BorderLayout.CENTER);
        imagenPanel.revalidate();

        new SwingWorker<ImageIcon, Void>() {
            @Override
            protected ImageIcon doInBackground() throws Exception {
                return descargarImagen(imageUrl);
            }

            @Override
            protected void done() {
                try {
                    ImageIcon imageIcon = get();
                    imagenPanel.removeAll();

                    if (imageIcon != null) {
                        // Escalar la imagen manteniendo el aspect ratio
                        Image img = imageIcon.getImage();
                        int ancho = 400;
                        int alto = (int) (ancho * ((double) img.getHeight(null) / img.getWidth(null)));
                        Image scaledImage = img.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);

                        JLabel lblImagen = new JLabel(new ImageIcon(scaledImage));
                        lblImagen.setHorizontalAlignment(SwingConstants.CENTER);
                        imagenPanel.add(lblImagen, BorderLayout.CENTER);
                    } else {
                        imagenPanel.add(new JLabel("No se pudo cargar la imagen", SwingConstants.CENTER), BorderLayout.CENTER);
                    }
                } catch (Exception e) {
                    imagenPanel.add(new JLabel("Error al cargar imagen", SwingConstants.CENTER), BorderLayout.CENTER);
                    e.printStackTrace();
                }
                imagenPanel.revalidate();
                imagenPanel.repaint();
            }
        }.execute();
    }

    private ImageIcon descargarImagen(String imageUrl) {
        try {
            Request request = new Request.Builder()
                .url(imageUrl)
                .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                .build();

            try (Response response = httpClient.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    System.err.println("Error al descargar imagen: " + response.code());
                    return null;
                }

                byte[] imageData = response.body().bytes();
                BufferedImage img = ImageIO.read(new java.io.ByteArrayInputStream(imageData));
                return img != null ? new ImageIcon(img) : null;
            }
        } catch (IOException e) {
            System.err.println("Error al descargar imagen: " + e.getMessage());
            return null;
        }
    }

    public void mostrar() {
        setVisible(true);
    }
}