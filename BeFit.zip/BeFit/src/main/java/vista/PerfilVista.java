package vista;

import controlador.App;
import javax.swing.*;
import java.awt.*;
import modelos.Usuario;

public class PerfilVista extends JFrame {
    private App controlador;
    private JTextField txtNombre, txtPeso, txtAltura, txtEdad;
    private JComboBox<Usuario.Genero> comboGenero;

    public PerfilVista(App controlador) {
        this.controlador = controlador;
        setTitle("BeFit - Mi Perfil");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initComponentes();
        cargarDatosUsuario();
    }

    private void initComponentes() {
        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        txtNombre = new JTextField();
        txtPeso = new JTextField();
        txtAltura = new JTextField();
        txtEdad = new JTextField();
        comboGenero = new JComboBox<>(Usuario.Genero.values());
        
        panel.add(new JLabel("Nombre:"));
        panel.add(txtNombre);
        panel.add(new JLabel("Peso (kg):"));
        panel.add(txtPeso);
        panel.add(new JLabel("Altura (m):"));
        panel.add(txtAltura);
        panel.add(new JLabel("Edad:"));
        panel.add(txtEdad);
        panel.add(new JLabel("Género:"));
        panel.add(comboGenero);

        JButton btnGuardar = new JButton("Guardar Cambios");
        btnGuardar.addActionListener(e -> guardarCambios());
        
        JButton btnVolver = new JButton("Volver al Menú");
        btnVolver.addActionListener(e -> volverAlMenu());

        panel.add(btnGuardar);
        panel.add(btnVolver);

        add(panel);
    }

    private void cargarDatosUsuario() {
        Usuario usuario = controlador.getUsuarioActual();
        if (usuario != null) {
            txtNombre.setText(usuario.getNombre());
            txtPeso.setText(String.valueOf(usuario.getPeso()));
            txtAltura.setText(String.valueOf(usuario.getAltura()));
            txtEdad.setText(String.valueOf(usuario.getEdad()));
            comboGenero.setSelectedItem(usuario.getGenero());
        }
    }

    private void guardarCambios() {
        try {
            String nombre = txtNombre.getText().trim();
            float peso = Float.parseFloat(txtPeso.getText());
            float altura = Float.parseFloat(txtAltura.getText());
            int edad = Integer.parseInt(txtEdad.getText());
            Usuario.Genero genero = (Usuario.Genero) comboGenero.getSelectedItem();

            if (controlador.actualizarPerfil(nombre, peso, altura, edad, genero)) {
                JOptionPane.showMessageDialog(this, "Perfil actualizado con éxito");
                volverAlMenu();
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar el perfil. Verifique los datos.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingrese valores válidos para peso, altura y edad");
        }
    }

    private void volverAlMenu() {
        new MenuPrincipalVista(controlador).mostrar();
        dispose();
    }

    public void mostrar() {
        setVisible(true);
    }
}