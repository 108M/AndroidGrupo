package vista;

import controlador.ControladorApp;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.time.Duration;
import java.time.LocalTime;
import java.util.List;
import javax.swing.Timer;
import modelos.ActividadFisica;
import modelos.Ejercicio;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class ActividadDiariaVista extends JFrame {
    private ControladorApp controlador;
    private Timer timer;
    private JLabel lblTiempo;
    private JList<String> listaEjercicios;
    private long segundosRestantes;
    private ActividadFisica actividad;

    public ActividadDiariaVista(ControladorApp controlador) {
        this.controlador = controlador;
        configurarVentana();
        initComponentes();
    }

    private void configurarVentana() {
        setTitle("BeFit - Actividad Diaria");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void initComponentes() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        actividad = controlador.generarActividadDiaria();
        if (actividad == null) {
            JOptionPane.showMessageDialog(this, "No se pudo generar la actividad diaria");
            dispose();
            return;
        }

        lblTiempo = new JLabel("", SwingConstants.CENTER);
        lblTiempo.setFont(new Font("Arial", Font.BOLD, 24));

        // Cambiar de JTextArea a JList para permitir selección
        DefaultListModel<String> model = new DefaultListModel<>();
        listaEjercicios = new JList<>(model);
        listaEjercicios.setFont(new Font("Arial", Font.PLAIN, 16));
        
        // Agregar listener para mostrar imagen al hacer clic
        listaEjercicios.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 1) {
                    int index = listaEjercicios.locationToIndex(evt.getPoint());
                    if (index >= 0) {
                        mostrarImagenEjercicio(index);
                    }
                }
            }
        });
        
        JScrollPane scrollEjercicios = new JScrollPane(listaEjercicios);

        JButton btnFinalizar = new JButton("Finalizar Actividad y Tomar Foto");
        btnFinalizar.setFont(new Font("Arial", Font.BOLD, 14));
        btnFinalizar.addActionListener(e -> finalizarActividad());

        panel.add(lblTiempo, BorderLayout.NORTH);
        panel.add(scrollEjercicios, BorderLayout.CENTER);
        panel.add(btnFinalizar, BorderLayout.SOUTH);

        cargarEjercicios(actividad);
        configurarTemporizador(actividad);

        add(panel);
    }

    private void cargarEjercicios(ActividadFisica actividad) {
        DefaultListModel<String> model = (DefaultListModel<String>) listaEjercicios.getModel();
        model.clear();
        
        if (actividad.getEjercicios() != null) {
            for (Ejercicio ejercicio : actividad.getEjercicios()) {
                model.addElement(ejercicio.getNombre() + ": " + ejercicio.getTecnica());
            }
        } else {
            model.addElement("No hay ejercicios asignados.");
        }
    }

    private void mostrarImagenEjercicio(int index) {
        List<Ejercicio> ejercicios = actividad.getEjercicios();
        if (ejercicios == null || index < 0 || index >= ejercicios.size()) {
            return;
        }

        Ejercicio ejercicio = ejercicios.get(index);
        String imagenPath = ejercicio.getImagenPath();
        
        if (imagenPath == null || imagenPath.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Este ejercicio no tiene imagen asociada", 
                "Imagen no disponible", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Crear diálogo para mostrar la imagen
        JDialog dialog = new JDialog(this, "Imagen del Ejercicio: " + ejercicio.getNombre(), true);
        dialog.setSize(500, 500);
        dialog.setLayout(new BorderLayout());
        
        JPanel panelImagen = new JPanel(new BorderLayout());
        panelImagen.add(new JLabel("Cargando imagen...", SwingConstants.CENTER), BorderLayout.CENTER);
        
        // Cargar imagen en segundo plano
        new SwingWorker<ImageIcon, Void>() {
            @Override
            protected ImageIcon doInBackground() throws Exception {
                try {
                    BufferedImage img;
                    if (imagenPath.startsWith("http")) {
                        // Cargar desde URL
                        img = ImageIO.read(new java.net.URL(imagenPath));
                    } else {
                        // Cargar desde archivo local
                        img = ImageIO.read(new File(imagenPath));
                    }
                    
                    if (img != null) {
                        // Escalar la imagen manteniendo el aspect ratio
                        int ancho = 400;
                        int alto = (int) (ancho * ((double) img.getHeight() / img.getWidth()));
                        Image scaledImg = img.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
                        return new ImageIcon(scaledImg);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }
            
            @Override
            protected void done() {
                try {
                    ImageIcon imageIcon = get();
                    panelImagen.removeAll();
                    
                    if (imageIcon != null) {
                        panelImagen.add(new JLabel(imageIcon), BorderLayout.CENTER);
                    } else {
                        panelImagen.add(new JLabel("No se pudo cargar la imagen", SwingConstants.CENTER), 
                            BorderLayout.CENTER);
                    }
                } catch (Exception e) {
                    panelImagen.add(new JLabel("Error al cargar la imagen", SwingConstants.CENTER), 
                        BorderLayout.CENTER);
                }
                panelImagen.revalidate();
                panelImagen.repaint();
            }
        }.execute();
        
        dialog.add(panelImagen, BorderLayout.CENTER);
        
        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.addActionListener(e -> dialog.dispose());
        dialog.add(btnCerrar, BorderLayout.SOUTH);
        
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void configurarTemporizador(ActividadFisica actividad) {
        try {
            String horaMaximaStr = actividad.getHoraMaximaActividad();
            if (horaMaximaStr == null || horaMaximaStr.trim().isEmpty()) {
                System.err.println("Error configurando temporizador: Hora máxima no definida en la actividad.");
                lblTiempo.setText("Error: Tiempo no definido");
                return;
            }
            LocalTime horaMaxima = LocalTime.parse(horaMaximaStr);
            LocalTime ahora = LocalTime.now();

            if (ahora.isAfter(horaMaxima)) {
                lblTiempo.setText("¡Tiempo completado!");
                return;
            }

            Duration duracion = Duration.between(ahora, horaMaxima);
            this.segundosRestantes = duracion.getSeconds();

            actualizarTiempoRestante(this.segundosRestantes);

            if (timer != null && timer.isRunning()) {
                timer.stop();
            }

            timer = new Timer(1000, e -> {
                this.segundosRestantes--;

                if (this.segundosRestantes <= 0) {
                    ((Timer)e.getSource()).stop();
                    lblTiempo.setText("¡Tiempo terminado!");
                    JOptionPane.showMessageDialog(ActividadDiariaVista.this, "¡Tiempo de actividad completado!");
                } else {
                    actualizarTiempoRestante(this.segundosRestantes);
                }
            });
            timer.start();

        } catch (java.time.format.DateTimeParseException dtpe) {
            lblTiempo.setText("Error: Formato hora");
            System.err.println("Error configurando temporizador: Formato de hora inválido en actividad - " + dtpe.getMessage());
        } catch (Exception e) {
            lblTiempo.setText("Error en tiempo");
            System.err.println("Error configurando temporizador: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void actualizarTiempoRestante(long segundos) {
        if (segundos < 0) segundos = 0;

        long horas = segundos / 3600;
        long minutos = (segundos % 3600) / 60;
        long segs = segundos % 60;
        lblTiempo.setText(String.format("Tiempo restante: %02d:%02d:%02d", horas, minutos, segs));
    }

    private void finalizarActividad() {
        if (timer != null) {
            timer.stop();
        }

        File imagen = new File("prueba.png");
        if (!imagen.exists()) {
            JOptionPane.showMessageDialog(this,
                    "prueba.png no encontrada en el directorio del proyecto.",
                    "Error de Archivo",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        double latitud = 40.4168;
        double longitud = -3.7038;

        boolean exito = controlador.finalizarActividad(imagen.getAbsolutePath(), latitud, longitud);

        if (exito) {
            JOptionPane.showMessageDialog(this,
                    "¡Actividad completada con éxito!",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    "Error al guardar la actividad finalizada. Revise la consola para detalles.",
                    "Error al Finalizar",
                    JOptionPane.ERROR_MESSAGE);
        }

        new MenuPrincipalVista(controlador).mostrar();
        dispose();
    }

    public void mostrar() {
        setVisible(true);
    }
}