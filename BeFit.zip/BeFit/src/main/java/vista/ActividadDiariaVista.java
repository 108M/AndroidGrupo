package vista;

import controlador.ControladorApp;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.time.Duration;
import java.time.LocalTime;
import javax.swing.Timer;
import modelos.ActividadFisica;
import modelos.Ejercicio;

public class ActividadDiariaVista extends JFrame {
    private ControladorApp controlador;
    private Timer timer;
    private JLabel lblTiempo;
    private JTextArea txtEjercicios;
    private long segundosRestantes;

    public ActividadDiariaVista(ControladorApp controlador) {
        this.controlador = controlador;
        configurarVentana();
        initComponentes();
    }

    private void configurarVentana() {
        setTitle("BeFit - Actividad Diaria");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void initComponentes() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        ActividadFisica actividad = controlador.generarActividadDiaria();
        if (actividad == null) {
            JOptionPane.showMessageDialog(this, "No se pudo generar la actividad diaria");
            dispose();
            return;
        }

        lblTiempo = new JLabel("", SwingConstants.CENTER);
        lblTiempo.setFont(new Font("Arial", Font.BOLD, 24));

        txtEjercicios = new JTextArea("Ejercicios de hoy:\n");
        txtEjercicios.setEditable(false);
        txtEjercicios.setFont(new Font("Arial", Font.PLAIN, 16));
        JScrollPane scrollEjercicios = new JScrollPane(txtEjercicios);

        JButton btnFinalizar = new JButton("Finalizar Actividad y Tomar Foto");
        btnFinalizar.setFont(new Font("Arial", Font.BOLD, 14));
        btnFinalizar.addActionListener(e -> finalizarActividad());

        panel.add(lblTiempo, BorderLayout.NORTH);
        panel.add(scrollEjercicios, BorderLayout.CENTER);
        panel.add(btnFinalizar, BorderLayout.SOUTH);

        cargarEjercicios(actividad); // Pasar la actividad
        configurarTemporizador(actividad);

        add(panel);
    }

    private void cargarEjercicios(ActividadFisica actividad) {
        txtEjercicios.setText("Ejercicios de hoy:\n"); // Limpiar el JTextArea
        if (actividad.getEjercicios() != null) {
            for (Ejercicio ejercicio : actividad.getEjercicios()) {
                txtEjercicios.append("- " + ejercicio.getNombre() + ": " + ejercicio.getTecnica() + "\n");
            }
        } else {
            txtEjercicios.append("No hay ejercicios asignados.\n");
        }
    }

    private void configurarTemporizador(ActividadFisica actividad) {
        try {
            String horaMaximaStr = actividad.getHoraMaximaActividad();
            if (horaMaximaStr == null || horaMaximaStr.trim().isEmpty()) {
                System.err.println("Error configurando temporizador: Hora máxima no definida en la actividad.");
                lblTiempo.setText("Error: Tiempo no definido");
                return;
            }
            LocalTime horaMaxima = LocalTime.parse(horaMaximaStr);
            LocalTime ahora = LocalTime.now();

            if (ahora.isAfter(horaMaxima)) {
                lblTiempo.setText("¡Tiempo completado!");
                return;
            }

            Duration duracion = Duration.between(ahora, horaMaxima);
            this.segundosRestantes = duracion.getSeconds();

            actualizarTiempoRestante(this.segundosRestantes);

            if (timer != null && timer.isRunning()) {
                timer.stop();
            }

            timer = new Timer(1000, e -> {
                this.segundosRestantes--;

                if (this.segundosRestantes <= 0) {
                    ((Timer)e.getSource()).stop();
                    lblTiempo.setText("¡Tiempo terminado!");
                    JOptionPane.showMessageDialog(ActividadDiariaVista.this, "¡Tiempo de actividad completado!");
                } else {
                    actualizarTiempoRestante(this.segundosRestantes);
                }
            });
            timer.start();

        } catch (java.time.format.DateTimeParseException dtpe) {
            lblTiempo.setText("Error: Formato hora");
            System.err.println("Error configurando temporizador: Formato de hora inválido en actividad - " + dtpe.getMessage());
        } catch (Exception e) {
            lblTiempo.setText("Error en tiempo");
            System.err.println("Error configurando temporizador: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void actualizarTiempoRestante(long segundos) {
        if (segundos < 0) segundos = 0;

        long horas = segundos / 3600;
        long minutos = (segundos % 3600) / 60;
        long segs = segundos % 60;
        lblTiempo.setText(String.format("Tiempo restante: %02d:%02d:%02d", horas, minutos, segs));
    }

    private void finalizarActividad() {
        if (timer != null) {
            timer.stop();
        }

        File imagen = new File("prueba.png");
        if (!imagen.exists()) {
            JOptionPane.showMessageDialog(this,
                    "prueba.png no encontrada en el directorio del proyecto.",
                    "Error de Archivo",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        double latitud = 40.4168;
        double longitud = -3.7038;

        boolean exito = controlador.finalizarActividad(imagen.getAbsolutePath(), latitud, longitud);

        if (exito) {
            JOptionPane.showMessageDialog(this,
                    "¡Actividad completada con éxito!",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    "Error al guardar la actividad finalizada. Revise la consola para detalles.",
                    "Error al Finalizar",
                    JOptionPane.ERROR_MESSAGE);
        }

        new MenuPrincipalVista(controlador).mostrar();
        dispose();
    }

    public void mostrar() {
        setVisible(true);
    }
}