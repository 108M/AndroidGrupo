package controlador;

import dao.*;
import modelos.*;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import modelos.Usuario.Genero;

public class ConsolaPruebas {

    // DAOs para gestionar los datos
    private static UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
    private static EjercicioDAO ejercicioDAO = new EjercicioDAOImpl();
    private static ActividadFisicaDAO actividadFisicaDAO = new ActividadFisicaDAOImpl();
    private static HistoriaDAO historiaDAO = new HistoriaDAOImpl();
    private static HistorialesDeUsuarioDAO historialesDeUsuarioDAO = new HistorialesDeUsuarioDAOImpl();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n--- Panel de Control ---");
            System.out.println("1. Crear Usuario");
            System.out.println("2. Listar Usuarios");
            System.out.println("3. Crear Actividad Física");
            System.out.println("4. Listar Actividades Físicas");
            System.out.println("5. Crear Ejercicio");
            System.out.println("6. Listar Ejercicios");
            System.out.println("7. Crear Historia");
            System.out.println("8. Listar Historias");
            System.out.println("9. Crear Historial de Usuario");
            System.out.println("10. Listar Historiales de Usuario");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1:
                    crearUsuario(scanner);
                    break;
                case 2:
                    listarUsuarios();
                    break;
                case 3:
                    crearActividadFisica(scanner);
                    break;
                case 4:
                    listarActividadesFisicas();
                    break;
                case 5:
                    crearEjercicio(scanner);
                    break;
                case 6:
                    listarEjercicios();
                    break;
                case 7:
                    crearHistoria(scanner);
                    break;
                case 8:
                    listarHistorias();
                    break;
                case 9:
                    crearHistorialUsuario(scanner);
                    break;
                case 10:
                    listarHistorialesUsuario();
                    break;
                case 0:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 0);

        scanner.close();
    }

    private static void crearUsuario(Scanner scanner) {
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Peso: ");
        float peso = scanner.nextFloat();
        System.out.print("Altura: ");
        float altura = scanner.nextFloat();
        System.out.print("Edad: ");
        int edad = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer
        System.out.print("Género (HOMBRE, MUJER, OTROS): ");
        Genero genero = Genero.valueOf(scanner.nextLine().toUpperCase());

        Usuario usuario = new Usuario(nombre, peso, altura, edad, genero);
        usuarioDAO.crearUsuario(usuario);
        System.out.println("Usuario creado con éxito.");
    }

    private static void listarUsuarios() {
        List<Usuario> usuarios = usuarioDAO.obtenerTodosLosUsuarios();
        if (usuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
        } else {
            for (Usuario usuario : usuarios) {
                System.out.println(usuario.getNombre() + " - ObjectId: " + usuario.getObjectId());
            }
        }
    }

    private static void crearActividadFisica(Scanner scanner) {
        System.out.print("Hora de comienzo (HH:MM): ");
        String horaComienzo = scanner.nextLine();
        System.out.print("Hora máxima (HH:MM): ");
        String horaMaxima = scanner.nextLine();
        System.out.print("Hora de finalización (HH:MM): ");
        String horaFinalizacion = scanner.nextLine();

        ActividadFisica actividad = new ActividadFisica(new ArrayList<>(), LocalTime.parse(horaComienzo),
                LocalTime.parse(horaMaxima), LocalTime.parse(horaFinalizacion), false);
        actividadFisicaDAO.crearActividadFisica(actividad);
        System.out.println("Actividad física creada con éxito.");
    }

    private static void listarActividadesFisicas() {
        List<ActividadFisica> actividades = actividadFisicaDAO.obtenerTodasLasActividadesFisicas();
        if (actividades.isEmpty()) {
            System.out.println("No hay actividades físicas registradas.");
        } else {
            for (ActividadFisica actividad : actividades) {
                System.out.println("ObjectId: " + actividad.getObjectId() + " - Hora de comienzo: " + actividad.getHoraComienzoActividad());
            }
        }
    }

    private static void crearEjercicio(Scanner scanner) {
        System.out.print("Nombre del ejercicio: ");
        String nombre = scanner.nextLine();
        System.out.print("Intensidad: ");
        int intensidad = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer
        System.out.print("Técnica: ");
        String tecnica = scanner.nextLine();
        System.out.print("Tiempo máximo (en minutos): ");
        float tiempoMax = scanner.nextFloat();

        Ejercicio ejercicio = new Ejercicio(nombre, intensidad, null, tecnica, tiempoMax);
        ejercicioDAO.crearEjercicio(ejercicio);
        System.out.println("Ejercicio creado con éxito.");
    }

    private static void listarEjercicios() {
        List<Ejercicio> ejercicios = ejercicioDAO.obtenerTodosLosEjercicios();
        if (ejercicios.isEmpty()) {
            System.out.println("No hay ejercicios registrados.");
        } else {
            for (Ejercicio ejercicio : ejercicios) {
                System.out.println(ejercicio.getNombre()+ " - Intensidad: " + ejercicio.getIntensidad());
            }
        }
    }

    private static void crearHistoria(Scanner scanner) {
        System.out.print("ObjectId de la actividad registrada: ");
        String objectIdActividad = scanner.nextLine();
        System.out.print("Estado de finalización (FACIL, MEDIO, DIFICIL, IMPOSIBLE): ");
        Historia.estadoFinalizacion estado = Historia.estadoFinalizacion.valueOf(scanner.nextLine().toUpperCase());

        ActividadFisica actividad = actividadFisicaDAO.obtenerActividadFisicaPorId(objectIdActividad);
        if (actividad != null) {
            Historia historia = new Historia(new Date(), objectIdActividad, estado, new ArrayList<>());
            historiaDAO.crearHistoria(historia);
            System.out.println("Historia creada con éxito.");
        } else {
            System.out.println("No se encontró la actividad con el ObjectId proporcionado.");
        }
    }

    private static void listarHistorias() {
        List<Historia> historias = historiaDAO.obtenerTodasLasHistorias();
        if (historias.isEmpty()) {
            System.out.println("No hay historias registradas.");
        } else {
            for (Historia historia : historias) {
                System.out.println("Fecha: " + historia.getFecha() + " - Estado: " + historia.getEstadoFinalizacion());
            }
        }
    }

    private static void crearHistorialUsuario(Scanner scanner) {
        System.out.print("ObjectId del usuario: ");
        String objectIdUsuario = scanner.nextLine();
        System.out.print("ObjectId de la historia: ");
        String objectIdHistoria = scanner.nextLine();

        Usuario usuario = usuarioDAO.obtenerUsuarioPorId(objectIdUsuario);
        Historia historia = historiaDAO.obtenerHistoriaPorId(objectIdHistoria);

        if (usuario != null && historia != null) {
            HistorialesDeUsuario historial = historialesDeUsuarioDAO.obtenerHistorialDeUsuarioPorId(objectIdUsuario);
            if (historial == null) {
                historial = new HistorialesDeUsuario(objectIdUsuario, new ArrayList<>());
            }
            historial.getHistorialUsuarioIds().add(objectIdHistoria);
            historialesDeUsuarioDAO.crearHistorialDeUsuario(historial);
            System.out.println("Historial de usuario creado con éxito.");
        } else {
            System.out.println("No se encontró el usuario o la historia con los ObjectIds proporcionados.");
        }
    }

    private static void listarHistorialesUsuario() {
        List<HistorialesDeUsuario> historiales = historialesDeUsuarioDAO.obtenerTodosLosHistorialesDeUsuario();
        if (historiales.isEmpty()) {
            System.out.println("No hay historiales de usuario registrados.");
        } else {
            for (HistorialesDeUsuario historial : historiales) {
                System.out.println("ObjectId Usuario: " + historial.getIdUsuario() + " - Historias: " + historial.getHistorialUsuarioIds().size());
            }
        }
    }
}