/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import modelos.ActividadFisica;
import modelos.Ejercicio;
import modelos.Historia;
import modelos.HistorialesDeUsuario;
import modelos.Usuario;
import modelos.Usuario.Dificultad;
import modelos.Usuario.Genero;

public class ConsolaPruebas {

    private static List<Usuario> usuarios = new ArrayList<>();
    private static List<ActividadFisica> actividades = new ArrayList<>();
    private static List<Ejercicio> ejercicios = new ArrayList<>();
    private static List<Historia> historias = new ArrayList<>();
    private static List<HistorialesDeUsuario> historiales = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n--- Panel de Control ---");
            System.out.println("1. Crear Usuario");
            System.out.println("2. Listar Usuarios");
            System.out.println("3. Crear Actividad Física");
            System.out.println("4. Listar Actividades Físicas");
            System.out.println("5. Crear Ejercicio");
            System.out.println("6. Listar Ejercicios");
            System.out.println("7. Crear Historia");
            System.out.println("8. Listar Historias");
            System.out.println("9. Crear Historial de Usuario");
            System.out.println("10. Listar Historiales de Usuario");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1:
                    crearUsuario(scanner);
                    break;
                case 2:
                    listarUsuarios();
                    break;
                case 3:
                    crearActividadFisica(scanner);
                    break;
                case 4:
                    listarActividadesFisicas();
                    break;
                case 5:
                    crearEjercicio(scanner);
                    break;
                case 6:
                    listarEjercicios();
                    break;
                case 7:
                    crearHistoria(scanner);
                    break;
                case 8:
                    listarHistorias();
                    break;
                case 9:
                    crearHistorialUsuario(scanner);
                    break;
                case 10:
                    listarHistorialesUsuario();
                    break;
                case 0:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 0);

        scanner.close();
    }

    private static void crearUsuario(Scanner scanner) {
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("ID: ");
        int id = scanner.nextInt();
        System.out.print("Peso: ");
        float peso = scanner.nextFloat();
        System.out.print("Altura: ");
        float altura = scanner.nextFloat();
        System.out.print("Edad: ");
        int edad = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer
        System.out.print("Género (HOMBRE, MUJER, OTROS): ");
        Genero genero = Genero.valueOf(scanner.nextLine().toUpperCase());
        System.out.print("Dificultad (FACIL, MEDIO, DIFICIL): ");
        Dificultad dificultad = Dificultad.valueOf(scanner.nextLine().toUpperCase());

        Usuario usuario = new Usuario(id, nombre, peso, altura, edad, genero, dificultad, null);
        usuarios.add(usuario);
        System.out.println("Usuario creado con éxito.");
    }

    private static void listarUsuarios() {
        if (usuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
        } else {
            for (Usuario usuario : usuarios) {
                System.out.println(usuario.getNombre() + " - ID: " + usuario.getId());
            }
        }
    }

    private static void crearActividadFisica(Scanner scanner) {
        System.out.print("ID de la actividad: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer
        System.out.print("Hora de comienzo (HH:MM): ");
        String horaComienzo = scanner.nextLine();
        System.out.print("Hora máxima (HH:MM): ");
        String horaMaxima = scanner.nextLine();
        System.out.print("Hora de finalización (HH:MM): ");
        String horaFinalizacion = scanner.nextLine();

        ActividadFisica actividad = new ActividadFisica(id, new ArrayList<>(), 
            LocalTime.parse(horaComienzo), LocalTime.parse(horaMaxima), LocalTime.parse(horaFinalizacion), false);
        actividades.add(actividad);
        System.out.println("Actividad física creada con éxito.");
    }

    private static void listarActividadesFisicas() {
        if (actividades.isEmpty()) {
            System.out.println("No hay actividades físicas registradas.");
        } else {
            for (ActividadFisica actividad : actividades) {
                System.out.println("ID: " + actividad.getId() + " - Hora de comienzo: " + actividad.getHora_comienzo_actividad());
            }
        }
    }

    private static void crearEjercicio(Scanner scanner) {
        System.out.print("Nombre del ejercicio: ");
        String nombre = scanner.nextLine();
        System.out.print("Intensidad: ");
        int intensidad = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer
        System.out.print("Técnica: ");
        String tecnica = scanner.nextLine();
        System.out.print("Tiempo máximo (en minutos): ");
        float tiempoMax = scanner.nextFloat();

        Ejercicio ejercicio = new Ejercicio(nombre, intensidad, null, tecnica, tiempoMax);
        ejercicios.add(ejercicio);
        System.out.println("Ejercicio creado con éxito.");
    }

    private static void listarEjercicios() {
        if (ejercicios.isEmpty()) {
            System.out.println("No hay ejercicios registrados.");
        } else {
            for (Ejercicio ejercicio : ejercicios) {
                System.out.println(ejercicio.getNombre_ejercicios() + " - Intensidad: " + ejercicio.getIntensidad());
            }
        }
    }

    private static void crearHistoria(Scanner scanner) {
        System.out.print("Fecha (YYYY-MM-DD): ");
        String fecha = scanner.nextLine();
        System.out.print("ID de la actividad registrada: ");
        int idActividad = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer
        System.out.print("Estado de finalización (FACIL, MEDIO, DIFICIL, IMPOSIBLE): ");
        Historia.estadoFinalizacion estado = Historia.estadoFinalizacion.valueOf(scanner.nextLine().toUpperCase());

        ActividadFisica actividad = actividades.stream()
            .filter(a -> a.getId() == idActividad)
            .findFirst()
            .orElse(null);

        if (actividad != null) {
            Historia historia = new Historia(new Date(), actividad, estado, new ArrayList<>());
            historias.add(historia);
            System.out.println("Historia creada con éxito.");
        } else {
            System.out.println("No se encontró la actividad con el ID proporcionado.");
        }
    }

    private static void listarHistorias() {
        if (historias.isEmpty()) {
            System.out.println("No hay historias registradas.");
        } else {
            for (Historia historia : historias) {
                System.out.println("Fecha: " + historia.getFecha() + " - Estado: " + historia.getEstadoFinalizacion());
            }
        }
    }

    private static void crearHistorialUsuario(Scanner scanner) {
        System.out.print("ID del usuario: ");
        int idUsuario = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer
        System.out.print("ID de la historia: ");
        int idHistoria = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer

        Usuario usuario = usuarios.stream()
            .filter(u -> u.getId() == idUsuario)
            .findFirst()
            .orElse(null);

        Historia historia = historias.stream()
            .filter(h -> h.getActividad_registrada().getId() == idHistoria)
            .findFirst()
            .orElse(null);

        if (usuario != null && historia != null) {
            HistorialesDeUsuario historial = new HistorialesDeUsuario(idUsuario, List.of(historia));
            historiales.add(historial);
            System.out.println("Historial de usuario creado con éxito.");
        } else {
            System.out.println("No se encontró el usuario o la historia con los IDs proporcionados.");
        }
    }

    private static void listarHistorialesUsuario() {
        if (historiales.isEmpty()) {
            System.out.println("No hay historiales de usuario registrados.");
        } else {
            for (HistorialesDeUsuario historial : historiales) {
                System.out.println("ID Usuario: " + historial.getId() + " - Historias: " + historial.getHistorialUsuario().size());
            }
        }
    }
}
