package controlador;

import modelos.*;
import dao.*;
import vista.PanelControlVista; // Importar la vista
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultListModel;

public class ControladorJFrame {

    // DAOs para gestionar los datos
    private UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
    private EjercicioDAO ejercicioDAO = new EjercicioDAOImpl();
    private ActividadFisicaDAO actividadFisicaDAO = new ActividadFisicaDAOImpl();
    private HistoriaDAO historiaDAO = new HistoriaDAOImpl();
    private HistorialesDeUsuarioDAO historialesDeUsuarioDAO = new HistorialesDeUsuarioDAOImpl();

    // Modelos de lista para la vista
    private DefaultListModel<String> listModelUsuarios = new DefaultListModel<>();
    private DefaultListModel<String> listModelActividades = new DefaultListModel<>();
    private DefaultListModel<String> listModelEjercicios = new DefaultListModel<>();
    private DefaultListModel<String> listModelHistorias = new DefaultListModel<>();
    private DefaultListModel<String> listModelHistoriales = new DefaultListModel<>();

    // Método main para ejecutar la aplicación
    public static void main(String[] args) {
        // Crear una instancia del controlador
        ControladorJFrame controlador = new ControladorJFrame();

        // Crear la vista y pasarle el controlador
        PanelControlVista vista = new PanelControlVista(controlador);

        // Mostrar la vista
        vista.mostrar();
    }

    // Métodos para Usuario
    public void crearUsuario(String nombre, int id, float peso, float altura, int edad, Usuario.Genero genero) {
        Usuario usuario = new Usuario(id, nombre, peso, altura, edad, genero);
        usuarioDAO.crearUsuario(usuario);
        listModelUsuarios.addElement(usuario.getNombre() + " - ID: " + usuario.getId());
    }

    public DefaultListModel<String> getListModelUsuarios() {
        listModelUsuarios.clear(); // Limpiar el modelo antes de actualizarlo
        for (Usuario usuario : usuarioDAO.obtenerTodosLosUsuarios()) {
            listModelUsuarios.addElement(usuario.getNombre() + " - ID: " + usuario.getId());
        }
        return listModelUsuarios;
    }

    // Métodos para Actividad
    public void crearActividad(int id, String horaComienzo, String horaMaxima, String horaFinalizacion) {
        ActividadFisica actividad = new ActividadFisica(id, new ArrayList<>(), LocalTime.parse(horaComienzo),
                LocalTime.parse(horaMaxima), LocalTime.parse(horaFinalizacion), false);
        actividadFisicaDAO.crearActividadFisica(actividad);
        // En el método getListModelActividades
listModelActividades.addElement("ID: " + actividad.getId() + " - Hora de comienzo: " + actividad.getHoraComienzoActividad());
    }

    public DefaultListModel<String> getListModelActividades() {
        listModelActividades.clear(); // Limpiar el modelo antes de actualizarlo
        for (ActividadFisica actividad : actividadFisicaDAO.obtenerTodasLasActividadesFisicas()) {
            listModelActividades.addElement("ID: " + actividad.getId() + " - Hora de comienzo: " + actividad.getHoraComienzoActividad());
        }
        return listModelActividades;
    }

    // Métodos para Ejercicio
    public void crearEjercicio(String nombre, int intensidad, String tecnica, float tiempoMax) {
        Ejercicio ejercicio = new Ejercicio(nombre, intensidad, null, tecnica, tiempoMax);
        ejercicioDAO.crearEjercicio(ejercicio);
        listModelEjercicios.addElement(ejercicio.getNombre_ejercicios() + " - Intensidad: " + ejercicio.getIntensidad());
    }

    public DefaultListModel<String> getListModelEjercicios() {
        listModelEjercicios.clear(); // Limpiar el modelo antes de actualizarlo
        for (Ejercicio ejercicio : ejercicioDAO.obtenerTodosLosEjercicios()) {
            listModelEjercicios.addElement(ejercicio.getNombre_ejercicios() + " - Intensidad: " + ejercicio.getIntensidad());
        }
        return listModelEjercicios;
    }

    // Métodos para Historia
    public void crearHistoria(Date fecha, int actividadId, Historia.estadoFinalizacion estado) {
        Historia historia = new Historia(fecha,historiaDAO.obtenerTodasLasHistorias().size() + 1, estado, null);
        historiaDAO.crearHistoria(historia);
        listModelHistorias.addElement("Fecha: " + historia.getFecha() + " - Estado: " + historia.getEstadoFinalizacion());
    }

    public DefaultListModel<String> getListModelHistorias() {
        listModelHistorias.clear(); // Limpiar el modelo antes de actualizarlo
        for (Historia historia : historiaDAO.obtenerTodasLasHistorias()) {
            listModelHistorias.addElement("Fecha: " + historia.getFecha() + " - Estado: " + historia.getEstadoFinalizacion());
        }
        return listModelHistorias;
    }

    // Métodos para Historial
    public void crearHistorial(int idUsuario, int historiaId) {
        HistorialesDeUsuario historial = historialesDeUsuarioDAO.obtenerHistorialDeUsuarioPorId(idUsuario);
        if (historial == null) {
            historial = new HistorialesDeUsuario(idUsuario, new ArrayList<>());
        }
        historial.getHistorialUsuarioIds().add(historiaId);
        historialesDeUsuarioDAO.crearHistorialDeUsuario(historial);
        listModelHistoriales.addElement("ID Usuario: " + historial.getIdUsuario() + " - Historias: " + historial.getHistorialUsuarioIds().size());
    }

    public DefaultListModel<String> getListModelHistoriales() {
        listModelHistoriales.clear(); // Limpiar el modelo antes de actualizarlo
        for (HistorialesDeUsuario historial : historialesDeUsuarioDAO.obtenerTodosLosHistorialesDeUsuario()) {
            listModelHistoriales.addElement("ID Usuario: " + historial.getIdUsuario() + " - Historias: " + historial.getHistorialUsuarioIds().size());
        }
        return listModelHistoriales;
    }

    // Getters para los DAOs (si es necesario)
    public UsuarioDAO getUsuarioDAO() {
        return usuarioDAO;
    }

    public EjercicioDAO getEjercicioDAO() {
        return ejercicioDAO;
    }

    public ActividadFisicaDAO getActividadFisicaDAO() {
        return actividadFisicaDAO;
    }

    public HistoriaDAO getHistoriaDAO() {
        return historiaDAO;
    }

    public HistorialesDeUsuarioDAO getHistorialesDeUsuarioDAO() {
        return historialesDeUsuarioDAO;
    }
}