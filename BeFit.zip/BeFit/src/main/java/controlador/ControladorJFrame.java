package controlador;

import modelos.*;
import vista.PanelControlVista; // Importar la vista
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultListModel;

public class ControladorJFrame {

    // Listas para almacenar los objetos
    private List<Usuario> usuarios = new ArrayList<>();
    private List<ActividadFisica> actividades = new ArrayList<>();
    private List<Ejercicio> ejercicios = new ArrayList<>();
    private List<Historia> historias = new ArrayList<>();
    private List<HistorialesDeUsuario> historiales = new ArrayList<>();

    // Modelos de lista para la vista
    private DefaultListModel<String> listModelUsuarios = new DefaultListModel<>();
    private DefaultListModel<String> listModelActividades = new DefaultListModel<>();
    private DefaultListModel<String> listModelEjercicios = new DefaultListModel<>();
    private DefaultListModel<String> listModelHistorias = new DefaultListModel<>();
    private DefaultListModel<String> listModelHistoriales = new DefaultListModel<>();

    // Método main para ejecutar la aplicación
    public static void main(String[] args) {
        // Crear una instancia del controlador
        ControladorJFrame controlador = new ControladorJFrame();

        // Crear la vista y pasarle el controlador
        PanelControlVista vista = new PanelControlVista(controlador);

        // Mostrar la vista
        vista.mostrar();
    }

    // Métodos para Usuario
    public void crearUsuario(String nombre, int id, float peso, float altura, int edad, Usuario.Genero genero, Usuario.Dificultad dificultad) {
        Usuario usuario = new Usuario(id, nombre, peso, altura, edad, genero, dificultad, null);
        usuarios.add(usuario);
        listModelUsuarios.addElement(usuario.getNombre() + " - ID: " + usuario.getId());
    }

    public DefaultListModel<String> getListModelUsuarios() {
        return listModelUsuarios;
    }

    // Métodos para Actividad
    public void crearActividad(int id, String horaComienzo, String horaMaxima, String horaFinalizacion) {
        ActividadFisica actividad = new ActividadFisica(id, new ArrayList<>(), LocalTime.parse(horaComienzo),
                LocalTime.parse(horaMaxima), LocalTime.parse(horaFinalizacion), false);
        actividades.add(actividad);
        listModelActividades.addElement("ID: " + actividad.getId() + " - Hora de comienzo: " + actividad.getHora_comienzo_actividad());
    }

    public DefaultListModel<String> getListModelActividades() {
        return listModelActividades;
    }

    // Métodos para Ejercicio
    public void crearEjercicio(String nombre, int intensidad, String tecnica, float tiempoMax) {
        Ejercicio ejercicio = new Ejercicio(nombre, intensidad, null, tecnica, tiempoMax);
        ejercicios.add(ejercicio);
        listModelEjercicios.addElement(ejercicio.getNombre_ejercicios() + " - Intensidad: " + ejercicio.getIntensidad());
    }

    public DefaultListModel<String> getListModelEjercicios() {
        return listModelEjercicios;
    }

    // Métodos para Historia
    public void crearHistoria(Date fecha, ActividadFisica actividad, Historia.estadoFinalizacion estado) {
        Historia historia = new Historia(fecha, actividad, estado, new ArrayList<>());
        historias.add(historia);
        listModelHistorias.addElement("Fecha: " + historia.getFecha() + " - Estado: " + historia.getEstadoFinalizacion());
    }

    public DefaultListModel<String> getListModelHistorias() {
        return listModelHistorias;
    }

    // Métodos para Historial
    public void crearHistorial(Usuario usuario, Historia historia) {
        HistorialesDeUsuario historial = new HistorialesDeUsuario(usuario.getId(), List.of(historia));
        historiales.add(historial);
        listModelHistoriales.addElement("ID Usuario: " + historial.getId() + " - Historias: " + historial.getHistorialUsuario().size());
    }

    public DefaultListModel<String> getListModelHistoriales() {
        return listModelHistoriales;
    }

    // Getters para las listas de objetos
    public List<ActividadFisica> getActividades() {
        return actividades;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public List<Historia> getHistorias() {
        return historias;
    }
}