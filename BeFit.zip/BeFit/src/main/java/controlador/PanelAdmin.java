package controlador;

import modelos.*;
import dao.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultListModel;
import vista.AdminVista;

public class PanelAdmin {

    // DAOs para gestionar los datos
    private UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
    private EjercicioDAO ejercicioDAO = new EjercicioDAOImpl();
    private ActividadFisicaDAO actividadFisicaDAO = new ActividadFisicaDAOImpl();
    private HistoriaDAO historiaDAO = new HistoriaDAOImpl();
    private HistorialesDeUsuarioDAO historialesDeUsuarioDAO = new HistorialesDeUsuarioDAOImpl();

    // Modelos de lista para la vista
    private DefaultListModel<String> listModelUsuarios = new DefaultListModel<>();
    private DefaultListModel<String> listModelActividades = new DefaultListModel<>();
    private DefaultListModel<String> listModelEjercicios = new DefaultListModel<>();
    private DefaultListModel<String> listModelHistorias = new DefaultListModel<>();
    private DefaultListModel<String> listModelHistoriales = new DefaultListModel<>();

    // Método main para ejecutar la aplicación
    public static void main(String[] args) {
        // Crear una instancia del controlador
        PanelAdmin controlador = new PanelAdmin();

        // Crear la vista y pasarle el controlador
        AdminVista vista = new AdminVista(controlador);

        // Mostrar la vista
        vista.mostrar();
    }
    
    private void actualizarListaUsuarios() {
        listModelUsuarios.clear();
        for (Usuario usuario : usuarioDAO.obtenerTodosLosUsuarios()) {
            String item = String.format("ObjectId: %s - Nombre: %s - Peso: %.2f - Altura: %.2f - Edad: %d - Género: %s",
                    usuario.getObjectId() != null ? usuario.getObjectId() : "null",
                    usuario.getNombre() != null ? usuario.getNombre() : "null",
                    usuario.getPeso(),
                    usuario.getAltura(),
                    usuario.getEdad(),
                    usuario.getGenero() != null ? usuario.getGenero().toString() : "null");
            listModelUsuarios.addElement(item);
        }
    }

    private void actualizarListaActividades() {
        listModelActividades.clear();
        for (ActividadFisica actividad : actividadFisicaDAO.obtenerTodasLasActividadesFisicas()) {
            String item = String.format("ObjectId: %s - Inicio: %s - Máx: %s - Fin: %s - Estado: %s - Ejercicios: %d",
                    actividad.getObjectId() != null ? actividad.getObjectId() : "null",
                    actividad.getHoraComienzoActividad() != null ? actividad.getHoraComienzoActividad() : "null",
                    actividad.getHoraMaximaActividad() != null ? actividad.getHoraMaximaActividad() : "null",
                    actividad.getHoraFinalizacionActividad() != null ? actividad.getHoraFinalizacionActividad() : "null",
                    actividad.getEstado() != null ? actividad.getEstado().toString() : "null",
                    actividad.getListaEjerciciosIds() != null ? actividad.getListaEjerciciosIds().size() : 0);
            listModelActividades.addElement(item);
        }
    }

    private void actualizarListaEjercicios() {
        listModelEjercicios.clear();
        for (Ejercicio ejercicio : ejercicioDAO.obtenerTodosLosEjercicios()) {
            String item = String.format("ObjectId: %s - Nombre: %s - Intensidad: %d - Técnica: %s - Tiempo: %.1f - Imagen: %s",
                    ejercicio.getObjectId() != null ? ejercicio.getObjectId() : "null",
                    ejercicio.getNombre() != null ? ejercicio.getNombre() : "null",
                    ejercicio.getIntensidad(),
                    ejercicio.getTecnica() != null ? ejercicio.getTecnica() : "null",
                    ejercicio.getTiempoMax(),
                    ejercicio.getImagenPath() != null ? "Sí" : "No");
            listModelEjercicios.addElement(item);
        }
    }

    private void actualizarListaHistorias() {
        listModelHistorias.clear();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy, hh:mm:ss a");
        for (Historia historia : historiaDAO.obtenerTodasLasHistorias()) {
            String item = String.format("ObjectId: %s - Fecha: %s - Actividad: %s - Estado: %s - Imagen: %s - Ubicación: (%.4f, %.4f)",
                    historia.getObjectId() != null ? historia.getObjectId() : "null",
                    historia.getFecha() != null ? dateFormat.format(historia.getFecha()) : "null",
                    historia.getActividadRegistradaId() != null ? historia.getActividadRegistradaId() : "null",
                    historia.getEstadoFinalizacion() != null ? historia.getEstadoFinalizacion().toString() : "null",
                    historia.getImagen() != null ? "Sí" : "No",
                    historia.getLatitud(),
                    historia.getLongitud());
            listModelHistorias.addElement(item);
        }
    }

    private void actualizarListaHistoriales() {
        listModelHistoriales.clear();
        for (HistorialesDeUsuario historial : historialesDeUsuarioDAO.obtenerTodosLosHistorialesDeUsuario()) {
            String item = String.format("ObjectId: %s - Usuario: %s - Historias: %d",
                    historial.getObjectId() != null ? historial.getObjectId() : "null",
                    historial.getIdUsuario() != null ? historial.getIdUsuario() : "null",
                    historial.getHistorialUsuarioIds() != null ? historial.getHistorialUsuarioIds().size() : 0);
            listModelHistoriales.addElement(item);
        }
    }
    
    // Métodos para Usuario
    public Usuario obtenerUsuarioPorId(String objectId) {
        return usuarioDAO.obtenerUsuarioPorId(objectId);
    }

    public void actualizarUsuario(Usuario usuario) {
        usuarioDAO.actualizarUsuario(usuario);
        actualizarListaUsuarios();
    }

    public void eliminarUsuario(String objectId) {
        usuarioDAO.eliminarUsuario(objectId);
        actualizarListaUsuarios();
    }

    // Métodos para ActividadFisica
    public ActividadFisica obtenerActividadFisicaPorId(String objectId) {
        return actividadFisicaDAO.obtenerActividadFisicaPorId(objectId);
    }

    public void actualizarActividadFisica(ActividadFisica actividadFisica) {
        actividadFisicaDAO.actualizarActividadFisica(actividadFisica);
        actualizarListaActividades();
    }

    public void eliminarActividadFisica(String objectId) {
        actividadFisicaDAO.eliminarActividadFisica(objectId);
        actualizarListaActividades();
    }

    // Métodos para Ejercicio
    public Ejercicio obtenerEjercicioPorId(String objectId) {
        return ejercicioDAO.obtenerEjercicioPorId(objectId);
    }

    public void actualizarEjercicio(Ejercicio ejercicio, File imagenFile) {
        ejercicioDAO.actualizarEjercicio(ejercicio, imagenFile);
        actualizarListaEjercicios();
    }

    public void eliminarEjercicio(String objectId) {
        ejercicioDAO.eliminarEjercicio(objectId);
        actualizarListaEjercicios();
    }

    // Métodos para Historia
    public Historia obtenerHistoriaPorId(String objectId) {
        return historiaDAO.obtenerHistoriaPorId(objectId);
    }

    public void actualizarHistoria(Historia historia, File imagenFile) {
        historiaDAO.actualizarHistoria(historia, imagenFile);
        actualizarListaHistorias();
    }

    public void eliminarHistoria(String objectId) {
        historiaDAO.eliminarHistoria(objectId);
        actualizarListaHistorias();
    }

    // Métodos para HistorialesDeUsuario
    public HistorialesDeUsuario obtenerHistorialesDeUsuarioPorId(String objectId) {
        return historialesDeUsuarioDAO.obtenerHistorialDeUsuarioPorId(objectId);
    }

    public void actualizarHistorialesDeUsuario(HistorialesDeUsuario historial) {
        historialesDeUsuarioDAO.actualizarHistorialDeUsuario(historial);
        actualizarListaHistoriales();
    }

    public void eliminarHistorialesDeUsuario(String objectId) {
        historialesDeUsuarioDAO.eliminarHistorialDeUsuario(objectId);
        actualizarListaHistoriales();
    }

    // Métodos para Usuario
    public void crearUsuario(String nombre, float peso, float altura, int edad, Usuario.Genero genero) {
        Usuario usuario = new Usuario(nombre, peso, altura, edad, genero);
        usuarioDAO.crearUsuario(usuario);
        actualizarListaUsuarios();
    }

    public DefaultListModel<String> getListModelUsuarios() {
        actualizarListaUsuarios();
        return listModelUsuarios;
    }

    // Métodos para Actividad
    public void crearActividad(String horaComienzo, String horaMaxima, String horaFinalizacion) {
        ActividadFisica actividad = new ActividadFisica(new ArrayList<>(), LocalTime.parse(horaComienzo), LocalTime.parse(horaComienzo).plusSeconds((long) 500), false);
        actividadFisicaDAO.crearActividadFisica(actividad);
        actualizarListaActividades();
    }

    public DefaultListModel<String> getListModelActividades() {
        actualizarListaActividades();
        return listModelActividades;
    }

    // Métodos para Ejercicio
    public void crearEjercicio(String nombre, int intensidad, String imagenPath, String tecnica, float tiempoMax) {
        Ejercicio ejercicio = new Ejercicio(nombre, intensidad, imagenPath, tecnica, tiempoMax);
        File imagen = new File(imagenPath);
        ejercicioDAO.crearEjercicio(ejercicio, imagen);
        actualizarListaEjercicios();
    }

    public DefaultListModel<String> getListModelEjercicios() {
        actualizarListaEjercicios();
        return listModelEjercicios;
    }

    // Métodos para Historia
    public void crearHistoria(Date fecha, String actividadId, 
                            Historia.estadoFinalizacion estado, 
                            File imagenFile,
                            double latitud, double longitud) {
        Historia historia = new Historia(fecha, actividadId, estado, 
                                       null, latitud, longitud);
        historiaDAO.crearHistoria(historia, imagenFile);
        actualizarListaHistorias();
    }

    public DefaultListModel<String> getListModelHistorias() {
        actualizarListaHistorias();
        return listModelHistorias;
    }

    // Métodos para Historial
    public void crearHistorial(String idUsuario, String historiaId) {
        HistorialesDeUsuario historial = historialesDeUsuarioDAO.obtenerHistorialDeUsuarioPorId(idUsuario);
        if (historial == null) {
            historial = new HistorialesDeUsuario(idUsuario, new ArrayList<>());
        }
        historial.getHistorialUsuarioIds().add(historiaId);
        historialesDeUsuarioDAO.crearHistorialDeUsuario(historial);
        actualizarListaHistoriales();
    }

    public DefaultListModel<String> getListModelHistoriales() {
        actualizarListaHistoriales();
        return listModelHistoriales;
    }
    
    // Getters para los DAOs (si es necesario)
    public UsuarioDAO getUsuarioDAO() {
        return usuarioDAO;
    }

    public EjercicioDAO getEjercicioDAO() {
        return ejercicioDAO;
    }

    public ActividadFisicaDAO getActividadFisicaDAO() {
        return actividadFisicaDAO;
    }

    public HistoriaDAO getHistoriaDAO() {
        return historiaDAO;
    }

    public HistorialesDeUsuarioDAO getHistorialesDeUsuarioDAO() {
        return historialesDeUsuarioDAO;
    }
    
    public List<Historia> obtenerTodasLasHistoriasCompletas() {
        return historiaDAO.obtenerTodasLasHistorias();
    }
}