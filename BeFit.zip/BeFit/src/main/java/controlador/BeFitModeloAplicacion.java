/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelos.Ejercicio;
import vista.ModeloAplicacionBefit;

public class BeFitModeloAplicacion {
    public static void main(String[] args) {
        // Ejecutar la GUI en el hilo de eventos de Swing

        
        javax.swing.SwingUtilities.invokeLater(() -> {
            
            ModeloAplicacionBefit app = new ModeloAplicacionBefit();
            app.setVisible(true);
        });
    }
}
