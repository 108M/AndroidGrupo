package controlador;

import dao.ActividadFisicaDAO;
import dao.ActividadFisicaDAOImpl;
import dao.EjercicioDAO;
import dao.EjercicioDAOImpl;
import dao.HistoriaDAO;
import dao.HistoriaDAOImpl;
import dao.HistorialesDeUsuarioDAO;
import dao.HistorialesDeUsuarioDAOImpl;
import dao.UsuarioDAO;
import dao.UsuarioDAOImpl;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import modelos.ActividadFisica;
import modelos.Ejercicio;
import modelos.Historia;
import modelos.HistorialesDeUsuario;
import modelos.Usuario;

/**
 *
 * @author Markel
 */
public class BeFit {

    public static void main(String[] args) {
        // Crear instancias de los DAOs
        UsuarioDAO usuarioDAO = new UsuarioDAOImpl();
        EjercicioDAO ejercicioDAO = new EjercicioDAOImpl();
        ActividadFisicaDAO actividadFisicaDAO = new ActividadFisicaDAOImpl();
        HistoriaDAO historiaDAO = new HistoriaDAOImpl();
        HistorialesDeUsuarioDAO historialesDeUsuarioDAO = new HistorialesDeUsuarioDAOImpl();

        // Crear un usuario
        Usuario usuario = new Usuario("Juan", 70.5f, 1.75f, 30, Usuario.Genero.HOMBRE);
        usuarioDAO.crearUsuario(usuario);

        // Crear un ejercicio
        Ejercicio ejercicio = new Ejercicio("Flexiones", 3, null, "Técnica básica", 30);
        ejercicioDAO.crearEjercicio(ejercicio);

        // Crear una actividad física
        ArrayList<String> ejerciciosIds = new ArrayList<>();
        ejerciciosIds.add(ejercicio.getObjectId()); // Usar objectId en lugar de id
        ActividadFisica actividadFisica = new ActividadFisica(ejerciciosIds, LocalTime.now(), LocalTime.now().plusHours(1), LocalTime.now().plusHours(2), false);
        actividadFisicaDAO.crearActividadFisica(actividadFisica);

        // Crear una historia
        Historia historia = new Historia(new Date(), actividadFisica.getObjectId(), Historia.estadoFinalizacion.MEDIO, new ArrayList<>());
        historiaDAO.crearHistoria(historia);

        // Crear un historial de usuario
        ArrayList<String> historiasIds = new ArrayList<>();
        historiasIds.add(historia.getObjectId()); // Asegúrate de que el ID de la historia se agregue correctamente
        HistorialesDeUsuario historialDeUsuario = new HistorialesDeUsuario(usuario.getObjectId(), historiasIds);
        historialesDeUsuarioDAO.crearHistorialDeUsuario(historialDeUsuario);

        // Recuperar y mostrar datos
        Usuario usuarioRecuperado = usuarioDAO.obtenerUsuarioPorId(usuario.getObjectId()); // Usar objectId en lugar de id
        System.out.println("Usuario recuperado: " + usuarioRecuperado.getNombre());

        // Recuperar el historial del usuario
        System.out.println("Recuperando historial para el usuario con ID: " + usuarioRecuperado.getObjectId());
        HistorialesDeUsuario historialRecuperado = historialesDeUsuarioDAO.obtenerHistorialDeUsuarioPorIdUsuario(usuarioRecuperado.getObjectId());
        System.out.println("Historial del usuario: " + historialRecuperado.getHistorialUsuarioIds());
    }
}