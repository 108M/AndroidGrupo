package dao;

import modelos.Ejercicio;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EjercicioDAOImpl implements EjercicioDAO {
    private Map<Integer, Ejercicio> ejercicios = new HashMap<>();
    private int nextId = 1; // Simula un autoincremento de ID

    @Override
    public void crearEjercicio(Ejercicio ejercicio) {
        ejercicio.setId(nextId++);
        ejercicios.put(ejercicio.getId(), ejercicio);
    }

    @Override
    public Ejercicio obtenerEjercicioPorId(int id) {
        return ejercicios.get(id);
    }

    @Override
    public List<Ejercicio> obtenerTodosLosEjercicios() {
        return new ArrayList<>(ejercicios.values());
    }

    @Override
    public void actualizarEjercicio(Ejercicio ejercicio) {
        if (ejercicios.containsKey(ejercicio.getId())) {
            ejercicios.put(ejercicio.getId(), ejercicio);
        }
    }

    @Override
    public void eliminarEjercicio(int id) {
        ejercicios.remove(id);
    }
}