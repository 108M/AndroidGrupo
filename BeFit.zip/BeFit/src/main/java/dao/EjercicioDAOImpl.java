package dao;

import Imagenes.FileResource;
import Imagenes.ImageRepository;
import modelos.Ejercicio;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import okhttp3.*;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class EjercicioDAOImpl implements EjercicioDAO {

    private final String API_URL = "https://parseapi.back4app.com/classes/Ejercicio";
    private final String APPLICATION_ID = "CdXSEGccBwT7HOAe8T3sE6CNuFiOyJDE9DNFEhJt"; 
    private final String REST_API_KEY = "jcxfHzxoP8jDYslcfGUSbhgMNQn8Iam1Cda35WpJ";
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();
    
    private final ImageRepository imageRepo = new ImageRepository();

    @Override
    public void crearEjercicio(Ejercicio ejercicio, File imagenFile) {
        try {
            // Subir imagen si existe
            if (imagenFile != null && imagenFile.exists()) {
                FileResource imagenResource = imageRepo.upload(imagenFile, generarNombreArchivo(imagenFile));
                ejercicio.setImagenPath(imagenResource.url);
                System.out.println("Imagen subida correctamente. URL: " + imagenResource.url);
            }
            
            String json = gson.toJson(ejercicio);
            RequestBody body = RequestBody.create(json, MediaType.get("application/json"));

            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .post(body)
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                JsonObject jsonObject = gson.fromJson(responseJson, JsonObject.class);
                String objectId = jsonObject.get("objectId").getAsString();

                ejercicio.setObjectId(objectId);
                System.out.println("Ejercicio creado con éxito en Back4App. ObjectId: " + objectId);
            } else {
                System.out.println("Error al crear el ejercicio: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }
    
    private String generarNombreArchivo(File file) {
        return "historia_" + System.currentTimeMillis() + "_" + file.getName();
    }


    @Override
    public Ejercicio obtenerEjercicioPorId(String objectId) {
        try {
            Request request = new Request.Builder()
                    .url(API_URL + "/" + objectId)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                return gson.fromJson(responseJson, Ejercicio.class);
            } else {
                System.out.println("Error al obtener el ejercicio: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return null;
    }

    @Override
    public void actualizarEjercicio(Ejercicio ejercicio) {
        try {
            String json = gson.toJson(ejercicio);
            RequestBody body = RequestBody.create(json, MediaType.get("application/json"));

            Request request = new Request.Builder()
                    .url(API_URL + "/" + ejercicio.getObjectId())
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .put(body)
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                System.out.println("Ejercicio actualizado con éxito en Back4App.");
            } else {
                System.out.println("Error al actualizar el ejercicio: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }

    @Override
    public void eliminarEjercicio(String objectId) {
        try {
            Request request = new Request.Builder()
                    .url(API_URL + "/" + objectId)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .delete()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                System.out.println("Ejercicio eliminado con éxito en Back4App.");
            } else {
                System.out.println("Error al eliminar el ejercicio: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }

    @Override
    public List<Ejercicio> obtenerTodosLosEjercicios() {
        List<Ejercicio> ejercicios = new ArrayList<>();
        try {
            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                JsonObject jsonObject = gson.fromJson(responseJson, JsonObject.class);
                JsonArray jsonArray = jsonObject.getAsJsonArray("results");

                Type listType = new TypeToken<ArrayList<Ejercicio>>() {}.getType();
                ejercicios = gson.fromJson(jsonArray, listType);
            } else {
                System.out.println("Error al obtener los ejercicios: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return ejercicios;
    }

}