package dao;

import modelos.ActividadFisica;
import java.util.List;

public interface ActividadFisicaDAO {
    // Crear una nueva actividad física
    void crearActividadFisica(ActividadFisica actividadFisica);

    // Obtener una actividad física por su ID
    ActividadFisica obtenerActividadFisicaPorId(int id);

    // Obtener todas las actividades físicas
    List<ActividadFisica> obtenerTodasLasActividadesFisicas();

    // Actualizar una actividad física existente
    void actualizarActividadFisica(ActividadFisica actividadFisica);

    // Eliminar una actividad física por su ID
    void eliminarActividadFisica(int id);
}