package dao;

import modelos.HistorialesDeUsuario;
import java.util.List;

public interface HistorialesDeUsuarioDAO {
    // Crear un nuevo historial de usuario
    void crearHistorialDeUsuario(HistorialesDeUsuario historialDeUsuario);

    // Obtener un historial de usuario por su ID
    HistorialesDeUsuario obtenerHistorialDeUsuarioPorId(int idUsuario);

    // Obtener todos los historiales de usuario
    List<HistorialesDeUsuario> obtenerTodosLosHistorialesDeUsuario();

    // Actualizar un historial de usuario existente
    void actualizarHistorialDeUsuario(HistorialesDeUsuario historialDeUsuario);

    // Eliminar un historial de usuario por su ID
    void eliminarHistorialDeUsuario(int idUsuario);
}