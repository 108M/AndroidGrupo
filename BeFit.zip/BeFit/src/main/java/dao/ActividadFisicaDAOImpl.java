package dao;

import modelos.ActividadFisica;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ActividadFisicaDAOImpl implements ActividadFisicaDAO {
    private Map<Integer, ActividadFisica> actividadesFisicas = new HashMap<>();
    private int nextId = 1; // Simula un autoincremento de ID

    @Override
    public void crearActividadFisica(ActividadFisica actividadFisica) {
        actividadFisica.setId(nextId++);
        actividadesFisicas.put(actividadFisica.getId(), actividadFisica);
    }

    @Override
    public ActividadFisica obtenerActividadFisicaPorId(int id) {
        return actividadesFisicas.get(id);
    }

    @Override
    public List<ActividadFisica> obtenerTodasLasActividadesFisicas() {
        return new ArrayList<>(actividadesFisicas.values());
    }

    @Override
    public void actualizarActividadFisica(ActividadFisica actividadFisica) {
        if (actividadesFisicas.containsKey(actividadFisica.getId())) {
            actividadesFisicas.put(actividadFisica.getId(), actividadFisica);
        }
    }

    @Override
    public void eliminarActividadFisica(int id) {
        actividadesFisicas.remove(id);
    }
}