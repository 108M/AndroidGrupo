package dao;

import modelos.ActividadFisica;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import okhttp3.*;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ActividadFisicaDAOImpl implements ActividadFisicaDAO {

    private final String API_URL = "https://parseapi.back4app.com/classes/ActividadFisica";
    private final String APPLICATION_ID = "CdXSEGccBwT7HOAe8T3sE6CNuFiOyJDE9DNFEhJt"; 
    private final String REST_API_KEY = "jcxfHzxoP8jDYslcfGUSbhgMNQn8Iam1Cda35WpJ";
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();

    @Override
    public void crearActividadFisica(ActividadFisica actividadFisica) {
        try {
            String json = gson.toJson(actividadFisica);
            RequestBody body = RequestBody.create(json, MediaType.get("application/json"));

            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .post(body)
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                JsonObject jsonObject = gson.fromJson(responseJson, JsonObject.class);
                String objectId = jsonObject.get("objectId").getAsString();

                actividadFisica.setObjectId(objectId);
                System.out.println("Actividad física creada con éxito en Back4App. ObjectId: " + objectId);
            } else {
                System.out.println("Error al crear la actividad física: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }

    @Override
    public ActividadFisica obtenerActividadFisicaPorId(String objectId) {
        try {
            Request request = new Request.Builder()
                    .url(API_URL + "/" + objectId)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                return gson.fromJson(responseJson, ActividadFisica.class);
            } else {
                System.out.println("Error al obtener la actividad física: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return null;
    }

    @Override
    public void actualizarActividadFisica(ActividadFisica actividadFisica) {
        try {
            String json = gson.toJson(actividadFisica);
            RequestBody body = RequestBody.create(json, MediaType.get("application/json"));

            Request request = new Request.Builder()
                    .url(API_URL + "/" + actividadFisica.getObjectId())
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .put(body)
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                System.out.println("Actividad física actualizada con éxito en Back4App.");
            } else {
                System.out.println("Error al actualizar la actividad física: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }

    @Override
    public void eliminarActividadFisica(String objectId) {
        try {
            Request request = new Request.Builder()
                    .url(API_URL + "/" + objectId)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .delete()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                System.out.println("Actividad física eliminada con éxito en Back4App.");
            } else {
                System.out.println("Error al eliminar la actividad física: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }

    @Override
    public List<ActividadFisica> obtenerTodasLasActividadesFisicas() {
        List<ActividadFisica> actividades = new ArrayList<>();
        try {
            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                JsonObject jsonObject = gson.fromJson(responseJson, JsonObject.class);
                JsonArray jsonArray = jsonObject.getAsJsonArray("results");

                Type listType = new TypeToken<ArrayList<ActividadFisica>>() {}.getType();
                actividades = gson.fromJson(jsonArray, listType);
            } else {
                System.out.println("Error al obtener las actividades físicas: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return actividades;
    }

}