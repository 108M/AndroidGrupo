package dao;

import modelos.Historia;
import java.util.List;

public interface HistoriaDAO {
    // Crear una nueva historia
    void crearHistoria(Historia historia);

    // Obtener una historia por su ID
    Historia obtenerHistoriaPorId(int id);

    // Obtener todas las historias
    List<Historia> obtenerTodasLasHistorias();

    // Actualizar una historia existente
    void actualizarHistoria(Historia historia);

    // Eliminar una historia por su ID
    void eliminarHistoria(int id);
}