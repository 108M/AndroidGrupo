package dao;

import modelos.Historia;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HistoriaDAOImpl implements HistoriaDAO {
    private Map<Integer, Historia> historias = new HashMap<>();
    private int nextId = 1; // Simula un autoincremento de ID

    @Override
    public void crearHistoria(Historia historia) {
        historia.setId(nextId++); // Asignamos un ID único
        historias.put(historia.getId(), historia);
    }

    @Override
    public Historia obtenerHistoriaPorId(int id) {
        return historias.get(id);
    }

    @Override
    public List<Historia> obtenerTodasLasHistorias() {
        return new ArrayList<>(historias.values());
    }

    @Override
    public void actualizarHistoria(Historia historia) {
        if (historias.containsKey(historia.getId())) {
            historias.put(historia.getId(), historia);
        }
    }

    @Override
    public void eliminarHistoria(int id) {
        historias.remove(id);
    }
}