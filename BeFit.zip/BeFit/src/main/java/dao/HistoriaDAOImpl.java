package dao;

import modelos.Historia;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import okhttp3.*;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class HistoriaDAOImpl implements HistoriaDAO {

    private final String API_URL = "https://parseapi.back4app.com/classes/employee";
    private final String APPLICATION_ID = "CdXSEGccBwT7HOAe8T3sE6CNuFiOyJDE9DNFEhJt"; 
    private final String REST_API_KEY = "jcxfHzxoP8jDYslcfGUSbhgMNQn8Iam1Cda35WpJ";
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();

    @Override
    public void crearHistoria(Historia historia) {
        try {
            String json = gson.toJson(historia);
            RequestBody body = RequestBody.create(json, MediaType.get("application/json"));

            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .post(body)
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                JsonObject jsonObject = gson.fromJson(responseJson, JsonObject.class);
                String objectId = jsonObject.get("objectId").getAsString();

                historia.setObjectId(objectId);
                System.out.println("Historia creada con éxito en Back4App. ObjectId: " + objectId);
            } else {
                System.out.println("Error al crear la historia: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }
    

    @Override
    public Historia obtenerHistoriaPorId(String objectId) {
        try {
            Request request = new Request.Builder()
                    .url(API_URL + "/" + objectId)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                return gson.fromJson(responseJson, Historia.class);
            } else {
                System.out.println("Error al obtener la historia: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return null;
    }

    @Override
    public void actualizarHistoria(Historia historia) {
        try {
            String json = gson.toJson(historia);
            RequestBody body = RequestBody.create(json, MediaType.get("application/json"));

            Request request = new Request.Builder()
                    .url(API_URL + "/" + historia.getObjectId())
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .put(body)
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                System.out.println("Historia actualizada con éxito en Back4App.");
            } else {
                System.out.println("Error al actualizar la historia: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }

    @Override
    public void eliminarHistoria(String objectId) {
        try {
            Request request = new Request.Builder()
                    .url(API_URL + "/" + objectId)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .delete()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                System.out.println("Historia eliminada con éxito en Back4App.");
            } else {
                System.out.println("Error al eliminar la historia: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }

    @Override
    public List<Historia> obtenerTodasLasHistorias() {
        List<Historia> historias = new ArrayList<>();
        try {
            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                JsonObject jsonObject = gson.fromJson(responseJson, JsonObject.class);
                JsonArray jsonArray = jsonObject.getAsJsonArray("results");

                Type listType = new TypeToken<ArrayList<Historia>>() {}.getType();
                historias = gson.fromJson(jsonArray, listType);
            } else {
                System.out.println("Error al obtener las historias: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return historias;
    }

}