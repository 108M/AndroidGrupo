package dao;

import modelos.Usuario;
import java.util.List;

public interface UsuarioDAO {
    // Crear un nuevo usuario
    void crearUsuario(Usuario usuario);

    // Obtener un usuario por su ID
    Usuario obtenerUsuarioPorId(int id);

    // Obtener todos los usuarios
    List<Usuario> obtenerTodosLosUsuarios();

    // Actualizar un usuario existente
    void actualizarUsuario(Usuario usuario);

    // Eliminar un usuario por su ID
    void eliminarUsuario(int id);
}