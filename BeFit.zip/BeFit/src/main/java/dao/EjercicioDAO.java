package dao;

import modelos.Ejercicio;
import java.util.List;

public interface EjercicioDAO {
    // Crear un nuevo ejercicio
    void crearEjercicio(Ejercicio ejercicio);

    // Obtener un ejercicio por su ID
    Ejercicio obtenerEjercicioPorId(int id);

    // Obtener todos los ejercicios
    List<Ejercicio> obtenerTodosLosEjercicios();

    // Actualizar un ejercicio existente
    void actualizarEjercicio(Ejercicio ejercicio);

    // Eliminar un ejercicio por su ID
    void eliminarEjercicio(int id);
}