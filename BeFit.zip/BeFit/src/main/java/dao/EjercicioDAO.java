package dao;

import java.io.File;
import modelos.Ejercicio;
import java.util.List;

public interface EjercicioDAO {
    // Crear un nuevo ejercicio
    void crearEjercicio(Ejercicio ejercicio, File imagenFile);

    // Obtener un ejercicio por su ID
    Ejercicio obtenerEjercicioPorId(String objectId);

    // Obtener todos los ejercicios
    List<Ejercicio> obtenerTodosLosEjercicios();

    // Actualizar un ejercicio existente
    void actualizarEjercicio(Ejercicio ejercicio);

    // Eliminar un ejercicio por su ID
    void eliminarEjercicio(String objectId);
}