package dao;

import modelos.Usuario;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import okhttp3.*;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAOImpl implements UsuarioDAO {

    private final String API_URL = "https://parseapi.back4app.com/classes/employee";
    private final String APPLICATION_ID = "CdXSEGccBwT7HOAe8T3sE6CNuFiOyJDE9DNFEhJt"; 
    private final String REST_API_KEY = "jcxfHzxoP8jDYslcfGUSbhgMNQn8Iam1Cda35WpJ";
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();

    @Override
    public void crearUsuario(Usuario usuario) {
        try {
            // Convertir el objeto Usuario a JSON (sin el campo id)
            String json = gson.toJson(usuario);
            RequestBody body = RequestBody.create(json, MediaType.get("application/json"));

            // Crear la solicitud POST
            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .post(body)
                    .build();

            // Ejecutar la solicitud
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                // Capturar el objectId devuelto por Back4App
                String responseJson = response.body().string();
                JsonObject jsonObject = gson.fromJson(responseJson, JsonObject.class);
                String objectId = jsonObject.get("objectId").getAsString();

                // Asignar el objectId al usuario
                usuario.setObjectId(objectId);
                System.out.println("Usuario creado con éxito en Back4App. ObjectId: " + objectId);
            } else {
                System.out.println("Error al crear el usuario: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }

    @Override
    public Usuario obtenerUsuarioPorId(String objectId) {
        try {
            Request request = new Request.Builder()
                    .url(API_URL + "/" + objectId)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                return gson.fromJson(responseJson, Usuario.class);
            } else {
                System.out.println("Error al obtener el usuario: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Usuario> obtenerTodosLosUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        try {
            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                JsonObject jsonObject = gson.fromJson(responseJson, JsonObject.class);
                JsonArray jsonArray = jsonObject.getAsJsonArray("results");

                Type listType = new TypeToken<ArrayList<Usuario>>() {}.getType();
                usuarios = gson.fromJson(jsonArray, listType);
            } else {
                System.out.println("Error al obtener los usuarios: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return usuarios;
    }

    @Override
    public void actualizarUsuario(Usuario usuario) {
        try {
            String json = gson.toJson(usuario);
            RequestBody body = RequestBody.create(json, MediaType.get("application/json"));

            Request request = new Request.Builder()
                    .url(API_URL + "/" + usuario.getObjectId())
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .put(body)
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                System.out.println("Usuario actualizado con éxito en Back4App.");
            } else {
                System.out.println("Error al actualizar el usuario: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
}

    @Override
    public void eliminarUsuario(String objectId) {
        try {
            Request request = new Request.Builder()
                    .url(API_URL + "/" + objectId)
                    .addHeader("X-Parse-Application-Id", APPLICATION_ID)
                    .addHeader("X-Parse-REST-API-Key", REST_API_KEY)
                    .delete()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                System.out.println("Usuario eliminado con éxito en Back4App.");
            } else {
                System.out.println("Error al eliminar el usuario: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }
}