package dao;

import modelos.Usuario;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UsuarioDAOImpl implements UsuarioDAO {
    private Map<Integer, Usuario> usuarios = new HashMap<>();
    private int nextId = 1; // Simula un autoincremento de ID

    @Override
    public void crearUsuario(Usuario usuario) {
        usuario.setId(nextId++);
        usuarios.put(usuario.getId(), usuario);
    }

    @Override
    public Usuario obtenerUsuarioPorId(int id) {
        return usuarios.get(id);
    }

    @Override
    public List<Usuario> obtenerTodosLosUsuarios() {
        return new ArrayList<>(usuarios.values());
    }

    @Override
    public void actualizarUsuario(Usuario usuario) {
        if (usuarios.containsKey(usuario.getId())) {
            usuarios.put(usuario.getId(), usuario);
        }
    }

    @Override
    public void eliminarUsuario(int id) {
        usuarios.remove(id);
    }
}