package dao;

import modelos.HistorialesDeUsuario;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import okhttp3.*;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class HistorialesDeUsuarioDAOImpl implements HistorialesDeUsuarioDAO {

    private final String API_URL = "https://parseapi.back4app.com/classes/HistorialesDeUsuario";
    private final Claves claves = new Claves();
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();

    @Override
    public void crearHistorialDeUsuario(HistorialesDeUsuario historial) {
        try {
            String json = gson.toJson(historial);
            RequestBody body = RequestBody.create(json, MediaType.get("application/json"));

            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("X-Parse-Application-Id", claves.getAPPLICATION_ID())
                    .addHeader("X-Parse-REST-API-Key", claves.getREST_API_KEY())
                    .post(body)
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                JsonObject jsonObject = gson.fromJson(responseJson, JsonObject.class);
                String objectId = jsonObject.get("objectId").getAsString();

                historial.setObjectId(objectId);
                System.out.println("Historial de usuario creado con éxito en Back4App. ObjectId: " + objectId);
            } else {
                System.out.println("Error al crear el historial de usuario: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }
    
    @Override
    public HistorialesDeUsuario obtenerHistorialDeUsuarioPorIdUsuario(String idUsuario) {
        try {
            // Construir la URL con la consulta para buscar por idUsuario
            String url = API_URL + "?where={\"idUsuario\":\"" + idUsuario + "\"}";

            Request request = new Request.Builder()
                    .url(url)
                    .addHeader("X-Parse-Application-Id", claves.getAPPLICATION_ID())
                    .addHeader("X-Parse-REST-API-Key", claves.getREST_API_KEY())
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                // Parsear la respuesta JSON
                JsonObject jsonObject = gson.fromJson(responseJson, JsonObject.class);
                JsonArray results = jsonObject.getAsJsonArray("results");

                // Si hay resultados, devolver el primero
                if (results.size() > 0) {
                    return gson.fromJson(results.get(0), HistorialesDeUsuario.class);
                } else {
                    System.out.println("No se encontró ningún historial para el usuario con ID: " + idUsuario);
                }
            } else {
                System.out.println("Error al obtener el historial de usuario: " + idUsuario + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return null;
    }

    @Override
    public HistorialesDeUsuario obtenerHistorialDeUsuarioPorId(String objectId) {
        try {
            Request request = new Request.Builder()
                    .url(API_URL + "/" + objectId)
                    .addHeader("X-Parse-Application-Id", claves.getAPPLICATION_ID())
                    .addHeader("X-Parse-REST-API-Key", claves.getREST_API_KEY())
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                return gson.fromJson(responseJson, HistorialesDeUsuario.class);
            } else {
                System.out.println("Error al obtener el historial de usuario: " + objectId);
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return null;
    }

    @Override
    public void actualizarHistorialDeUsuario(HistorialesDeUsuario historialDeUsuario) {
        try {
            String json = gson.toJson(historialDeUsuario);
            RequestBody body = RequestBody.create(json, MediaType.get("application/json"));

            Request request = new Request.Builder()
                    .url(API_URL + "/" + historialDeUsuario.getObjectId())
                    .addHeader("X-Parse-Application-Id", claves.getAPPLICATION_ID())
                    .addHeader("X-Parse-REST-API-Key", claves.getREST_API_KEY())
                    .put(body)
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                System.out.println("Historial de usuario actualizado con éxito en Back4App.");
            } else {
                System.out.println("Error al actualizar el historial de usuario: " + historialDeUsuario.getObjectId());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }

    @Override
    public void eliminarHistorialDeUsuario(String objectId) {
        try {
            Request request = new Request.Builder()
                    .url(API_URL + "/" + objectId)
                    .addHeader("X-Parse-Application-Id", claves.getAPPLICATION_ID())
                    .addHeader("X-Parse-REST-API-Key", claves.getREST_API_KEY())
                    .delete()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                System.out.println("Historial de usuario eliminado con éxito en Back4App.");
            } else {
                System.out.println("Error al eliminar el historial de usuario: " + objectId);
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }

    @Override
    public List<HistorialesDeUsuario> obtenerTodosLosHistorialesDeUsuario() {
        List<HistorialesDeUsuario> historiales = new ArrayList<>();
        try {
            Request request = new Request.Builder()
                    .url(API_URL)
                    .addHeader("X-Parse-Application-Id", claves.getAPPLICATION_ID())
                    .addHeader("X-Parse-REST-API-Key", claves.getREST_API_KEY())
                    .get()
                    .build();

            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseJson = response.body().string();
                JsonObject jsonObject = gson.fromJson(responseJson, JsonObject.class);
                JsonArray jsonArray = jsonObject.getAsJsonArray("results");

                Type listType = new TypeToken<ArrayList<HistorialesDeUsuario>>() {}.getType();
                historiales = gson.fromJson(jsonArray, listType);
            } else {
                System.out.println("Error al obtener los historiales de usuario: " + response.body().string());
            }
        } catch (IOException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return historiales;
    }

}