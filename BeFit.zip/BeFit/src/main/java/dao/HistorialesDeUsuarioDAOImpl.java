package dao;

import modelos.HistorialesDeUsuario;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HistorialesDeUsuarioDAOImpl implements HistorialesDeUsuarioDAO {
    private Map<Integer, HistorialesDeUsuario> historialesDeUsuario = new HashMap<>();

    @Override
    public void crearHistorialDeUsuario(HistorialesDeUsuario historialDeUsuario) {
        // Usamos el ID del usuario como clave en el Map
        historialesDeUsuario.put(historialDeUsuario.getIdUsuario(), historialDeUsuario);
    }

    @Override
    public HistorialesDeUsuario obtenerHistorialDeUsuarioPorId(int idUsuario) {
        return historialesDeUsuario.get(idUsuario);
    }

    @Override
    public List<HistorialesDeUsuario> obtenerTodosLosHistorialesDeUsuario() {
        return new ArrayList<>(historialesDeUsuario.values());
    }

    @Override
    public void actualizarHistorialDeUsuario(HistorialesDeUsuario historialDeUsuario) {
        if (historialesDeUsuario.containsKey(historialDeUsuario.getIdUsuario())) {
            historialesDeUsuario.put(historialDeUsuario.getIdUsuario(), historialDeUsuario);
        }
    }

    @Override
    public void eliminarHistorialDeUsuario(int idUsuario) {
        historialesDeUsuario.remove(idUsuario);
    }
}