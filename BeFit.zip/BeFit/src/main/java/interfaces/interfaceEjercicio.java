/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

import java.util.List;
import javax.swing.ImageIcon;
import modelos.Ejercicio;

/**
 *
 * @author Markel
 */
public interface interfaceEjercicio {

    public List<Ejercicio> getEjercicios();
    public void agregarEjercicio(String nombre_ejercicio, int intensidad, ImageIcon imagen, String tecnica, float tiempoMax);
    public Ejercicio buscarEjercicio(String nombre);
    public void asignarIntensidad (String nombre, int intensidad);
    public void asignarTiempoMax (String nombre, float tiempoMax);
   
}
