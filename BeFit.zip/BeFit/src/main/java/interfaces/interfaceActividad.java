/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

import java.util.List;
import modelos.ActividadFisica;
import modelos.Ejercicio;

/**
 *
 * @author Markel
 */
public interface interfaceActividad {
    
    public void FinalizarActividad (int idActividad);
    public void AñadirEjercicoActividad (int idActividad, Ejercicio ejercicio);
    public ActividadFisica buscarActividad (int id);
    public List <ActividadFisica> getListaActividades ();
    
    
}
