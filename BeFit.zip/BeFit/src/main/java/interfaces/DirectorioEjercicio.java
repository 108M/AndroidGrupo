/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;
import modelos.Ejercicio;

/**
 *
 * @author Markel
 */

//esto es como tu base de datos es insertar, buscar ejercicios, eliminar y añadir
public class DirectorioEjercicio implements interfaceEjercicio{
    List<Ejercicio> ListaEjercicios;
    
    
    public DirectorioEjercicio(List<Ejercicio> ListaEjercicios) {
        this.ListaEjercicios = new ArrayList<>(); // Inicializar la lista
    }
    
    @Override
    public List<Ejercicio> getEjercicios() {
        return ListaEjercicios;
    }
    
    
    @Override
    public void agregarEjercicio(String nombre_ejercicio, int intensidad, ImageIcon imagen, String tecnica, float tiempoMax) {
        ListaEjercicios.add(new Ejercicio(nombre_ejercicio, intensidad, imagen,tecnica, tiempoMax));
    }
    
    
    @Override
    public Ejercicio buscarEjercicio(String nombre) {
        for (Ejercicio ejercicio : ListaEjercicios) {
            if (ejercicio.getNombre_ejercicios().equals(nombre)) {
                return ejercicio;
            }
        } 
        return null;
    }
    
    
    @Override
    public void asignarIntensidad (String nombre, int intensidad)
    {
        Ejercicio aux = buscarEjercicio(nombre);
        aux.setIntensidad(intensidad);
        
        
    }
    
    @Override
    public void asignarTiempoMax (String nombre, float tiempoMax)
    {
        Ejercicio aux = buscarEjercicio(nombre);
        aux.setTiempoMax(tiempoMax);
        
        
    }
            
    
    
}
