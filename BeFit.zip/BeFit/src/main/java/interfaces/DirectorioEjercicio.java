/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import java.util.List;
import modelos.Ejercicio;

/**
 *
 * @author Markel
 */

//esto es como tu base de datos es insertar, buscar ejercicios, eliminar y añadir
public class DirectorioEjercicio implements interfaceEjercicio{
    List<Ejercicio> ListaEjercicios;
    
    
    
}
