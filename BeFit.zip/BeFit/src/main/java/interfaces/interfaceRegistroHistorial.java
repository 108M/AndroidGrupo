package interfaces;

import java.util.List;
import modelos.Historia;
import modelos.HistorialesDeUsuario;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author Markel
 */
public interface interfaceRegistroHistorial {
    
    public List<HistorialesDeUsuario> getHistorialTotal();
    public void setHistorialTotal(List<HistorialesDeUsuario> Historial);
    public HistorialesDeUsuario obtenerHistorial(int id);
    public void AñadirHistoria (int id, Historia historia);
    
}
