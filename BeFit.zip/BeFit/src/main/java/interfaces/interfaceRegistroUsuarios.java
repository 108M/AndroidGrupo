/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

import modelos.ActividadFisica;
import modelos.Usuario;

/**
 *
 * @author Markel
 */
public interface interfaceRegistroUsuarios {
    
    public void añadirUsuario (String nombre, int id, float peso, float altura, int edad ,Usuario.Genero genero, Usuario.Dificultad dificultad, ActividadFisica actividad);
    public Usuario getUsuario (int id);
    
    
}
