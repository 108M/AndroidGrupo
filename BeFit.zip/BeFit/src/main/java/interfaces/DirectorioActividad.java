/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import java.util.List;
import modelos.ActividadFisica;
import modelos.Ejercicio;

/**
 *
 * @author Markel
 */
public class DirectorioActividad implements interfaceActividad{
    List <ActividadFisica> ListaActividades;

    public DirectorioActividad(List<ActividadFisica> ListaActividades) {
        this.ListaActividades = ListaActividades;
    }
    
    @Override
    public List <ActividadFisica> getListaActividades ()
    {
        return ListaActividades;
    }
    
    @Override
    public ActividadFisica buscarActividad (int id)
    {
        for (ActividadFisica actividad : ListaActividades)
        {
            if (actividad.getId() == id) 
            {
                return actividad;
            }
            
        }
        return null;
    }
    
    
    @Override
    public void AñadirEjercicoActividad (int idActividad, Ejercicio ejercicio)
    {
        ActividadFisica aux = buscarActividad(idActividad);
        
        aux.getListaEjercicios().add(ejercicio);
        
    }
    
    @Override
    public void FinalizarActividad (int idActividad)
    {
        ActividadFisica aux = buscarActividad (idActividad);
        aux.setEstado(Boolean.FALSE);
    }
    
    
    
    
    
    
    
}
