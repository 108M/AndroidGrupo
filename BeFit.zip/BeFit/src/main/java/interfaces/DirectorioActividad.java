/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import java.util.List;
import modelos.ActividadFisica;
import modelos.Ejercicio;

/**
 *
 * @author Markel
 */
public class DirectorioActividad implements interfaceActividad{
    ActividadFisica Actividad;

    public DirectorioActividad(ActividadFisica ListaActividades) {
        this.Actividad = ListaActividades;
    }
    
    @Override
    public ActividadFisica getActividad ()
    {
        return Actividad;
    }
    
    
    @Override
    public void AñadirEjercicoActividad ( Ejercicio ejercicio)
    {
       Actividad.añadirEjercicio(ejercicio);
        
    }
    
    @Override
    public void FinalizarActividad ()
    {
        
        Actividad.setEstado(Boolean.FALSE);
    }
    
    
    
    
    
    
    
}
