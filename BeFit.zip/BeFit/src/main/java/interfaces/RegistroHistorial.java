/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import java.util.ArrayList;
import java.util.List;
import modelos.Historia;
import modelos.HistorialesDeUsuario;

/**
 *
 * @author Markel
 */
public class RegistroHistorial implements interfaceRegistroHistorial {
    List <HistorialesDeUsuario> HistorialTotal;
    
    public RegistroHistorial(List<HistorialesDeUsuario> Historial) {
        this.HistorialTotal = Historial;
    }
    
    @Override
    public List<HistorialesDeUsuario> getHistorialTotal() {
        return HistorialTotal;
    }

    
    @Override
    public void setHistorialTotal(List<HistorialesDeUsuario> Historial) {
        this.HistorialTotal = Historial;
    }

    @Override
    public HistorialesDeUsuario obtenerHistorial (int id)
    {
        for(HistorialesDeUsuario historia: HistorialTotal)
        {
            if (historia.getId() == id)
            {
                return historia;            
            }
        }
        return null;
    }
    
    @Override
    public void AñadirHistoria (int id, Historia historia)
    {
       try
       {
           obtenerHistorial(id).getHistorialUsuario().add(historia);
       }catch (Exception e)
       {
            List<Historia> auxHistoria = new ArrayList<Historia>();
            auxHistoria.add(historia);
            HistorialesDeUsuario aux = new HistorialesDeUsuario (id, auxHistoria);
            HistorialTotal.add(aux);
       }
       
    }

    
        
    
}
