/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import java.util.List;
import modelos.ActividadFisica;
import modelos.Usuario;
import modelos.Usuario.Dificultad;
import modelos.Usuario.Genero;

/**
 *
 * @author Markel
 */
public class RegistroUsuarios implements interfaceRegistroUsuarios {
    
    List <Usuario> registroUsuarios;

    public RegistroUsuarios(List<Usuario> registroUsuarios) {
        this.registroUsuarios = registroUsuarios;
    }
    
    
    @Override
    public void añadirUsuario (String nombre, int id, float peso, float altura, int edad ,Genero genero, Dificultad dificultad, ActividadFisica actividad )
    {
        Usuario usuario = new Usuario ( id,nombre, peso, altura,edad, genero, dificultad, actividad);
        registroUsuarios.add(usuario);
    }
    
    @Override
    public Usuario getUsuario (int id)
    {
        for (Usuario usuario : registroUsuarios)
        {
            if (usuario.getId() == id)
            {
                return usuario;
            }
        }
        return null;
    }
    
    
    
    
    
}
