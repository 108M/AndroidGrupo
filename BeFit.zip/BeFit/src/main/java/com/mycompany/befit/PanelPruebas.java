package com.mycompany.befit;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import modelos.*;

public class PanelPruebas extends JFrame {

    private JButton btnCrearUsuario, btnListarUsuarios, btnCrearActividad, btnListarActividades,
            btnCrearEjercicio, btnListarEjercicios, btnCrearHistoria, btnListarHistorias,
            btnCrearHistorial, btnListarHistoriales;

    private DefaultListModel<String> listModelUsuarios, listModelActividades, listModelEjercicios,
            listModelHistorias, listModelHistoriales;

    // Listas para almacenar los objetos
    private List<Usuario> usuarios = new ArrayList<>();
    private List<ActividadFisica> actividades = new ArrayList<>();
    private List<Ejercicio> ejercicios = new ArrayList<>();
    private List<Historia> historias = new ArrayList<>();
    private List<HistorialesDeUsuario> historiales = new ArrayList<>();

    public PanelPruebas() {
        setTitle("Panel de Control");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Inicializar modelos de lista
        listModelUsuarios = new DefaultListModel<>();
        listModelActividades = new DefaultListModel<>();
        listModelEjercicios = new DefaultListModel<>();
        listModelHistorias = new DefaultListModel<>();
        listModelHistoriales = new DefaultListModel<>();

        // Crear botones
        btnCrearUsuario = new JButton("Crear Usuario");
        btnListarUsuarios = new JButton("Listar Usuarios");
        btnCrearActividad = new JButton("Crear Actividad");
        btnListarActividades = new JButton("Listar Actividades");
        btnCrearEjercicio = new JButton("Crear Ejercicio");
        btnListarEjercicios = new JButton("Listar Ejercicios");
        btnCrearHistoria = new JButton("Crear Historia");
        btnListarHistorias = new JButton("Listar Historias");
        btnCrearHistorial = new JButton("Crear Historial");
        btnListarHistoriales = new JButton("Listar Historiales");

        // Configurar el layout
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.add(btnCrearUsuario);
        panel.add(btnListarUsuarios);
        panel.add(btnCrearActividad);
        panel.add(btnListarActividades);
        panel.add(btnCrearEjercicio);
        panel.add(btnListarEjercicios);
        panel.add(btnCrearHistoria);
        panel.add(btnListarHistorias);
        panel.add(btnCrearHistorial);
        panel.add(btnListarHistoriales);

        // Añadir el panel al JFrame
        add(panel);

        // Asignar acciones a los botones
        btnCrearUsuario.addActionListener(e -> crearUsuario());
        btnListarUsuarios.addActionListener(e -> listarUsuarios());
        btnCrearActividad.addActionListener(e -> crearActividadFisica());
        btnListarActividades.addActionListener(e -> listarActividadesFisicas());
        btnCrearEjercicio.addActionListener(e -> crearEjercicio());
        btnListarEjercicios.addActionListener(e -> listarEjercicios());
        btnCrearHistoria.addActionListener(e -> crearHistoria());
        btnListarHistorias.addActionListener(e -> listarHistorias());
        btnCrearHistorial.addActionListener(e -> crearHistorialUsuario());
        btnListarHistoriales.addActionListener(e -> listarHistorialesUsuario());
    }

    private void crearUsuario() {
        JTextField nombreField = new JTextField();
        JTextField idField = new JTextField();
        JTextField pesoField = new JTextField();
        JTextField alturaField = new JTextField();
        JTextField edadField = new JTextField();
        JComboBox<Usuario.Genero> generoCombo = new JComboBox<>(Usuario.Genero.values());
        JComboBox<Usuario.Dificultad> dificultadCombo = new JComboBox<>(Usuario.Dificultad.values());

        JPanel panel = new JPanel(new GridLayout(7, 2));
        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("ID:"));
        panel.add(idField);
        panel.add(new JLabel("Peso:"));
        panel.add(pesoField);
        panel.add(new JLabel("Altura:"));
        panel.add(alturaField);
        panel.add(new JLabel("Edad:"));
        panel.add(edadField);
        panel.add(new JLabel("Género:"));
        panel.add(generoCombo);
        panel.add(new JLabel("Dificultad:"));
        panel.add(dificultadCombo);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Usuario", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String nombre = nombreField.getText();
            int id = Integer.parseInt(idField.getText());
            float peso = Float.parseFloat(pesoField.getText());
            float altura = Float.parseFloat(alturaField.getText());
            int edad = Integer.parseInt(edadField.getText());
            Usuario.Genero genero = (Usuario.Genero) generoCombo.getSelectedItem();
            Usuario.Dificultad dificultad = (Usuario.Dificultad) dificultadCombo.getSelectedItem();

            Usuario usuario = new Usuario(id, nombre, peso, altura, edad, genero, dificultad, null);
            usuarios.add(usuario);
            listModelUsuarios.addElement(usuario.getNombre() + " - ID: " + usuario.getId());
            JOptionPane.showMessageDialog(null, "Usuario creado con éxito.");
        }
    }

    private void listarUsuarios() {
        JList<String> list = new JList<>(listModelUsuarios);
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Usuarios", JOptionPane.PLAIN_MESSAGE);
    }

    private void crearActividadFisica() {
        JTextField idField = new JTextField();
        JTextField horaComienzoField = new JTextField();
        JTextField horaMaximaField = new JTextField();
        JTextField horaFinalizacionField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("ID:"));
        panel.add(idField);
        panel.add(new JLabel("Hora de comienzo (HH:MM):"));
        panel.add(horaComienzoField);
        panel.add(new JLabel("Hora máxima (HH:MM):"));
        panel.add(horaMaximaField);
        panel.add(new JLabel("Hora de finalización (HH:MM):"));
        panel.add(horaFinalizacionField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Actividad Física", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            int id = Integer.parseInt(idField.getText());
            String horaComienzo = horaComienzoField.getText();
            String horaMaxima = horaMaximaField.getText();
            String horaFinalizacion = horaFinalizacionField.getText();

            ActividadFisica actividad = new ActividadFisica(id, new ArrayList<>(), LocalTime.parse(horaComienzo),
                    LocalTime.parse(horaMaxima), LocalTime.parse(horaFinalizacion), false);
            actividades.add(actividad);
            listModelActividades.addElement("ID: " + actividad.getId() + " - Hora de comienzo: " + actividad.getHora_comienzo_actividad());
            JOptionPane.showMessageDialog(null, "Actividad física creada con éxito.");
        }
    }

    private void listarActividadesFisicas() {
        JList<String> list = new JList<>(listModelActividades);
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Actividades Físicas", JOptionPane.PLAIN_MESSAGE);
    }

    private void crearEjercicio() {
        JTextField nombreField = new JTextField();
        JTextField intensidadField = new JTextField();
        JTextField tecnicaField = new JTextField();
        JTextField tiempoMaxField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("Intensidad:"));
        panel.add(intensidadField);
        panel.add(new JLabel("Técnica:"));
        panel.add(tecnicaField);
        panel.add(new JLabel("Tiempo máximo (minutos):"));
        panel.add(tiempoMaxField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Ejercicio", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String nombre = nombreField.getText();
            int intensidad = Integer.parseInt(intensidadField.getText());
            String tecnica = tecnicaField.getText();
            float tiempoMax = Float.parseFloat(tiempoMaxField.getText());

            Ejercicio ejercicio = new Ejercicio(nombre, intensidad, null, tecnica, tiempoMax);
            ejercicios.add(ejercicio);
            listModelEjercicios.addElement(ejercicio.getNombre_ejercicios() + " - Intensidad: " + ejercicio.getIntensidad());
            JOptionPane.showMessageDialog(null, "Ejercicio creado con éxito.");
        }
    }

    private void listarEjercicios() {
        JList<String> list = new JList<>(listModelEjercicios);
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Ejercicios", JOptionPane.PLAIN_MESSAGE);
    }

    private void crearHistoria() {
        JTextField fechaField = new JTextField();
        JTextField idActividadField = new JTextField();
        JComboBox<Historia.estadoFinalizacion> estadoCombo = new JComboBox<>(Historia.estadoFinalizacion.values());

        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(new JLabel("Fecha (YYYY-MM-DD):"));
        panel.add(fechaField);
        panel.add(new JLabel("ID de la actividad:"));
        panel.add(idActividadField);
        panel.add(new JLabel("Estado de finalización:"));
        panel.add(estadoCombo);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Historia", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String fecha = fechaField.getText();
            int idActividad = Integer.parseInt(idActividadField.getText());
            Historia.estadoFinalizacion estado = (Historia.estadoFinalizacion) estadoCombo.getSelectedItem();

            ActividadFisica actividad = actividades.stream()
                    .filter(a -> a.getId() == idActividad)
                    .findFirst()
                    .orElse(null);

            if (actividad != null) {
                Historia historia = new Historia(new Date(), actividad, estado, new ArrayList<>());
                historias.add(historia);
                listModelHistorias.addElement("Fecha: " + historia.getFecha() + " - Estado: " + historia.getEstadoFinalizacion());
                JOptionPane.showMessageDialog(null, "Historia creada con éxito.");
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró la actividad con el ID proporcionado.");
            }
        }
    }

    private void listarHistorias() {
        JList<String> list = new JList<>(listModelHistorias);
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Historias", JOptionPane.PLAIN_MESSAGE);
    }

    private void crearHistorialUsuario() {
        JTextField idUsuarioField = new JTextField();
        JTextField idHistoriaField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(2, 2));
        panel.add(new JLabel("ID del usuario:"));
        panel.add(idUsuarioField);
        panel.add(new JLabel("ID de la historia:"));
        panel.add(idHistoriaField);

        int result = JOptionPane.showConfirmDialog(null, panel, "Crear Historial de Usuario", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            int idUsuario = Integer.parseInt(idUsuarioField.getText());
            int idHistoria = Integer.parseInt(idHistoriaField.getText());

            Usuario usuario = usuarios.stream()
                    .filter(u -> u.getId() == idUsuario)
                    .findFirst()
                    .orElse(null);

            Historia historia = historias.stream()
                    .filter(h -> h.getActividad_registrada().getId() == idHistoria)
                    .findFirst()
                    .orElse(null);

            if (usuario != null && historia != null) {
                HistorialesDeUsuario historial = new HistorialesDeUsuario(idUsuario, List.of(historia));
                historiales.add(historial);
                listModelHistoriales.addElement("ID Usuario: " + historial.getId() + " - Historias: " + historial.getHistorialUsuario().size());
                JOptionPane.showMessageDialog(null, "Historial de usuario creado con éxito.");
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró el usuario o la historia con los IDs proporcionados.");
            }
        }
    }

    private void listarHistorialesUsuario() {
        JList<String> list = new JList<>(listModelHistoriales);
        JScrollPane scrollPane = new JScrollPane(list);
        JOptionPane.showMessageDialog(null, scrollPane, "Lista de Historiales de Usuario", JOptionPane.PLAIN_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PanelPruebas frame = new PanelPruebas();
            frame.setVisible(true);
        });
    }
}