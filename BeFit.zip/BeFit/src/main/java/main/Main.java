package main;

import vista.LoginRegistroVista;

public class Main {
    public static void main(String[] args) {
        LoginRegistroVista vista = new LoginRegistroVista();
        vista.mostrar();
    }
}