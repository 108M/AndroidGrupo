
package modelos;

import javax.swing.ImageIcon;

public class Ejercicio {
        public enum nombre_ejercicio {
            FLEXIONES, DOMINADAS, ABDOMINALES, CORRER, BURPIS
        }
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre_ejercicio() {
        return nombre_ejercicio;
    }

    public void setNombre_ejercicio(String nombre_ejercicio) {
        this.nombre_ejercicio = nombre_ejercicio;
    }
    private String nombre_ejercicio;
    private Integer intensidad;   
    private ImageIcon imagen;
    private String tecnica;
    private float tiempoMax;
    
    public Ejercicio(String nombre_ejercicio, Integer intensidad, ImageIcon imagen, String tecnica, float tiempo) {
        this.nombre_ejercicio = nombre_ejercicio;
        this.intensidad = intensidad;
        this.imagen = imagen;
        this.tecnica = tecnica;
        this.tiempoMax = tiempo;
    }

    public String getNombre_ejercicios() {
        return nombre_ejercicio;
    }

    public void setNombre_ejercicios(String nombre_ejercicio) {
        this.nombre_ejercicio = nombre_ejercicio;
    }

    public Integer getIntensidad() {
        return intensidad;
    }

    public void setIntensidad(Integer intensidad) {
        this.intensidad = intensidad;
    }

    public ImageIcon getImagen() {
        return imagen;
    }

    public void setImagen(ImageIcon imagen) {
        this.imagen = imagen;
    }

    public String getTecnica() {
        return tecnica;
    }

    public void setTecnica(String tecnica) {
        this.tecnica = tecnica;
    }

    public float getTiempoMax() {
        return tiempoMax;
    }

    public void setTiempoMax(float tiempoMax) {
        this.tiempoMax = tiempoMax;
    }
    
    
    
    
    
    
    
   
    
    

    

    
}
