package modelos;

public class Ejercicio {
    private String objectId;
    private String nombre;
    private Integer intensidad;
    private String imagenPath; // Ruta de la imagen en lugar de ImageIcon
    private String tecnica;
    private float tiempoMax;

    public Ejercicio(String nombre, Integer intensidad, String imagenPath, String tecnica, float tiempoMax) {
        this.nombre = nombre;
        this.intensidad = intensidad;
        this.imagenPath = imagenPath;
        this.tecnica = tecnica;
        this.tiempoMax = tiempoMax;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getIntensidad() {
        return intensidad;
    }

    public void setIntensidad(Integer intensidad) {
        this.intensidad = intensidad;
    }

    public String getImagenPath() {
        return imagenPath;
    }

    public void setImagenPath(String imagenPath) {
        this.imagenPath = imagenPath;
    }

    public String getTecnica() {
        return tecnica;
    }

    public void setTecnica(String tecnica) {
        this.tecnica = tecnica;
    }

    public float getTiempoMax() {
        return tiempoMax;
    }

    public void setTiempoMax(float tiempoMax) {
        this.tiempoMax = tiempoMax;
    }

    
}