package modelos;

public class Ejercicio {
    private String objectId;
    private String nombre;
    private Integer intensidad;
    private String imagenPath; // Ruta de la imagen en lugar de ImageIcon
    private String tecnica;
    private float tiempoMax;

    public Ejercicio(String nombre, Integer intensidad, String imagenPath, String tecnica, float tiempoMax) {
        this.nombre = nombre;
        this.intensidad = intensidad;
        this.imagenPath = imagenPath;
        this.tecnica = tecnica;
        this.tiempoMax = tiempoMax;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        this.nombre = nombre;
    }

    public Integer getIntensidad() {
        return intensidad;
    }

    public void setIntensidad(Integer intensidad) {
        if (intensidad == null || intensidad < 1 || intensidad > 10) {
            throw new IllegalArgumentException("La intensidad debe estar entre 1 y 10.");
        }
        this.intensidad = intensidad;
    }

    public String getImagenPath() {
        return imagenPath;
    }

    public void setImagenPath(String imagenPath) {
        if (imagenPath == null || imagenPath.trim().isEmpty()) {
            throw new IllegalArgumentException("La ruta de la imagen no puede estar vacía.");
        }
        this.imagenPath = imagenPath;
    }

    public String getTecnica() {
        if (tecnica == null || tecnica.trim().isEmpty()) {
            throw new IllegalArgumentException("La técnica no puede estar vacía.");
        }
        return tecnica;
    }

    public void setTecnica(String tecnica) {
        if (tecnica == null || tecnica.trim().isEmpty()) {
            throw new IllegalArgumentException("La técnica no puede estar vacía.");
        }
        this.tecnica = tecnica;
    }

    public float getTiempoMax() {
        return tiempoMax;
    }

    public void setTiempoMax(float tiempoMax) {
        if (tiempoMax <= 0) {
            throw new IllegalArgumentException("El tiempo máximo debe ser mayor a 0.");
        }
        this.tiempoMax = tiempoMax;
    }

    
}