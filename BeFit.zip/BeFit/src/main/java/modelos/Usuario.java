package modelos;

import dao.HistorialesDeUsuarioDAO;

public class Usuario {
       
    public enum Genero 
    {
        HOMBRE, MUJER, OTROS
    }
    public enum Dificultad 
    {
        FACIL, MEDIO, DIFICIL
    }

    private String Nombre;
    private int id;
    private float peso;
    private float altura;
    private Integer edad;
    private Genero genero;
    private Dificultad dificultad;

    public Usuario(int id, String Nombre, float peso, float altura, Integer edad, Genero genero) {
        this.id = id;
        this.Nombre = Nombre;
        this.peso = peso;
        this.altura = altura;
        this.edad = edad;
        this.genero = genero;
        this.dificultad = calcularDificultad();
    }
    
    private Dificultad calcularDificultad() {
        if (edad == null || peso <= 0 || altura <= 0) {
            return Dificultad.MEDIO; // Valor por defecto si hay datos incorrectos.
        }

        // Calcular Índice de Masa Corporal (IMC)
        float imc = peso / (altura * altura);

        if (edad > 50 || imc > 30) {
            return Dificultad.FACIL; // Mayor edad o sobrepeso -> nivel fácil.
        } else if (edad < 25 && imc >= 18.5 && imc <= 25) {
            return Dificultad.DIFICIL; // Joven y en buen estado físico -> nivel difícil.
        } else {
            return Dificultad.MEDIO; // Para otros casos -> nivel medio.
        }
    }
        
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public Dificultad getDificultad() {
        return dificultad;
    }

    public void setDificultad(Dificultad dificultad) {
        this.dificultad = dificultad;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }
        
    // Método para obtener el historial del usuario (si es necesario)
    public HistorialesDeUsuario obtenerHistorial(HistorialesDeUsuarioDAO historialesDeUsuarioDAO) {
        return historialesDeUsuarioDAO.obtenerHistorialDeUsuarioPorId(this.id);
    }
}
