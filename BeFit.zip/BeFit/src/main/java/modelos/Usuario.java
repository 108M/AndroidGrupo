package modelos;

import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Markel
 */
public class Usuario {
       
        public enum Genero 
        {
            HOMBRE, MUJER, OTROS
        }
        public enum Dificultad 
        {
            FACIL, MEDIO, DIFICIL
        }
        
        private String Nombre;
        private float peso;
        private float altura;
        private Integer edad;
        private Genero genero;
        private Dificultad dificultad;
        private ArrayList<HistorialUsuario> Historial;
        private ActividadFisica ActividadActual;
        
        public Usuario(String Nombre, float peso, float altura, Integer edad, Genero genero, Dificultad dificultad, ArrayList<HistorialUsuario> historial, ActividadFisica actividad) {
            this.Nombre = Nombre;
            this.peso = peso;
            this.altura = altura;
            this.edad = edad;
            this.genero = genero;
            this.dificultad = dificultad;
            this.Historial =historial;
            this.ActividadActual = actividad;
        }

    public ArrayList<HistorialUsuario> getHistorial() {
        return Historial;
    }

    public void setHistorial(ArrayList<HistorialUsuario> Historial) {
        this.Historial = Historial;
    }

    public ActividadFisica getActividadActual() {
        return ActividadActual;
    }

    public void setActividadActual(ActividadFisica ActividadActual) {
        this.ActividadActual = ActividadActual;
    }
        
        
        

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public Dificultad getDificultad() {
        return dificultad;
    }

    public void setDificultad(Dificultad dificultad) {
        this.dificultad = dificultad;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }
        
        
}
