package modelos;

public class Usuario {
    private String objectId; // Este campo será asignado por Back4App
    private String nombre;
    private float peso;
    private float altura;
    private int edad;
    private Genero genero;

    public Usuario(String nombre, float peso, float altura, int edad, Genero genero) {
        this.nombre = nombre;
        this.peso = peso;
        this.altura = altura;
        this.edad = edad;
        this.genero = genero;
    }

    // Getters y Setters
    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }

    public enum Genero {
        HOMBRE, MUJER, OTROS
    }
}