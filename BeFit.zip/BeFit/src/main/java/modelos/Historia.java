package modelos;

import java.util.ArrayList;
import java.util.Date;
import javax.swing.ImageIcon;

public class Historia {
    
    public enum estadoFinalizacion {
        FACIL, MEDIO, DIFICIL, IMPOSIBLE
    }

    private int id; // Nuevo campo ID
    private Date fecha;
    private int actividadRegistradaId; // ID de la actividad física
    private estadoFinalizacion estadoFinalizacion;
    private ArrayList<ImageIcon> imagenesEjercicios;

    public Historia(Date fecha, int id, estadoFinalizacion estadoFinalizacion, ArrayList<ImageIcon> imagenesEjercicios) {
        this.id = id;
        this.fecha = fecha;
        this.actividadRegistradaId = actividadRegistradaId;
        this.estadoFinalizacion = estadoFinalizacion;
        this.imagenesEjercicios = new ArrayList<>();
    }

    // Getter y Setter para el ID
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // Resto de getters y setters
    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getActividadRegistradaId() {
        return actividadRegistradaId;
    }

    public void setActividadRegistradaId(int actividadRegistradaId) {
        this.actividadRegistradaId = actividadRegistradaId;
    }

    public estadoFinalizacion getEstadoFinalizacion() {
        return estadoFinalizacion;
    }

    public void setEstadoFinalizacion(estadoFinalizacion estadoFinalizacion) {
        this.estadoFinalizacion = estadoFinalizacion;
    }

    public ArrayList<ImageIcon> getImagenesEjercicios() {
        return imagenesEjercicios;
    }

    public void setImagenesEjercicios(ArrayList<ImageIcon> imagenesEjercicios) {
        this.imagenesEjercicios = imagenesEjercicios;
    }
}