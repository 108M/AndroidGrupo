package modelos;

import java.util.List;

public class HistorialesDeUsuario {
    
    private int idUsuario; // ID del usuario (ahora es el ID del historial)
    private List<Integer> historialUsuarioIds; // Lista de IDs de historias

    public HistorialesDeUsuario(int idUsuario, List<Integer> historialUsuarioIds) {
        this.idUsuario = idUsuario;
        this.historialUsuarioIds = historialUsuarioIds;
    }

    // Getter y Setter para el ID del usuario (que ahora es el ID del historial)
    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    // Getter y Setter para la lista de IDs de historias
    public List<Integer> getHistorialUsuarioIds() {
        return historialUsuarioIds;
    }

    public void setHistorialUsuarioIds(List<Integer> historialUsuarioIds) {
        this.historialUsuarioIds = historialUsuarioIds;
    }
}