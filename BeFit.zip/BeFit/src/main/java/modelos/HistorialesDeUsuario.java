package modelos;

import java.util.List;

public class HistorialesDeUsuario {
    private String objectId; // Este campo será asignado por Back4App
    private String idUsuario; // Ahora es un String (objectId de Usuario)
    private List<String> historialUsuarioIds; // Lista de objectIds de Historias

    public HistorialesDeUsuario(String idUsuario, List<String> historialUsuarioIds) {
        this.idUsuario = idUsuario;
        this.historialUsuarioIds = historialUsuarioIds;
    }

    // Getters y Setters
    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public List<String> getHistorialUsuarioIds() {
        return historialUsuarioIds;
    }

    public void setHistorialUsuarioIds(List<String> historialUsuarioIds) {
        this.historialUsuarioIds = historialUsuarioIds;
    }
}