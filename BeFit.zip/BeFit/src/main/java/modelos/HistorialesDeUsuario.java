/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import java.util.List;

/**
 *
 * @author Markel
 */
public class HistorialesDeUsuario {
    
    private int idUsuario;
    private List <Historia> historialUsuario;

    public HistorialesDeUsuario(int idUsuario, List<Historia> historialUsuario) {
        this.idUsuario = idUsuario;
        this.historialUsuario = historialUsuario;
    }

    public int getId() {
        return idUsuario;
    }

    public void setId(int id) {
        this.idUsuario = idUsuario;
    }

    public List<Historia> getHistorialUsuario() {
        return historialUsuario;
    }

    public void setHistorialUsuario(List<Historia> historialUsuario) {
        this.historialUsuario = historialUsuario;
    }
    
    
}
