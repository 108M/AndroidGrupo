/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import java.util.ArrayList;
import java.util.Date;
import javax.swing.ImageIcon;

/**
 *
 * @author Markel
 */
public class HistorialUsuario {
    
    public enum estadoFinalizacion 
    {
           FACIL, MEDIO, DIFICIL, IMPOSIBLE
    }
    
    private Date fecha;
    private ActividadFisica actividad_registrada;
    private estadoFinalizacion estadoFinalizacion;
    private ArrayList<ImageIcon>imagenes_ejercios;

    public HistorialUsuario(Date fecha, ActividadFisica actividad_registrada, estadoFinalizacion estadoFinalizacion, ArrayList<ImageIcon> imagenes_ejercios) {
        this.fecha = fecha;
        this.actividad_registrada = actividad_registrada;
        this.estadoFinalizacion = estadoFinalizacion;
        this.imagenes_ejercios = new ArrayList<>(actividad_registrada.getSizeListaEjercicios());
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public ActividadFisica getActividad_registrada() {
        return actividad_registrada;
    }

    public void setActividad_registrada(ActividadFisica actividad_registrada) {
        this.actividad_registrada = actividad_registrada;
    }

    public estadoFinalizacion getEstadoFinalizacion() {
        return estadoFinalizacion;
    }

    public void setEstadoFinalizacion(estadoFinalizacion estadoFinalizacion) {
        this.estadoFinalizacion = estadoFinalizacion;
    }

    public ArrayList<ImageIcon> getImagenes_ejercios() {
        return imagenes_ejercios;
    }

    public void setImagenes_ejercios(ArrayList<ImageIcon> imagenes_ejercios) {
        this.imagenes_ejercios = imagenes_ejercios;
    }
    
    
    
    
}
