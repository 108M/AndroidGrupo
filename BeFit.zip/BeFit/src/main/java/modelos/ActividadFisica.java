package modelos;

import java.time.LocalTime;
import java.util.ArrayList;

public class ActividadFisica {
    
    private int id;
    private ArrayList<Integer> listaEjerciciosIds; // Lista de IDs de ejercicios
    private LocalTime horaComienzoActividad;
    private LocalTime horaMaximaActividad;
    private LocalTime horaFinalizacionActividad;
    private Boolean estado;

    public ActividadFisica(int id, ArrayList<Integer> listaEjerciciosIds, LocalTime horaComienzoActividad, LocalTime horaMaximaActividad, LocalTime horaFinalizacionActividad, Boolean estado) {
        this.id = id;
        this.listaEjerciciosIds = listaEjerciciosIds;
        this.horaComienzoActividad = horaComienzoActividad;
        this.horaMaximaActividad = horaMaximaActividad;
        this.horaFinalizacionActividad = horaFinalizacionActividad;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Boolean getEstado() {
        return estado;
    }

    public void setEstado(Boolean estado) {
        this.estado = estado;
    }

    public ArrayList<Integer> getListaEjerciciosIds() {
        return listaEjerciciosIds;
    }

    public void setListaEjerciciosIds(ArrayList<Integer> listaEjerciciosIds) {
        this.listaEjerciciosIds = listaEjerciciosIds;
    }

    public void añadirEjercicioId(int ejercicioId) {
        this.listaEjerciciosIds.add(ejercicioId);
    }

    public LocalTime getHoraComienzoActividad() {
        return horaComienzoActividad;
    }

    public void setHoraComienzoActividad(LocalTime horaComienzoActividad) {
        this.horaComienzoActividad = horaComienzoActividad;
    }

    public LocalTime getHoraMaximaActividad() {
        return horaMaximaActividad;
    }

    public void setHoraMaximaActividad(LocalTime horaMaximaActividad) {
        this.horaMaximaActividad = horaMaximaActividad;
    }

    public LocalTime getHoraFinalizacionActividad() {
        return horaFinalizacionActividad;
    }

    public void setHoraFinalizacionActividad(LocalTime horaFinalizacionActividad) {
        this.horaFinalizacionActividad = horaFinalizacionActividad;
    }

    public int getSizeListaEjerciciosIds() {
        return listaEjerciciosIds.size();
    }
}