package modelos;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ActividadFisica {
    private String objectId;
    private ArrayList<String> listaEjerciciosIds;
    private String horaComienzoActividad;
    private String horaMaximaActividad;
    private String horaFinalizacionActividad;
    private Boolean estado;

    private List<Ejercicio> ejercicios; // Para almacenar los objetos Ejercicio

    public ActividadFisica(ArrayList<String> listaEjerciciosIds,
                         LocalTime horaComienzoActividad,
                         LocalTime horaMaximaActividad, // Recibir horaMaxima como parámetro
                         Boolean estado) {
        this.listaEjerciciosIds = listaEjerciciosIds;
        this.horaComienzoActividad = horaComienzoActividad.toString();
        this.horaMaximaActividad = horaMaximaActividad.toString(); // Asignar horaMaxima recibida
        this.horaFinalizacionActividad = null;
        this.estado = estado;
        this.ejercicios = new ArrayList<>(); // Inicializar la lista de ejercicios
    }

    public List<Ejercicio> getEjercicios() {
        return ejercicios;
    }

    public void setEjercicios(List<Ejercicio> ejercicios) {
        this.ejercicios = ejercicios;
        // Actualizar también la lista de IDs
        this.listaEjerciciosIds = new ArrayList<>(
            ejercicios.stream()
                .map(Ejercicio::getObjectId)
                .collect(Collectors.toList())
        );
    }

    // Método para establecer la hora de finalización (con validación)
    public void setHoraFinalizacionActividad(LocalTime horaFinalizacion) {
        LocalTime horaComienzo = LocalTime.parse(this.horaComienzoActividad);
        LocalTime horaMax = LocalTime.parse(this.horaMaximaActividad);
        
        // Validar que esté entre hora inicio y hora máxima
        if (horaFinalizacion.isBefore(horaComienzo)) {
            throw new IllegalArgumentException("La hora de finalización no puede ser anterior al inicio");
        }
        if (horaFinalizacion.isAfter(horaMax)) {
            throw new IllegalArgumentException("La hora de finalización no puede superar el tiempo máximo");
        }
        
        this.horaFinalizacionActividad = horaFinalizacion.toString();
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public ArrayList<String> getListaEjerciciosIds() {
        return listaEjerciciosIds;
    }

    public void setListaEjerciciosIds(ArrayList<String> listaEjerciciosIds) {
        if (listaEjerciciosIds == null || listaEjerciciosIds.isEmpty()) {
            throw new IllegalArgumentException("La lista de ejercicios no puede ser vacía.");
        }
        this.listaEjerciciosIds = listaEjerciciosIds;
    }

    public String getHoraComienzoActividad() {
        return horaComienzoActividad;
    }

    public void setHoraComienzoActividad(String horaComienzoActividad) {
        if (horaComienzoActividad == null || horaComienzoActividad.trim().isEmpty()) {
            throw new IllegalArgumentException("La hora de comienzo no puede estar vacía.");
        }
        this.horaComienzoActividad = horaComienzoActividad;
    }

    public String getHoraMaximaActividad() {
        return horaMaximaActividad;
    }

    public void setHoraMaximaActividad(String horaMaximaActividad) {
        if (horaMaximaActividad == null || horaMaximaActividad.trim().isEmpty()) {
            throw new IllegalArgumentException("La hora máxima de actividad no puede estar vacía.");
        }
        this.horaMaximaActividad = horaMaximaActividad;
    }

    public String getHoraFinalizacionActividad() {
        return horaFinalizacionActividad;
    }

    public Boolean getEstado() {
        return estado;
    }

    public void setEstado(Boolean estado) {
        if (estado == null) {
            throw new IllegalArgumentException("El estado no puede ser null.");
        }
        this.estado = estado;
    }

   
}