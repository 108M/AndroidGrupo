package modelos;

import java.time.LocalTime;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Markel
 */
public class ActividadFisica {
    
    private int id;
    private ArrayList <Ejercicio> ListaEjercicios;
    private LocalTime Hora_comienzo_actividad;
    private LocalTime Hora_maxima_actividad; // esta hora se calcula con el tiempo maximo de los ejericios y la dificultad y descansos
    private LocalTime Hora_finalizacion_actividad;
    private Boolean estado; //marcara si la actividad esta finalizada o no

    public ActividadFisica(int id,ArrayList<Ejercicio> ListaEjercicios, LocalTime Hora_comienzo_actividad, LocalTime Hora_maxima_actividad, LocalTime Hora_finalizacion_actividad, Boolean estado) {
        this.id = id;
        this.ListaEjercicios = ListaEjercicios;
        this.Hora_comienzo_actividad = Hora_comienzo_actividad;
        this.Hora_maxima_actividad = Hora_maxima_actividad;
        this.Hora_finalizacion_actividad = Hora_finalizacion_actividad;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
    public Boolean getEstado() {
        return estado;
    }

    public void setEstado(Boolean estado) {
        this.estado = estado;
    }

    public ArrayList<Ejercicio> getListaEjercicios() {
        return ListaEjercicios;
    }
    
    public void añadirEjercicio(Ejercicio ejercicio){
        this.ListaEjercicios.addLast(ejercicio);
    }

    public void setListaEjercicios(ArrayList<Ejercicio> ListaEjercicios) {
        this.ListaEjercicios = ListaEjercicios;
    }

    public LocalTime getHora_comienzo_actividad() {
        return Hora_comienzo_actividad;
    }

    public void setHora_comienzo_actividad(LocalTime Hora_comienzo_actividad) {
        this.Hora_comienzo_actividad = Hora_comienzo_actividad;
    }

    public LocalTime getHora_maxima_actividad() {
        return Hora_maxima_actividad;
    }

    public void setHora_maxima_actividad(LocalTime Hora_maxima_actividad) {
        this.Hora_maxima_actividad = Hora_maxima_actividad;
    }

    public LocalTime getHora_finalizacion_actividad() {
        return Hora_finalizacion_actividad;
    }

    public void setHora_finalizacion_actividad(LocalTime Hora_finalizacion_actividad) {
        this.Hora_finalizacion_actividad = Hora_finalizacion_actividad;
    }
    
    public int getSizeListaEjercicios (){
        return ListaEjercicios.size();
    }
    
    
    
    
}
