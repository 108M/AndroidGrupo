package modelos;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import modelos.HistorialesDeUsuario;
import java.util.ArrayList;
import java.util.List;

public class HistorialesDeUsuarioTest {
    private HistorialesDeUsuario historialDeUsuario;

    @BeforeEach
    public void setUp() {
        List<String> historialIds = new ArrayList<>();
        historialIds.add("historial1");
        historialIds.add("historial2");
        
        historialDeUsuario = new HistorialesDeUsuario("usuario123", historialIds);
    }

    @Test
    public void testCreacionCorrecta() {
        assertNotNull(historialDeUsuario.getHistorialUsuarioIds());
        assertEquals(2, historialDeUsuario.getHistorialUsuarioIds().size());
        assertEquals("historial1", historialDeUsuario.getHistorialUsuarioIds().get(0));
        assertEquals("usuario123", historialDeUsuario.getIdUsuario());
    }

    @Test
    public void testIdUsuarioNoVacio() {
        assertThrows(IllegalArgumentException.class, () -> {
            historialDeUsuario.setIdUsuario(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            historialDeUsuario.setIdUsuario("");
        });
    }

    @Test
    public void testHistorialUsuarioIdsNoVacio() {
        assertThrows(IllegalArgumentException.class, () -> {
            historialDeUsuario.setHistorialUsuarioIds(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            historialDeUsuario.setHistorialUsuarioIds(new ArrayList<>());
        });
    }
}
