package com.example.befit.models;

import java.io.Serializable;
import java.util.ArrayList;
import org.threeten.bp.LocalTime;

public class ActividadFisica implements Serializable {

    private int id;
    private ArrayList<Ejercicio> listaEjercicios;
    private LocalTime horaComienzoActividad;
    private LocalTime horaMaximaActividad; // Calculada en base al tiempo máximo de los ejercicios, dificultad y descansos
    private LocalTime horaFinalizacionActividad;
    private Boolean estado; // Indica si la actividad está finalizada o no

    public ActividadFisica(int id, ArrayList<Ejercicio> listaEjercicios, LocalTime horaComienzoActividad, LocalTime horaMaximaActividad, LocalTime horaFinalizacionActividad, Boolean estado) {
        this.id = id;
        this.listaEjercicios = listaEjercicios;
        this.horaComienzoActividad = horaComienzoActividad;
        this.horaMaximaActividad = horaMaximaActividad;
        this.horaFinalizacionActividad = horaFinalizacionActividad;
        this.estado = estado;
    }

    // Getters y setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Boolean getEstado() {
        return estado;
    }

    public void setEstado(Boolean estado) {
        this.estado = estado;
    }

    public ArrayList<Ejercicio> getListaEjercicios() {
        return listaEjercicios;
    }

    public void añadirEjercicio(Ejercicio ejercicio) {
        this.listaEjercicios.add(ejercicio);
    }

    public void setListaEjercicios(ArrayList<Ejercicio> listaEjercicios) {
        this.listaEjercicios = listaEjercicios;
    }

    public LocalTime getHoraComienzoActividad() {
        return horaComienzoActividad;
    }

    public void setHoraComienzoActividad(LocalTime horaComienzoActividad) {
        this.horaComienzoActividad = horaComienzoActividad;
    }

    public LocalTime getHoraMaximaActividad() {
        return horaMaximaActividad;
    }

    public void setHoraMaximaActividad(LocalTime horaMaximaActividad) {
        this.horaMaximaActividad = horaMaximaActividad;
    }

    public LocalTime getHoraFinalizacionActividad() {
        return horaFinalizacionActividad;
    }

    public void setHoraFinalizacionActividad(LocalTime horaFinalizacionActividad) {
        this.horaFinalizacionActividad = horaFinalizacionActividad;
    }

    public int getSizeListaEjercicios() {
        return listaEjercicios.size();
    }
}
