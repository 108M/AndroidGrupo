package com.example.befit.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

public class Historia implements Serializable {

    public enum EstadoFinalizacion {
        FACIL, MEDIO, DIFICIL, IMPOSIBLE
    }

    private Date fecha;
    private ActividadFisica actividadRegistrada;
    private EstadoFinalizacion estadoFinalizacion;
    // Usamos una lista de enteros para representar los resource IDs de las imágenes (por ejemplo, R.drawable.imagen)
    private ArrayList<Integer> imagenesEjercicios;

    public Historia(Date fecha, ActividadFisica actividadRegistrada, EstadoFinalizacion estadoFinalizacion, ArrayList<Integer> imagenesEjercicios) {
        this.fecha = fecha;
        this.actividadRegistrada = actividadRegistrada;
        this.estadoFinalizacion = estadoFinalizacion;
        // Puedes inicializar la lista con una capacidad basada en la cantidad de ejercicios, si lo deseas:
        // this.imagenesEjercicios = new ArrayList<>(actividadRegistrada.getSizeListaEjercicios());
        // En este ejemplo se asigna la lista recibida:
        this.imagenesEjercicios = imagenesEjercicios;
    }

    // Getters y Setters

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public ActividadFisica getActividadRegistrada() {
        return actividadRegistrada;
    }

    public void setActividadRegistrada(ActividadFisica actividadRegistrada) {
        this.actividadRegistrada = actividadRegistrada;
    }

    public EstadoFinalizacion getEstadoFinalizacion() {
        return estadoFinalizacion;
    }

    public void setEstadoFinalizacion(EstadoFinalizacion estadoFinalizacion) {
        this.estadoFinalizacion = estadoFinalizacion;
    }

    public ArrayList<Integer> getImagenesEjercicios() {
        return imagenesEjercicios;
    }

    public void setImagenesEjercicios(ArrayList<Integer> imagenesEjercicios) {
        this.imagenesEjercicios = imagenesEjercicios;
    }
}
