package com.example.befit.models;

import java.io.Serializable;
import java.util.List;

public class HistorialesDeUsuario implements Serializable {

    private int idUsuario;
    private List<Historia> historialUsuario;

    public HistorialesDeUsuario(int idUsuario, List<Historia> historialUsuario) {
        this.idUsuario = idUsuario;
        this.historialUsuario = historialUsuario;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int id) {
        this.idUsuario = id;
    }

    public List<Historia> getHistorialUsuario() {
        return historialUsuario;
    }

    public void setHistorialUsuario(List<Historia> historialUsuario) {
        this.historialUsuario = historialUsuario;
    }
}
