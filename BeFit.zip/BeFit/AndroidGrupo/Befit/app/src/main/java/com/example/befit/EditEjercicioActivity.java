package com.example.befit;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.befit.models.Ejercicio;

public class EditEjercicioActivity extends AppCompatActivity {

    private EditText editTextNombre, editTextIntensidad, editTextTiempoMax, editTextTecnica;
    private Button buttonGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_ejercicio);

        editTextNombre = findViewById(R.id.editTextNombre);
        editTextIntensidad = findViewById(R.id.editTextIntensidad);
        editTextTiempoMax = findViewById(R.id.editTextTiempoMax);
        editTextTecnica = findViewById(R.id.editTextTecnica);

        buttonGuardar = findViewById(R.id.buttonGuardar);
        buttonGuardar.setOnClickListener(v -> guardarEjercicio());
    }

    private void guardarEjercicio() {
        try {
            String nombre = editTextNombre.getText().toString();
            int intensidad = Integer.parseInt(editTextIntensidad.getText().toString());
            float tiempoMax = Float.parseFloat(editTextTiempoMax.getText().toString());
            String tecnica = editTextTecnica.getText().toString();

            // Suponemos que no pasamos imageResId o lo dejamos en 0
            Ejercicio ejercicio = new Ejercicio(nombre, intensidad, 0, tecnica, tiempoMax);

            Toast.makeText(this, "Ejercicio creado: " + ejercicio.getNombreEjercicio(), Toast.LENGTH_SHORT).show();
            finish();
        } catch (Exception e) {
            Toast.makeText(this, "Error al crear ejercicio: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
