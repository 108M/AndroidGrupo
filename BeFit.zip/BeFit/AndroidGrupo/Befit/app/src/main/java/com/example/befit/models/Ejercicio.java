package com.example.befit.models;

import java.io.Serializable;

public class Ejercicio implements Serializable {

    // Opcional: Enumeración para tipos predefinidos de ejercicio
    public enum TipoEjercicio {
        FLEXIONES, DOMINADAS, ABDOMINALES, CORRER, BURPIS
    }

    private String nombreEjercicio;
    private Integer intensidad;
    // Reemplazamos ImageIcon por un resource ID (int) para imágenes en res/drawable
    private int imageResId;
    private String tecnica;
    private float tiempoMax;

    public Ejercicio(String nombreEjercicio, Integer intensidad, int imageResId, String tecnica, float tiempoMax) {
        this.nombreEjercicio = nombreEjercicio;
        this.intensidad = intensidad;
        this.imageResId = imageResId;
        this.tecnica = tecnica;
        this.tiempoMax = tiempoMax;
    }

    public String getNombreEjercicio() {
        return nombreEjercicio;
    }

    public void setNombreEjercicio(String nombreEjercicio) {
        this.nombreEjercicio = nombreEjercicio;
    }

    public Integer getIntensidad() {
        return intensidad;
    }

    public void setIntensidad(Integer intensidad) {
        this.intensidad = intensidad;
    }

    public int getImageResId() {
        return imageResId;
    }

    public void setImageResId(int imageResId) {
        this.imageResId = imageResId;
    }

    public String getTecnica() {
        return tecnica;
    }

    public void setTecnica(String tecnica) {
        this.tecnica = tecnica;
    }

    public float getTiempoMax() {
        return tiempoMax;
    }

    public void setTiempoMax(float tiempoMax) {
        this.tiempoMax = tiempoMax;
    }
}
