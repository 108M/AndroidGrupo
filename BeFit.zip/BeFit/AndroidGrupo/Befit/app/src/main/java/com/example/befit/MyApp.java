package com.example.befit;

import android.app.Application;
import com.jakewharton.threetenabp.AndroidThreeTen;

public class MyApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // Inicializa la librería ThreeTenABP
        AndroidThreeTen.init(this);
    }
}
